-- Digital Wage and Attendance Management System
-- Case study: Kampala Cement. Academic prototype.
-- Works on MySQL 8 and MariaDB 10.4+ (XAMPP).
-- Run through: npm run setup-db  (inside the backend folder)

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  phone VARCHAR(25) NULL,
  password_hash VARCHAR(100) NOT NULL,
  role ENUM('worker','supervisor','finance','admin') NOT NULL,
  status ENUM('pending','active','inactive') NOT NULL DEFAULT 'pending',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_users_role (role),
  INDEX idx_users_status (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS worker_profiles (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL UNIQUE,
  worker_code VARCHAR(20) NOT NULL UNIQUE,
  skills VARCHAR(255) NULL,
  address VARCHAR(255) NULL,
  emergency_contact VARCHAR(120) NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS employer_profiles (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL UNIQUE,
  section VARCHAR(120) NULL,
  position_title VARCHAR(120) NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS jobs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  description TEXT NULL,
  location VARCHAR(150) NULL,
  start_date DATE NOT NULL,
  end_date DATE NULL,
  status ENUM('active','completed','cancelled') NOT NULL DEFAULT 'active',
  created_by INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id),
  INDEX idx_jobs_status (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS assignments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  job_id INT UNSIGNED NOT NULL,
  worker_id INT UNSIGNED NOT NULL,
  rate_type ENUM('hourly','daily') NOT NULL,
  rate DECIMAL(12,2) NOT NULL,
  status ENUM('active','ended') NOT NULL DEFAULT 'active',
  assigned_by INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (job_id) REFERENCES jobs(id),
  FOREIGN KEY (worker_id) REFERENCES users(id),
  FOREIGN KEY (assigned_by) REFERENCES users(id),
  UNIQUE KEY uq_assignment (job_id, worker_id),
  INDEX idx_assign_worker (worker_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS shifts (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  assignment_id INT UNSIGNED NOT NULL,
  shift_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  created_by INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (assignment_id) REFERENCES assignments(id),
  FOREIGN KEY (created_by) REFERENCES users(id),
  UNIQUE KEY uq_shift (assignment_id, shift_date, start_time),
  INDEX idx_shift_date (shift_date)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS attendance (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  worker_id INT UNSIGNED NOT NULL,
  assignment_id INT UNSIGNED NOT NULL,
  shift_id INT UNSIGNED NOT NULL UNIQUE,
  work_date DATE NOT NULL,
  clock_in DATETIME NULL,
  clock_out DATETIME NULL,
  total_hours DECIMAL(6,2) NULL,
  attendance_status ENUM('In Progress','Completed','Absent','Missed Clock-out') NOT NULL DEFAULT 'In Progress',
  is_late TINYINT(1) NOT NULL DEFAULT 0,
  approval_status ENUM('Pending Approval','Approved','Rejected','Correction Requested') NOT NULL DEFAULT 'Pending Approval',
  approved_by INT UNSIGNED NULL,
  approved_at DATETIME NULL,
  supervisor_note VARCHAR(255) NULL,
  in_lat DECIMAL(9,6) NULL,
  in_lng DECIMAL(9,6) NULL,
  out_lat DECIMAL(9,6) NULL,
  out_lng DECIMAL(9,6) NULL,
  location_flag TINYINT(1) NOT NULL DEFAULT 0,
  capture_method ENUM('self','qr','system') NOT NULL DEFAULT 'self',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (worker_id) REFERENCES users(id),
  FOREIGN KEY (assignment_id) REFERENCES assignments(id),
  FOREIGN KEY (shift_id) REFERENCES shifts(id),
  FOREIGN KEY (approved_by) REFERENCES users(id),
  INDEX idx_att_worker_date (worker_id, work_date),
  INDEX idx_att_approval (approval_status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS attendance_corrections (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  attendance_id INT UNSIGNED NOT NULL,
  requested_by INT UNSIGNED NOT NULL,
  original_clock_in DATETIME NULL,
  original_clock_out DATETIME NULL,
  proposed_clock_in DATETIME NOT NULL,
  proposed_clock_out DATETIME NOT NULL,
  reason VARCHAR(255) NOT NULL,
  status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  reviewed_by INT UNSIGNED NULL,
  reviewed_at DATETIME NULL,
  review_note VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (attendance_id) REFERENCES attendance(id),
  FOREIGN KEY (requested_by) REFERENCES users(id),
  FOREIGN KEY (reviewed_by) REFERENCES users(id),
  INDEX idx_corr_status (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS wage_rules (
  rule_key VARCHAR(60) PRIMARY KEY,
  rule_value VARCHAR(255) NOT NULL,
  description VARCHAR(255) NULL,
  updated_by INT UNSIGNED NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS payroll_periods (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  period_type ENUM('daily','weekly','biweekly','monthly') NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  status ENUM('Draft','Approved','Closed') NOT NULL DEFAULT 'Draft',
  created_by INT UNSIGNED NOT NULL,
  approved_by INT UNSIGNED NULL,
  approved_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id),
  FOREIGN KEY (approved_by) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS payroll_items (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  period_id INT UNSIGNED NOT NULL,
  worker_id INT UNSIGNED NOT NULL,
  days_worked INT NOT NULL DEFAULT 0,
  total_hours DECIMAL(8,2) NOT NULL DEFAULT 0,
  normal_pay DECIMAL(14,2) NOT NULL DEFAULT 0,
  overtime_pay DECIMAL(14,2) NOT NULL DEFAULT 0,
  total_pay DECIMAL(14,2) NOT NULL DEFAULT 0,
  status ENUM('Unpaid','Paid') NOT NULL DEFAULT 'Unpaid',
  FOREIGN KEY (period_id) REFERENCES payroll_periods(id),
  FOREIGN KEY (worker_id) REFERENCES users(id),
  UNIQUE KEY uq_period_worker (period_id, worker_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS wage_calculations (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  attendance_id INT UNSIGNED NOT NULL UNIQUE,
  worker_id INT UNSIGNED NOT NULL,
  assignment_id INT UNSIGNED NOT NULL,
  work_date DATE NOT NULL,
  rate_type ENUM('hourly','daily') NOT NULL,
  rate DECIMAL(12,2) NOT NULL,
  total_hours DECIMAL(6,2) NOT NULL,
  normal_hours DECIMAL(6,2) NOT NULL,
  overtime_hours DECIMAL(6,2) NOT NULL,
  overtime_multiplier DECIMAL(4,2) NOT NULL,
  basic_pay DECIMAL(14,2) NOT NULL,
  overtime_pay DECIMAL(14,2) NOT NULL,
  total_pay DECIMAL(14,2) NOT NULL,
  payroll_item_id INT UNSIGNED NULL,
  calculated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (attendance_id) REFERENCES attendance(id),
  FOREIGN KEY (worker_id) REFERENCES users(id),
  FOREIGN KEY (assignment_id) REFERENCES assignments(id),
  FOREIGN KEY (payroll_item_id) REFERENCES payroll_items(id),
  INDEX idx_wc_worker_date (worker_id, work_date)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS payments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  payroll_item_id INT UNSIGNED NOT NULL UNIQUE,
  amount DECIMAL(14,2) NOT NULL,
  method ENUM('cash','mobile_money','bank_transfer') NOT NULL,
  reference VARCHAR(80) NOT NULL,
  payment_date DATE NOT NULL,
  recorded_by INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (payroll_item_id) REFERENCES payroll_items(id),
  FOREIGN KEY (recorded_by) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS payslips (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  payslip_no VARCHAR(30) NOT NULL UNIQUE,
  payroll_item_id INT UNSIGNED NOT NULL UNIQUE,
  worker_id INT UNSIGNED NOT NULL,
  generated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (payroll_item_id) REFERENCES payroll_items(id),
  FOREIGN KEY (worker_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS notifications (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  type VARCHAR(40) NOT NULL,
  message VARCHAR(255) NOT NULL,
  dedupe_key VARCHAR(100) NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  sms_status ENUM('not_sent','sent','failed','skipped') NOT NULL DEFAULT 'not_sent',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_notif_user (user_id, is_read),
  INDEX idx_notif_dedupe (dedupe_key)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NULL,
  action VARCHAR(60) NOT NULL,
  entity VARCHAR(60) NULL,
  entity_id VARCHAR(40) NULL,
  previous_value TEXT NULL,
  new_value TEXT NULL,
  ip_address VARCHAR(60) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_audit_action (action),
  INDEX idx_audit_user (user_id),
  INDEX idx_audit_created (created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS revoked_tokens (
  jti VARCHAR(64) PRIMARY KEY,
  expires_at DATETIME NOT NULL
) ENGINE=InnoDB;
