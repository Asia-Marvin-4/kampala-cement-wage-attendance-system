// Creates the database, all tables, default wage rules, audit-log protection and (optionally) clearly labelled demo data.
// Usage (inside the backend folder):
//   npm run setup-db                 -> create everything + demo data
//   npm run setup-db -- --no-demo    -> create everything, no demo data
//   npm run setup-db -- --reset      -> DELETE the database first, then create everything again
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
const env = require('../src/config/env');
const { DEFAULT_RULES, getRules } = require('../src/services/rules');
const { calculateWage } = require('../src/services/wageEngine');
const { createUser } = require('../src/services/userService');
const T = require('../src/utils/time');

async function setupDatabase({ demo = true, reset = false, silent = false } = {}) {
  const log = (...a) => { if (!silent) console.log(...a); };
  if (!/^[A-Za-z0-9_]+$/.test(env.DB_NAME)) throw new Error('DB_NAME may only contain letters, numbers and underscores.');
  const conn = await mysql.createConnection({ host: env.DB_HOST, port: env.DB_PORT, user: env.DB_USER, password: env.DB_PASSWORD, dateStrings: true, decimalNumbers: true });
  try {
    await conn.query("SET time_zone = '+03:00'");
    if (reset) { await conn.query(`DROP DATABASE IF EXISTS \`${env.DB_NAME}\``); log(`Database ${env.DB_NAME} deleted.`); }
    await conn.query(`CREATE DATABASE IF NOT EXISTS \`${env.DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
    await conn.query(`USE \`${env.DB_NAME}\``);

    const sql = fs.readFileSync(path.join(__dirname, '..', '..', 'database', 'schema.sql'), 'utf8')
      .split('\n').filter((l) => !l.trim().startsWith('--')).join('\n');
    for (const stmt of sql.split(';').map((s) => s.trim()).filter(Boolean)) await conn.query(stmt);
    log('Tables ready.');

    // Audit logs cannot be edited or deleted, even by mistake
    try {
      for (const [name, evt] of [['audit_logs_no_update', 'UPDATE'], ['audit_logs_no_delete', 'DELETE']]) {
        await conn.query(`DROP TRIGGER IF EXISTS ${name}`);
        await conn.query(`CREATE TRIGGER ${name} BEFORE ${evt} ON audit_logs FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Audit logs are read-only'`);
      }
      log('Audit log protection ready.');
    } catch (e) { console.warn('Warning: could not create audit-log protection triggers:', e.message); }

    for (const [k, v, d] of DEFAULT_RULES) await conn.query('INSERT IGNORE INTO wage_rules (rule_key, rule_value, description) VALUES (?,?,?)', [k, v, d]);
    log('Default wage rules ready.');

    const [[{ n }]] = await conn.query('SELECT COUNT(*) AS n FROM users');
    if (n === 0) {
      if (demo) { await seedDemo(conn, log); }
      else {
        const id = await createUser(conn, { full_name: 'System Administrator', email: 'admin@wams.test', phone: null, password: 'Admin@12345', role: 'admin', status: 'active' });
        log('Created the first administrator: admin@wams.test / Admin@12345  (change this password after logging in)');
        return id;
      }
    } else log('Users already exist: demo data skipped.');
  } finally { await conn.end(); }
}

// ---------- TEST / DEMO DATA (clearly labelled: not real Kampala Cement data) ----------
async function seedDemo(conn, log) {
  const mk = (full_name, email, role, phone) => createUser(conn, { full_name, email, phone, password: { admin: 'Admin@12345', supervisor: 'Super@12345', finance: 'Finance@12345', worker: 'Worker@12345' }[role], role, status: 'active' });
  const admin = await mk('Demo Administrator', 'admin@wams.test', 'admin', null);
  const sup = await mk('Demo Supervisor', 'supervisor@wams.test', 'supervisor', null);
  await mk('Demo Finance Officer', 'finance@wams.test', 'finance', null);
  const w1 = await mk('Demo Worker One', 'worker1@wams.test', 'worker', '0700000001');
  const w2 = await mk('Demo Worker Two', 'worker2@wams.test', 'worker', '0700000002');
  const w3 = await mk('Demo Worker Three', 'worker3@wams.test', 'worker', '0700000003');

  const today = T.todayStr();
  const [job] = await conn.query('INSERT INTO jobs (title, description, location, start_date, created_by) VALUES (?,?,?,?,?)', ['Bag Loading (Demo Job)', 'Test/Demo data: loading bagged product onto trucks', 'Demo loading bay', T.addDays(today, -10), sup]);
  const asg = {};
  for (const [w, type, rate] of [[w1, 'hourly', 5000], [w2, 'hourly', 5000], [w3, 'daily', 40000]]) {
    const [a] = await conn.query('INSERT INTO assignments (job_id, worker_id, rate_type, rate, assigned_by) VALUES (?,?,?,?,?)', [job.insertId, w, type, rate, sup]);
    asg[w] = { id: a.insertId, type, rate };
  }
  const rules = await getRules(conn);
  // Three past days of approved attendance, so payroll can be created straight away
  for (let back = 3; back >= 1; back--) {
    const d = T.addDays(today, -back);
    for (const w of [w1, w2, w3]) {
      const a = asg[w];
      const [s] = await conn.query('INSERT INTO shifts (assignment_id, shift_date, start_time, end_time, created_by) VALUES (?,?,?,?,?)', [a.id, d, '08:00:00', '17:00:00', sup]);
      const late = w === w2 && back === 2;
      const cin = `${d} ${late ? '08:30' : '08:00'}:00`;
      const cout = `${d} ${w === w1 && back === 1 ? '19:00' : '17:00'}:00`;
      const hours = T.hoursBetween(cin, cout);
      const [att] = await conn.query(
        `INSERT INTO attendance (worker_id, assignment_id, shift_id, work_date, clock_in, clock_out, total_hours, attendance_status, is_late, approval_status, approved_by, approved_at, capture_method)
         VALUES (?,?,?,?,?,?,?, 'Completed', ?, 'Approved', ?, ?, 'self')`, [w, a.id, s.insertId, d, cin, cout, hours, late ? 1 : 0, sup, `${d} 18:00:00`]);
      const c = calculateWage({ rateType: a.type, rate: a.rate, totalHours: hours, rules });
      await conn.query(
        `INSERT INTO wage_calculations (attendance_id, worker_id, assignment_id, work_date, rate_type, rate, total_hours, normal_hours, overtime_hours, overtime_multiplier, basic_pay, overtime_pay, total_pay)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`, [att.insertId, w, a.id, d, c.rate_type, c.rate, c.total_hours, c.normal_hours, c.overtime_hours, c.overtime_multiplier, c.basic_pay, c.overtime_pay, c.total_pay]);
    }
  }
  // Open shifts today and tomorrow (wide window so you can try clock-in at any time of the day)
  for (const d of [today, T.addDays(today, 1)]) for (const w of [w1, w2, w3]) {
    await conn.query('INSERT INTO shifts (assignment_id, shift_date, start_time, end_time, created_by) VALUES (?,?,?,?,?)', [asg[w].id, d, '06:00:00', '23:00:00', sup]);
  }
  await conn.query("INSERT INTO audit_logs (user_id, action, entity, new_value) VALUES (?, 'DEMO_DATA_LOADED', 'system', ?)", [admin, JSON.stringify({ note: 'Test/Demo data only' })]);
  log('\nDemo data loaded (TEST/DEMO DATA, not real company data). Demo logins:');
  log('  Administrator : admin@wams.test       / Admin@12345');
  log('  Supervisor    : supervisor@wams.test  / Super@12345');
  log('  Finance       : finance@wams.test     / Finance@12345');
  log('  Workers       : worker1@wams.test, worker2@wams.test, worker3@wams.test  / Worker@12345');
}

module.exports = { setupDatabase };

if (require.main === module) {
  const args = process.argv.slice(2);
  setupDatabase({ demo: !args.includes('--no-demo'), reset: args.includes('--reset') })
    .then(() => { console.log('\nDatabase setup finished. Start the system with: npm start\n'); })
    .catch((e) => { console.error('\nSetup failed:', e.message, '\nCheck DB_HOST, DB_USER and DB_PASSWORD in backend/.env and that MySQL is running.\n'); process.exit(1); });
}
