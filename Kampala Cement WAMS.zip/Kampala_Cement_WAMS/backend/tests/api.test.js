// End-to-end test of the whole workflow against a real (test) database.
// Needs MySQL running and the DB_* settings in backend/.env (it creates its own database kc_wams_test).
process.env.DB_NAME = 'kc_wams_test';
process.env.NODE_ENV = 'test';
process.env.AUTOMATION_ENABLED = 'false';

const test = require('node:test');
const assert = require('node:assert/strict');
const { setupDatabase } = require('../scripts/setup-db');
const T = require('../src/utils/time');

let base, server, pool;
const tokens = {};
async function api(method, path, { token, body, raw } = {}) {
  const res = await fetch(base + '/api' + path, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: body ? JSON.stringify(body) : undefined });
  if (raw) return res;
  let data = null; try { data = await res.json(); } catch { /* no body */ }
  return { status: res.status, data };
}
const ids = {};

test.before(async () => {
  await setupDatabase({ demo: false, reset: true, silent: true });
  pool = require('../src/config/db').pool;
  const app = require('../src/app');
  await new Promise((r) => { server = app.listen(0, r); });
  base = `http://127.0.0.1:${server.address().port}`;
});
test.after(async () => { server.close(); await pool.end(); });

test('authentication: wrong password, unknown user and missing token are refused', async () => {
  assert.equal((await api('POST', '/auth/login', { body: { email: 'admin@wams.test', password: 'Wrong@12345' } })).status, 401);
  assert.equal((await api('POST', '/auth/login', { body: { email: 'nobody@wams.test', password: 'Whatever@123' } })).status, 401);
  assert.equal((await api('GET', '/users')).status, 401);
  const r = await api('POST', '/auth/login', { body: { email: 'admin@wams.test', password: 'Admin@12345' } });
  assert.equal(r.status, 200); tokens.admin = r.data.token;
});

test('step 1: admin creates users; worker self-registers and must be activated', async () => {
  const mk = (full_name, email, role, password) => api('POST', '/users', { token: tokens.admin, body: { full_name, email, role, password, phone: '0700111222' } });
  assert.equal((await mk('Test Supervisor', 'sup@t.test', 'supervisor', 'Super@12345')).status, 201);
  assert.equal((await mk('Test Finance', 'fin@t.test', 'finance', 'Finance@12345')).status, 201);
  assert.equal((await mk('Test Worker A', 'a@t.test', 'worker', 'Worker@12345')).status, 201);
  assert.equal((await mk('Test Worker B', 'b@t.test', 'worker', 'Worker@12345')).status, 201);
  assert.equal((await api('POST', '/users', { token: tokens.admin, body: { full_name: 'X', email: 'weak@t.test', role: 'worker', password: 'weak' } })).status, 400);

  const reg = await api('POST', '/auth/register', { body: { full_name: 'Self Registered', email: 'self@t.test', password: 'Worker@12345' } });
  assert.equal(reg.status, 201);
  const early = await api('POST', '/auth/login', { body: { email: 'self@t.test', password: 'Worker@12345' } });
  assert.equal(early.status, 403);                       // pending activation
  const list = await api('GET', '/users?status=pending', { token: tokens.admin });
  const pend = list.data.find((u) => u.email === 'self@t.test');
  assert.equal((await api('PATCH', `/users/${pend.id}/status`, { token: tokens.admin, body: { status: 'active' } })).status, 200);
  assert.equal((await api('POST', '/auth/login', { body: { email: 'self@t.test', password: 'Worker@12345' } })).status, 200);

  for (const [k, e, p] of [['sup', 'sup@t.test', 'Super@12345'], ['fin', 'fin@t.test', 'Finance@12345'], ['a', 'a@t.test', 'Worker@12345'], ['b', 'b@t.test', 'Worker@12345']]) {
    const r = await api('POST', '/auth/login', { body: { email: e, password: p } });
    assert.equal(r.status, 200); tokens[k] = r.data.token; ids[k] = r.data.user.id;
  }
});

test('role restrictions: workers and supervisors cannot use admin or finance functions', async () => {
  assert.equal((await api('GET', '/users', { token: tokens.a })).status, 403);
  assert.equal((await api('POST', '/jobs', { token: tokens.a, body: { title: 'Hack', start_date: T.todayStr() } })).status, 403);
  assert.equal((await api('GET', '/payroll', { token: tokens.sup })).status, 403);
  assert.equal((await api('PUT', '/rules/overtime_multiplier', { token: tokens.sup, body: { value: '3' } })).status, 403);
  assert.equal((await api('GET', '/audit', { token: tokens.fin })).status, 403);
});

test('steps 3-4: supervisor creates job, assigns worker, creates shift', async () => {
  const today = T.todayStr();
  const job = await api('POST', '/jobs', { token: tokens.sup, body: { title: 'Test Bag Loading', location: 'Bay 1', start_date: today } });
  assert.equal(job.status, 201); ids.job = job.data.id;
  const a = await api('POST', '/assignments', { token: tokens.sup, body: { job_id: ids.job, worker_id: ids.a, rate_type: 'hourly', rate: 5000 } });
  assert.equal(a.status, 201); ids.asgA = a.data.id;
  assert.equal((await api('POST', '/assignments', { token: tokens.sup, body: { job_id: ids.job, worker_id: ids.a, rate_type: 'hourly', rate: 5000 } })).status, 409);
  const b = await api('POST', '/assignments', { token: tokens.sup, body: { job_id: ids.job, worker_id: ids.b, rate_type: 'daily', rate: 40000 } });
  assert.equal(b.status, 201); ids.asgB = b.data.id;
  for (const asg of [ids.asgA, ids.asgB]) {
    const s = await api('POST', '/shifts', { token: tokens.sup, body: { assignment_id: asg, shift_date: today, start_time: '00:00', end_time: '23:59' } });
    assert.equal(s.status, 201); assert.equal(s.data.created, 1);
  }
  assert.equal((await api('POST', '/shifts', { token: tokens.sup, body: { assignment_id: ids.asgA, shift_date: '2020-01-01', start_time: '08:00', end_time: '17:00' } })).status, 400);
});

test('steps 5-6: clock in, duplicate clock-in blocked, clock out; clock-out without clock-in blocked', async () => {
  assert.equal((await api('POST', '/attendance/clock-out', { token: tokens.a })).status, 400);
  const cin = await api('POST', '/attendance/clock-in', { token: tokens.a, body: {} });
  assert.equal(cin.status, 201); assert.equal(cin.data.attendance_status, 'In Progress'); assert.ok(cin.data.clock_in);
  ids.att = cin.data.id;
  assert.equal((await api('POST', '/attendance/clock-in', { token: tokens.a, body: {} })).status, 409);
  const cout = await api('POST', '/attendance/clock-out', { token: tokens.a, body: {} });
  assert.equal(cout.status, 200); assert.equal(cout.data.attendance_status, 'Completed'); assert.equal(cout.data.approval_status, 'Pending Approval');
  assert.ok(cout.data.total_hours >= 0);
});

test('workers cannot approve their own attendance or see other workers\' records', async () => {
  assert.equal((await api('PUT', `/attendance/${ids.att}/approve`, { token: tokens.a })).status, 403);
  const mine = await api('GET', '/attendance', { token: tokens.b });
  assert.equal(mine.data.length, 0);
});

test('correction: worker requests, worker cannot decide, supervisor approves; original is kept in the audit trail', async () => {
  const d = T.todayStr();
  const r = await api('POST', '/corrections', { token: tokens.a, body: { attendance_id: ids.att, proposed_clock_in: `${d} 08:00`, proposed_clock_out: `${d} 18:00`, reason: 'Phone was off when I finished' } });
  assert.equal(r.status, 201); ids.corr = r.data.id;
  assert.equal((await api('POST', '/corrections', { token: tokens.a, body: { attendance_id: ids.att, proposed_clock_in: `${d} 08:00`, proposed_clock_out: `${d} 18:00`, reason: 'again again' } })).status, 409);
  assert.equal((await api('PUT', `/corrections/${ids.corr}/decision`, { token: tokens.a, body: { decision: 'approve' } })).status, 403);
  const ok = await api('PUT', `/corrections/${ids.corr}/decision`, { token: tokens.sup, body: { decision: 'approve', note: 'Confirmed on site' } });
  assert.equal(ok.status, 200);
  const att = (await api('GET', '/attendance', { token: tokens.sup })).data.find((x) => x.id === ids.att);
  assert.equal(att.total_hours, 10); assert.equal(att.approval_status, 'Pending Approval');
  const log = (await api('GET', '/audit?action=CORRECTION_APPROVED', { token: tokens.admin })).data;
  assert.ok(log.length >= 1 && JSON.parse(log[0].previous_value).clock_in);
});

test('steps 7-8: supervisor approves, wage engine calculates automatically (10 h x 5,000 with 1.5x overtime = 55,000)', async () => {
  const ap = await api('PUT', `/attendance/${ids.att}/approve`, { token: tokens.sup });
  assert.equal(ap.status, 200); assert.equal(ap.data.approval_status, 'Approved');
  assert.equal((await api('PUT', `/attendance/${ids.att}/approve`, { token: tokens.sup })).status, 409);
  const w = (await api('GET', '/wages', { token: tokens.a })).data;
  assert.equal(w.length, 1);
  assert.equal(w[0].normal_hours, 8); assert.equal(w[0].overtime_hours, 2);
  assert.equal(w[0].basic_pay, 40000); assert.equal(w[0].overtime_pay, 15000); assert.equal(w[0].total_pay, 55000);
});

test('rejection and correction request by supervisor (worker B)', async () => {
  const cin = await api('POST', '/attendance/clock-in', { token: tokens.b, body: {} });
  assert.equal(cin.status, 201);
  assert.equal((await api('POST', '/attendance/clock-out', { token: tokens.b, body: {} })).status, 200);
  const rej = await api('PUT', `/attendance/${cin.data.id}/reject`, { token: tokens.sup, body: { note: 'Not on site' } });
  assert.equal(rej.data.approval_status, 'Rejected');
  assert.equal((await api('PUT', `/attendance/${cin.data.id}/reject`, { token: tokens.sup, body: {} })).status, 400);
  ids.attB = cin.data.id;
});

test('steps 9-11: finance creates payroll, approves, records payment; supervisor cannot; payslip generated', async () => {
  const d = T.todayStr();
  assert.equal((await api('POST', '/payroll', { token: tokens.sup, body: { name: 'x', period_type: 'daily', start_date: d, end_date: d } })).status, 403);
  const p = await api('POST', '/payroll', { token: tokens.fin, body: { name: 'Test Payroll', period_type: 'daily', start_date: d, end_date: d } });
  assert.equal(p.status, 201); assert.equal(p.data.totals.total, 55000); assert.equal(p.data.items.length, 1);
  ids.period = p.data.id; ids.item = p.data.items[0].id;
  assert.equal((await api('POST', '/payroll', { token: tokens.fin, body: { name: 'Again', period_type: 'daily', start_date: d, end_date: d } })).status, 400); // nothing left to include
  const early = await api('POST', '/payments', { token: tokens.fin, body: { payroll_item_id: ids.item, method: 'cash', reference: 'CASH-001', payment_date: d } });
  assert.equal(early.status, 409);                        // payroll not approved yet
  assert.equal((await api('POST', `/payroll/${ids.period}/approve`, { token: tokens.fin })).status, 200);
  assert.equal((await api('POST', '/payments', { token: tokens.sup, body: { payroll_item_id: ids.item, method: 'cash', reference: 'CASH-001', payment_date: d } })).status, 403);
  const pay = await api('POST', '/payments', { token: tokens.fin, body: { payroll_item_id: ids.item, method: 'mobile_money', reference: 'MM-12345', payment_date: d } });
  assert.equal(pay.status, 201); assert.equal(pay.data.amount, 55000); ids.payslip = pay.data.payslip_id;
  assert.equal((await api('POST', '/payments', { token: tokens.fin, body: { payroll_item_id: ids.item, method: 'cash', reference: 'DUP-001', payment_date: d } })).status, 409);
  const closed = await api('GET', `/payroll/${ids.period}`, { token: tokens.fin });
  assert.equal(closed.data.status, 'Closed');
});

test('steps 12-14: worker views and downloads own payslip (PDF); other worker cannot; notifications created', async () => {
  const list = await api('GET', '/payslips', { token: tokens.a });
  assert.equal(list.data.length, 1);
  const pdf = await api('GET', `/payslips/${ids.payslip}/download`, { token: tokens.a, raw: true });
  assert.equal(pdf.status, 200); assert.equal(pdf.headers.get('content-type'), 'application/pdf');
  const buf = Buffer.from(await pdf.arrayBuffer());
  assert.equal(buf.slice(0, 4).toString(), '%PDF'); assert.ok(buf.length > 1500);
  assert.equal((await api('GET', `/payslips/${ids.payslip}`, { token: tokens.b })).status, 403);
  const n = await api('GET', '/notifications', { token: tokens.a });
  assert.ok(n.data.items.some((x) => x.type === 'payment') && n.data.items.some((x) => x.type === 'payslip'));
});

test('QR badge: supervisor scans a worker badge; fake codes are refused', async () => {
  const badge = await api('GET', `/workers/${ids.b}/badge`, { token: tokens.sup });
  assert.equal(badge.status, 200); assert.ok(badge.data.qr.startsWith('data:image/png'));
  assert.equal((await api('POST', '/attendance/scan', { token: tokens.sup, body: { code: 'KCW0099.aaaaaaaaaaaa' } })).status, 400);
  // worker B already has an attendance for today's only shift, so the scan is refused cleanly
  const s = await api('POST', '/attendance/scan', { token: tokens.sup, body: { code: badge.data.token } });
  assert.equal(s.status, 400);
});

test('automation: a past shift with no clock-in is marked absent automatically and alerts are created', async () => {
  const y = T.addDays(T.todayStr(), -1);
  assert.equal((await api('POST', '/shifts', { token: tokens.admin, body: { assignment_id: ids.asgA, shift_date: y, start_time: '08:00', end_time: '17:00' } })).status, 201);
  const run = await api('POST', '/admin/run-automation', { token: tokens.admin });
  assert.equal(run.status, 200); assert.equal(run.data.marked_absent, 1);
  const rows = (await api('GET', `/attendance?status=Absent`, { token: tokens.sup })).data;
  assert.equal(rows.length, 1); assert.equal(rows[0].capture_method, 'system');
  assert.equal((await api('POST', '/admin/run-automation', { token: tokens.admin })).data.marked_absent, 0); // not repeated
});

test('rules: admin can change the overtime multiplier; invalid values are refused', async () => {
  assert.equal((await api('PUT', '/rules/overtime_multiplier', { token: tokens.admin, body: { value: '0.5' } })).status, 400);
  assert.equal((await api('PUT', '/rules/overtime_multiplier', { token: tokens.admin, body: { value: '2' } })).status, 200);
  const rules = (await api('GET', '/rules', { token: tokens.fin })).data;
  assert.equal(rules.find((r) => r.key === 'overtime_multiplier').value, '2');
  await api('PUT', '/rules/overtime_multiplier', { token: tokens.admin, body: { value: '1.5' } });
});

test('step 15-16: reports and dashboards return correct figures', async () => {
  const csv = await api('GET', '/reports/wages?format=csv', { token: tokens.fin, raw: true });
  const text = await csv.text();
  assert.ok(text.includes('Test Worker A') && text.includes('55000'));
  assert.equal((await api('GET', '/reports/wages', { token: tokens.a })).status, 403);
  const dash = await api('GET', '/dashboard', { token: tokens.fin });
  assert.equal(dash.data.paid_wages, 55000); assert.equal(dash.data.unpaid_wages, 0);
  const adash = await api('GET', '/dashboard', { token: tokens.admin });
  assert.equal(adash.data.workers, 3); assert.equal(adash.data.supervisors, 1);
  assert.equal((await api('GET', '/dashboard', { token: tokens.a })).data.recent_payments.length, 1);
});

test('step 17: audit trail has the important actions and cannot be edited or deleted', async () => {
  const actions = (await api('GET', '/audit/actions', { token: tokens.admin })).data;
  for (const a of ['LOGIN', 'LOGIN_FAILED', 'USER_CREATED', 'WORKER_ASSIGNED', 'CLOCK_IN', 'CLOCK_OUT', 'ATTENDANCE_APPROVED', 'ATTENDANCE_REJECTED', 'CORRECTION_APPROVED', 'WAGE_CALCULATED', 'PAYROLL_CREATED', 'PAYMENT_RECORDED', 'PAYSLIP_GENERATED']) {
    assert.ok(actions.includes(a), 'missing audit action ' + a);
  }
  await assert.rejects(() => pool.query("UPDATE audit_logs SET action = 'HACKED' WHERE id = 1"), /read-only/);
  await assert.rejects(() => pool.query('DELETE FROM audit_logs WHERE id = 1'), /read-only/);
  const susp = await api('GET', '/audit/suspicious', { token: tokens.admin });
  assert.equal(susp.status, 200);
});

test('security: logout revokes the token; accounts lock after repeated failed logins; passwords are hashed', async () => {
  const r = await api('POST', '/auth/login', { body: { email: 'b@t.test', password: 'Worker@12345' } });
  const tk = r.data.token;
  assert.equal((await api('GET', '/auth/me', { token: tk })).status, 200);
  assert.equal((await api('POST', '/auth/logout', { token: tk })).status, 200);
  assert.equal((await api('GET', '/auth/me', { token: tk })).status, 401);
  for (let i = 0; i < 5; i++) await api('POST', '/auth/login', { body: { email: 'a@t.test', password: 'Nope@12345' } });
  assert.equal((await api('POST', '/auth/login', { body: { email: 'a@t.test', password: 'Worker@12345' } })).status, 429);
  const [rows] = await pool.query("SELECT password_hash FROM users WHERE email = 'a@t.test'");
  assert.ok(rows[0].password_hash.startsWith('$2'));
  // SQL injection attempt is treated as plain text
  assert.equal((await api('POST', '/auth/login', { body: { email: "x' OR '1'='1", password: 'x' } })).status, 400);
});
