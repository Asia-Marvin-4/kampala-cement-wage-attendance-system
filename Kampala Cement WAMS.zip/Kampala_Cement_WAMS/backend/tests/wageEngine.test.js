// Wage engine tests with known expected answers (no database needed).
const test = require('node:test');
const assert = require('node:assert/strict');
const { calculateWage } = require('../src/services/wageEngine');

const rules = { normal_hours_per_day: 8, overtime_multiplier: 1.5, daily_min_hours: 4 };
const calc = (rateType, rate, totalHours, r = rules) => calculateWage({ rateType, rate, totalHours, rules: r });

test('hourly: 8 hours x UGX 5,000 = UGX 40,000', () => {
  const w = calc('hourly', 5000, 8);
  assert.equal(w.basic_pay, 40000); assert.equal(w.overtime_pay, 0); assert.equal(w.total_pay, 40000);
  assert.equal(w.normal_hours, 8); assert.equal(w.overtime_hours, 0);
});
test('hourly: 10 hours = 8 normal + 2 overtime at 1.5x', () => {
  const w = calc('hourly', 5000, 10);
  assert.equal(w.normal_hours, 8); assert.equal(w.overtime_hours, 2);
  assert.equal(w.basic_pay, 40000); assert.equal(w.overtime_pay, 15000); assert.equal(w.total_pay, 55000);
});
test('hourly: part hours (6.5 h x 4,000 = 26,000)', () => {
  assert.equal(calc('hourly', 4000, 6.5).total_pay, 26000);
});
test('hourly: different rate and multiplier (9 h, rate 6,000, x2 overtime)', () => {
  const w = calc('hourly', 6000, 9, { ...rules, overtime_multiplier: 2 });
  assert.equal(w.basic_pay, 48000); assert.equal(w.overtime_pay, 12000); assert.equal(w.total_pay, 60000);
});
test('hourly: different normal hours rule (normal day = 6 h)', () => {
  const w = calc('hourly', 5000, 8, { ...rules, normal_hours_per_day: 6 });
  assert.equal(w.normal_hours, 6); assert.equal(w.overtime_hours, 2);
  assert.equal(w.total_pay, 30000 + 15000);
});
test('daily: a full day earns the daily rate (UGX 30,000)', () => {
  const w = calc('daily', 30000, 8);
  assert.equal(w.basic_pay, 30000); assert.equal(w.overtime_pay, 0); assert.equal(w.total_pay, 30000);
});
test('daily: 5 days x UGX 30,000 = UGX 150,000', () => {
  let t = 0; for (let i = 0; i < 5; i++) t += calc('daily', 30000, 8).total_pay;
  assert.equal(t, 150000);
});
test('daily: 4 hours or more still earns the full day rate', () => {
  assert.equal(calc('daily', 40000, 4).basic_pay, 40000);
});
test('daily: under the minimum hours is paid proportionally (2 h of 8 = 10,000)', () => {
  assert.equal(calc('daily', 40000, 2).basic_pay, 10000);
});
test('daily: overtime uses daily rate / normal hours (10 h, 40,000/day)', () => {
  const w = calc('daily', 40000, 10);
  assert.equal(w.overtime_hours, 2); assert.equal(w.overtime_pay, 2 * 5000 * 1.5); assert.equal(w.total_pay, 55000);
});
test('rounding to the nearest whole shilling', () => {
  const w = calc('daily', 10000, 9);          // OT = 1 h x (10000/8) x 1.5 = 1875
  assert.equal(w.overtime_pay, 1875);
  const w2 = calc('hourly', 3333, 8.33);      // 8 x 3333 = 26664 ; OT 0.33 x 3333 x 1.5 = 1649.835 -> 1650
  assert.equal(w2.overtime_pay, 1650);
  assert.equal(w2.total_pay, 26664 + 1650);
});
test('zero hours gives zero pay', () => {
  assert.equal(calc('hourly', 5000, 0).total_pay, 0);
});
test('invalid values are refused', () => {
  assert.throws(() => calc('hourly', -1, 8));
  assert.throws(() => calc('hourly', 5000, -2));
  assert.throws(() => calc('hourly', 5000, 25));
  assert.throws(() => calc('weekly', 5000, 8));
  assert.throws(() => calc('hourly', 'abc', 8));
  assert.throws(() => calc('hourly', 5000, 8, { ...rules, overtime_multiplier: 0.5 }));
});
test('payroll total equals the sum of its shifts', () => {
  const shifts = [8, 10, 7.5, 9];
  const total = shifts.reduce((s, h) => s + calc('hourly', 5000, h).total_pay, 0);
  assert.equal(total, 40000 + 55000 + 37500 + (40000 + 1 * 5000 * 1.5));
});
