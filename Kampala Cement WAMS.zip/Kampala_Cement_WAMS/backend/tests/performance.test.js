// Measures real response times on a larger data set (200 workers x 5 shifts = 1,000 approved shifts).
// Target from the project plan: normal payroll updates respond within about 2 seconds.
process.env.DB_NAME = 'kc_wams_perf';
process.env.NODE_ENV = 'test';
process.env.AUTOMATION_ENABLED = 'false';

const test = require('node:test');
const assert = require('node:assert/strict');
const bcrypt = require('bcryptjs');
const { setupDatabase } = require('../scripts/setup-db');
const T = require('../src/utils/time');

let base, server, pool, token;
async function timed(method, path, body) {
  const t0 = performance.now();
  const res = await fetch(base + '/api' + path, { method, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token }, body: body ? JSON.stringify(body) : undefined });
  const ms = performance.now() - t0;
  const data = await res.json().catch(() => null);
  return { status: res.status, ms, data };
}
const results = [];

test.before(async () => {
  await setupDatabase({ demo: false, reset: true, silent: true });
  pool = require('../src/config/db').pool;
  const hash = await bcrypt.hash('Test@12345', 4);
  await pool.query("INSERT INTO users (full_name,email,password_hash,role,status) VALUES ('Perf Finance','pf@t.test',?, 'finance','active'),('Perf Supervisor','ps@t.test',?, 'supervisor','active')", [hash, hash]);
  const [[sup]] = await pool.query("SELECT id FROM users WHERE email='ps@t.test'");
  const [job] = await pool.query("INSERT INTO jobs (title,start_date,created_by) VALUES ('Perf job', ?, ?)", [T.addDays(T.todayStr(), -10), sup.id]);
  const today = T.todayStr();
  for (let i = 1; i <= 200; i++) {
    const [u] = await pool.query("INSERT INTO users (full_name,email,password_hash,role,status) VALUES (?,?,?,'worker','active')", ['Perf Worker ' + i, `pw${i}@t.test`, hash]);
    await pool.query('INSERT INTO worker_profiles (user_id, worker_code) VALUES (?,?)', [u.insertId, 'KCP' + String(i).padStart(4, '0')]);
    const [a] = await pool.query("INSERT INTO assignments (job_id,worker_id,rate_type,rate,assigned_by) VALUES (?,?,'hourly',5000,?)", [job.insertId, u.insertId, sup.id]);
    for (let d = 1; d <= 5; d++) {
      const day = T.addDays(today, -d);
      const [s] = await pool.query("INSERT INTO shifts (assignment_id,shift_date,start_time,end_time,created_by) VALUES (?,?,'08:00:00','17:00:00',?)", [a.insertId, day, sup.id]);
      const [att] = await pool.query("INSERT INTO attendance (worker_id,assignment_id,shift_id,work_date,clock_in,clock_out,total_hours,attendance_status,approval_status,approved_by,approved_at) VALUES (?,?,?,?,?,?,9,'Completed','Approved',?,?)", [u.insertId, a.insertId, s.insertId, day, day + ' 08:00:00', day + ' 17:00:00', sup.id, day + ' 18:00:00']);
      await pool.query("INSERT INTO wage_calculations (attendance_id,worker_id,assignment_id,work_date,rate_type,rate,total_hours,normal_hours,overtime_hours,overtime_multiplier,basic_pay,overtime_pay,total_pay) VALUES (?,?,?,?, 'hourly',5000,9,8,1,1.5,40000,7500,47500)", [att.insertId, u.insertId, a.insertId, day]);
    }
  }
  const app = require('../src/app');
  await new Promise((r) => { server = app.listen(0, r); });
  base = `http://127.0.0.1:${server.address().port}`;
  const res = await fetch(base + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'pf@t.test', password: 'Test@12345' }) });
  token = (await res.json()).token;
});
test.after(async () => {
  console.log('\nPERFORMANCE RESULTS (milliseconds)'); for (const r of results) console.log(`  ${r.name}: ${r.ms.toFixed(0)} ms`);
  server.close(); await pool.end();
});

test('payroll creation for 200 workers / 1,000 shifts responds within 2 seconds', async () => {
  const d = T.todayStr();
  const r = await timed('POST', '/payroll', { name: 'Perf payroll', period_type: 'weekly', start_date: T.addDays(d, -7), end_date: d });
  results.push({ name: 'Create payroll (200 workers, 1,000 shifts)', ms: r.ms });
  assert.equal(r.status, 201); assert.equal(r.data.totals.workers, 200); assert.equal(r.data.totals.total, 200 * 5 * 47500);
  assert.ok(r.ms < 2000, `took ${r.ms} ms`);
  token = token; globalThis.periodId = r.data.id;
});
test('payroll approval, listing, wages, dashboard and report endpoints respond within 2 seconds', async () => {
  const checks = [['Approve payroll', 'POST', `/payroll/${globalThis.periodId}/approve`], ['Open payroll detail', 'GET', `/payroll/${globalThis.periodId}`], ['List wages (500 rows)', 'GET', '/wages'],
    ['Finance dashboard', 'GET', '/dashboard'], ['Payroll CSV report', 'GET', `/reports/payroll/${globalThis.periodId}`]];
  for (const [name, m, p] of checks) {
    const r = await timed(m, p); results.push({ name, ms: r.ms });
    assert.ok(r.status < 300, `${name} returned ${r.status}`); assert.ok(r.ms < 2000, `${name} took ${r.ms} ms`);
  }
});
test('recording a payment responds within 2 seconds', async () => {
  const detail = (await timed('GET', `/payroll/${globalThis.periodId}`)).data;
  const times = [];
  for (const item of detail.items.slice(0, 10)) {
    const r = await timed('POST', '/payments', { payroll_item_id: item.id, method: 'cash', reference: 'PERF-' + item.id, payment_date: T.todayStr() });
    assert.equal(r.status, 201); times.push(r.ms);
  }
  const avg = times.reduce((a, b) => a + b, 0) / times.length;
  results.push({ name: 'Record one payment (average of 10)', ms: avg });
  assert.ok(Math.max(...times) < 2000);
});
