const env = require('./config/env');
const { pool } = require('./config/db');
const app = require('./app');
const { startScheduler } = require('./services/scheduler');

async function main() {
  try {
    await pool.query('SELECT 1');
  } catch (e) {
    console.error('\nCould not connect to the database:', e.message);
    console.error('Check that MySQL is running and that DB_USER / DB_PASSWORD / DB_NAME in backend/.env are correct.');
    console.error('Then run: npm run setup-db\n');
    process.exit(1);
  }
  try { await pool.query('SELECT 1 FROM users LIMIT 1'); }
  catch { console.error('\nThe database tables do not exist yet. Run: npm run setup-db\n'); process.exit(1); }

  app.listen(env.PORT, () => {
    console.log(`\nDigital Wage & Attendance System running at http://localhost:${env.PORT}\n`);
    startScheduler();
  });
}
main();
