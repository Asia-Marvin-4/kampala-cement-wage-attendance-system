const { validationResult } = require('express-validator');
const { HttpError } = require('../utils/httpError');

function handleValidation(req, res, next) {
  const errors = validationResult(req);
  if (errors.isEmpty()) return next();
  const details = errors.array().map((e) => ({ field: e.path, message: e.msg }));
  next(new HttpError(400, details[0].message, details));
}

const PASSWORD_MESSAGE = 'Password must be at least 8 characters and include an uppercase letter, a lowercase letter and a number.';
function strongPassword(p) { return typeof p === 'string' && p.length >= 8 && p.length <= 72 && /[A-Z]/.test(p) && /[a-z]/.test(p) && /\d/.test(p); }

module.exports = { handleValidation, strongPassword, PASSWORD_MESSAGE };
