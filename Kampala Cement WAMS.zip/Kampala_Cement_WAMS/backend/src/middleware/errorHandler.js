const { HttpError } = require('../utils/httpError');

function notFoundHandler(req, res, next) {
  if (req.path.startsWith('/api/')) return next(new HttpError(404, 'API route not found.'));
  res.status(404).send('Page not found');
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message, details: err.details });
  if (err && err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'That record already exists.' });
  if (err && err.type === 'entity.parse.failed') return res.status(400).json({ error: 'The request body is not valid JSON.' });
  console.error('[error]', err);
  res.status(500).json({ error: 'Something went wrong on the server. Please try again.' });
}
module.exports = { notFoundHandler, errorHandler };
