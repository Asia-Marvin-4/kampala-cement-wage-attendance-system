const jwt = require('jsonwebtoken');
const env = require('../config/env');
const { query } = require('../config/db');
const { HttpError } = require('../utils/httpError');

async function authenticate(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) throw new HttpError(401, 'Please log in.');
    let payload;
    try { payload = jwt.verify(token, env.JWT_SECRET); }
    catch { throw new HttpError(401, 'Your session has expired. Please log in again.'); }
    const revoked = await query('SELECT jti FROM revoked_tokens WHERE jti = ?', [payload.jti]);
    if (revoked.length) throw new HttpError(401, 'You have logged out. Please log in again.');
    const rows = await query('SELECT id, full_name, email, phone, role, status FROM users WHERE id = ?', [payload.sub]);
    const u = rows[0];
    if (!u || u.status !== 'active') throw new HttpError(401, 'This account is not active.');
    req.user = { ...u, jti: payload.jti, exp: payload.exp };
    next();
  } catch (e) { next(e); }
}

// Role-based access control: allow only the listed roles
const authorize = (...roles) => (req, res, next) => {
  if (!req.user) return next(new HttpError(401, 'Please log in.'));
  if (!roles.includes(req.user.role)) return next(new HttpError(403, 'Your role is not allowed to do this.'));
  next();
};

module.exports = { authenticate, authorize };
