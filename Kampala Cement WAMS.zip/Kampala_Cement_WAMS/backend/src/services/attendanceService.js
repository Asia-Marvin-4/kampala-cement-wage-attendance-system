const { pool, query, tx } = require('../config/db');
const { getRules } = require('./rules');
const { calculateWage } = require('./wageEngine');
const { notify } = require('./notificationService');
const { audit } = require('../utils/audit');
const { bad, forbidden, notFound, conflict } = require('../utils/httpError');
const T = require('../utils/time');
const badge = require('./badge');

function distanceMetres(lat1, lng1, lat2, lng2) {
  const R = 6371000, rad = (d) => (d * Math.PI) / 180;
  const dLat = rad(lat2 - lat1), dLng = rad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}
function locationFlag(rules, lat, lng) {
  const wl = Number(rules.worksite_lat), wn = Number(rules.worksite_lng);
  if (rules.worksite_lat === '' || rules.worksite_lng === '' || !Number.isFinite(wl) || !Number.isFinite(wn)) return 0;
  if (lat == null || lng == null || !Number.isFinite(Number(lat)) || !Number.isFinite(Number(lng))) return 0;
  return distanceMetres(Number(lat), Number(lng), wl, wn) > Number(rules.worksite_radius_m || 500) ? 1 : 0;
}
const numOrNull = (v) => (v === undefined || v === null || v === '' || !Number.isFinite(Number(v)) ? null : Number(v));

const ATT_SELECT = `
  SELECT att.*, w.full_name AS worker_name, wp.worker_code, j.id AS job_id, j.title AS job_title, j.created_by AS job_owner,
         a.rate_type, a.rate, s.start_time AS shift_start, s.end_time AS shift_end,
         ap.full_name AS approved_by_name, wc.total_pay, wc.payroll_item_id
  FROM attendance att
  JOIN users w ON w.id = att.worker_id
  LEFT JOIN worker_profiles wp ON wp.user_id = w.id
  JOIN assignments a ON a.id = att.assignment_id
  JOIN jobs j ON j.id = a.job_id
  JOIN shifts s ON s.id = att.shift_id
  LEFT JOIN users ap ON ap.id = att.approved_by
  LEFT JOIN wage_calculations wc ON wc.attendance_id = att.id`;

async function getAttendance(id, conn = pool) {
  const rows = await query(ATT_SELECT + ' WHERE att.id = ?', [id], conn);
  if (!rows.length) throw notFound('Attendance record not found.');
  return rows[0];
}
function assertCanManage(user, att) {
  if (user.role === 'admin') return;
  if (user.role === 'supervisor' && att.job_owner === user.id) return;
  throw forbidden('This attendance belongs to a job you do not supervise.');
}

// ---------- Clock in / clock out ----------
async function clockIn({ workerId, lat, lng, method = 'self', req, actor }) {
  const rules = await getRules();
  const now = T.nowStr(), today = T.todayStr();

  const open = await query("SELECT id FROM attendance WHERE worker_id = ? AND attendance_status = 'In Progress' LIMIT 1", [workerId]);
  if (open.length) throw conflict('You are already clocked in. Clock out first.');

  const shifts = await query(
    `SELECT s.*, a.id AS aid, j.title FROM shifts s
     JOIN assignments a ON a.id = s.assignment_id
     JOIN jobs j ON j.id = a.job_id
     WHERE a.worker_id = ? AND a.status = 'active' AND j.status = 'active' AND s.shift_date = ?
       AND NOT EXISTS (SELECT 1 FROM attendance t WHERE t.shift_id = s.id)
     ORDER BY s.start_time`, [workerId, today]);
  if (!shifts.length) throw bad('There is no open shift for you today. Ask your supervisor to schedule one.');

  let chosen = null, tooEarly = null;
  for (const s of shifts) {
    const start = T.combine(s.shift_date, s.start_time), end = T.combine(s.shift_date, s.end_time);
    if (now < T.addMinutes(start, -rules.early_clockin_minutes)) { tooEarly = tooEarly || s; continue; }
    if (now > end) continue;
    chosen = s; break;
  }
  if (!chosen) {
    if (tooEarly) throw bad(`Too early to clock in. Your shift starts at ${String(tooEarly.start_time).slice(0, 5)}.`);
    throw bad('Your shift has already ended. Ask your supervisor to create a correction.');
  }

  const start = T.combine(chosen.shift_date, chosen.start_time);
  const isLate = now > T.addMinutes(start, rules.late_grace_minutes) ? 1 : 0;
  const flag = locationFlag(rules, lat, lng);
  const [res] = await pool.query(
    `INSERT INTO attendance (worker_id, assignment_id, shift_id, work_date, clock_in, attendance_status, is_late, approval_status, in_lat, in_lng, location_flag, capture_method)
     VALUES (?,?,?,?,?, 'In Progress', ?, 'Pending Approval', ?,?,?,?)`,
    [workerId, chosen.aid, chosen.id, today, now, isLate, numOrNull(lat), numOrNull(lng), flag, method]);
  await audit({ req, userId: actor?.id ?? workerId, action: 'CLOCK_IN', entity: 'attendance', entityId: res.insertId, next: { worker_id: workerId, clock_in: now, late: !!isLate, method, location_flag: !!flag } });
  await notify(workerId, 'clock_in', `Clock-in recorded at ${now.slice(11, 16)}${isLate ? ' (late)' : ''}.`);
  return getAttendance(res.insertId);
}

async function clockOut({ workerId, lat, lng, method = 'self', req, actor }) {
  const rules = await getRules();
  const rows = await query("SELECT * FROM attendance WHERE worker_id = ? AND attendance_status = 'In Progress' ORDER BY id DESC LIMIT 1", [workerId]);
  if (!rows.length) throw bad('You have not clocked in, so there is nothing to clock out of.');
  const att = rows[0], now = T.nowStr();
  const hours = T.hoursBetween(att.clock_in, now);
  if (hours < 0) throw bad('Clock-out time is before clock-in time.');
  if (hours > 24) throw bad('This shift is longer than 24 hours. Ask your supervisor to correct it.');
  const flag = att.location_flag || locationFlag(rules, lat, lng);
  await pool.query(
    `UPDATE attendance SET clock_out = ?, total_hours = ?, attendance_status = 'Completed', approval_status = 'Pending Approval',
       out_lat = ?, out_lng = ?, location_flag = ? WHERE id = ?`,
    [now, hours, numOrNull(lat), numOrNull(lng), flag, att.id]);
  await audit({ req, userId: actor?.id ?? workerId, action: 'CLOCK_OUT', entity: 'attendance', entityId: att.id, previous: { clock_out: null }, next: { clock_out: now, total_hours: hours, method } });
  await notify(workerId, 'clock_out', `Clock-out recorded at ${now.slice(11, 16)}. Hours worked: ${hours}. Waiting for supervisor approval.`);
  const full = await getAttendance(att.id);
  await notify(full.job_owner, 'approval_needed', `${full.worker_name} finished a shift (${hours} h). Attendance is waiting for your approval.`, { dedupeKey: `appr:${att.id}:${now}` });
  return full;
}

// Supervisor scans a worker's QR badge: clocks in, or out if already clocked in.
async function scanBadge({ token, lat, lng, req, actor }) {
  const code = badge.readToken(token);
  if (!code) throw bad('This QR code is not valid.');
  const rows = await query("SELECT u.id, u.status, u.full_name FROM users u JOIN worker_profiles wp ON wp.user_id = u.id WHERE wp.worker_code = ? AND u.role = 'worker'", [code]);
  if (!rows.length) throw notFound('No worker matches this badge.');
  if (rows[0].status !== 'active') throw forbidden('This worker account is not active.');
  const workerId = rows[0].id;
  const open = await query("SELECT id FROM attendance WHERE worker_id = ? AND attendance_status = 'In Progress' LIMIT 1", [workerId]);
  const action = open.length ? 'clock-out' : 'clock-in';
  const attendance = open.length
    ? await clockOut({ workerId, lat, lng, method: 'qr', req, actor })
    : await clockIn({ workerId, lat, lng, method: 'qr', req, actor });
  return { action, worker: rows[0].full_name, attendance };
}

// ---------- Review: approve / reject / ask for correction ----------
async function approve(id, user, req) {
  const result = await tx(async (conn) => {
    const rows = await query(ATT_SELECT + ' WHERE att.id = ? FOR UPDATE', [id], conn);
    if (!rows.length) throw notFound('Attendance record not found.');
    const att = rows[0];
    assertCanManage(user, att);
    if (att.attendance_status !== 'Completed' || !att.clock_out) throw bad('Only completed attendance (with a clock-out) can be approved. Use a correction for missing times.');
    if (att.approval_status !== 'Pending Approval') throw conflict(`This record is already: ${att.approval_status}.`);
    const now = T.nowStr();
    await conn.query("UPDATE attendance SET approval_status = 'Approved', approved_by = ?, approved_at = ?, supervisor_note = NULL WHERE id = ?", [user.id, now, id]);
    const rules = await getRules(conn);
    const w = calculateWage({ rateType: att.rate_type, rate: att.rate, totalHours: att.total_hours, rules });
    const [wc] = await conn.query(
      `INSERT INTO wage_calculations (attendance_id, worker_id, assignment_id, work_date, rate_type, rate, total_hours, normal_hours, overtime_hours, overtime_multiplier, basic_pay, overtime_pay, total_pay)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [id, att.worker_id, att.assignment_id, att.work_date, w.rate_type, w.rate, w.total_hours, w.normal_hours, w.overtime_hours, w.overtime_multiplier, w.basic_pay, w.overtime_pay, w.total_pay]);
    await audit({ req, userId: user.id, action: 'ATTENDANCE_APPROVED', entity: 'attendance', entityId: id, previous: { approval_status: att.approval_status }, next: { approval_status: 'Approved' }, conn });
    await audit({ req, userId: user.id, action: 'WAGE_CALCULATED', entity: 'wage_calculation', entityId: wc.insertId, next: w, conn });
    return { att, wage: w };
  });
  await notify(result.att.worker_id, 'attendance_approved', `Your attendance for ${result.att.work_date} was approved. Wage calculated: UGX ${result.wage.total_pay.toLocaleString('en-US')}.`, { sms: true });
  return getAttendance(id);
}

async function reviewNote(id, user, req, newStatus, note, action) {
  const att = await getAttendance(id);
  assertCanManage(user, att);
  if (!note || note.trim().length < 3) throw bad('Please write a short reason (at least 3 characters).');
  if (att.approval_status !== 'Pending Approval') throw conflict(`This record is already: ${att.approval_status}.`);
  await pool.query('UPDATE attendance SET approval_status = ?, supervisor_note = ?, approved_by = ?, approved_at = ? WHERE id = ?', [newStatus, note.trim().slice(0, 250), user.id, T.nowStr(), id]);
  await audit({ req, userId: user.id, action, entity: 'attendance', entityId: id, previous: { approval_status: att.approval_status }, next: { approval_status: newStatus, note } });
  const msg = newStatus === 'Rejected'
    ? `Your attendance for ${att.work_date} was rejected: ${note.trim()}`
    : `Your supervisor asked for a correction on ${att.work_date}: ${note.trim()}`;
  await notify(att.worker_id, newStatus === 'Rejected' ? 'attendance_rejected' : 'correction_requested', msg, { sms: true });
  return getAttendance(id);
}
const reject = (id, user, req, note) => reviewNote(id, user, req, 'Rejected', note, 'ATTENDANCE_REJECTED');
const requestCorrection = (id, user, req, note) => reviewNote(id, user, req, 'Correction Requested', note, 'ATTENDANCE_CORRECTION_REQUESTED');

// ---------- Corrections (history is never overwritten without a trail) ----------
async function createCorrection(user, req, { attendance_id, proposed_clock_in, proposed_clock_out, reason }) {
  const att = await getAttendance(attendance_id);
  if (user.role === 'worker' && att.worker_id !== user.id) throw forbidden('You can only request corrections for your own attendance.');
  if (user.role === 'supervisor') assertCanManage(user, att);
  if (!reason || reason.trim().length < 5) throw bad('Please give a reason (at least 5 characters).');
  if (!T.isValidDateTime(proposed_clock_in) || !T.isValidDateTime(proposed_clock_out)) throw bad('Please give valid clock-in and clock-out times.');
  const pin = T.normalizeDateTime(proposed_clock_in), pout = T.normalizeDateTime(proposed_clock_out);
  if (pin.slice(0, 10) !== att.work_date) throw bad('The corrected clock-in must be on the shift date.');
  const hours = T.hoursBetween(pin, pout);
  if (hours <= 0) throw bad('Clock-out must be after clock-in.');
  if (hours > 24) throw bad('A shift cannot be longer than 24 hours.');
  if (att.payroll_item_id) throw conflict('This attendance is already included in payroll and cannot be corrected.');
  if (att.attendance_status === 'In Progress') throw conflict('The worker is still clocked in. Clock out first, or wait for the missed clock-out check.');
  const pend = await query("SELECT id FROM attendance_corrections WHERE attendance_id = ? AND status = 'pending'", [attendance_id]);
  if (pend.length) throw conflict('There is already a pending correction request for this record.');
  const [r] = await pool.query(
    `INSERT INTO attendance_corrections (attendance_id, requested_by, original_clock_in, original_clock_out, proposed_clock_in, proposed_clock_out, reason)
     VALUES (?,?,?,?,?,?,?)`, [attendance_id, user.id, att.clock_in, att.clock_out, pin, pout, reason.trim().slice(0, 250)]);
  await audit({ req, userId: user.id, action: 'CORRECTION_REQUESTED', entity: 'attendance_corrections', entityId: r.insertId, previous: { clock_in: att.clock_in, clock_out: att.clock_out }, next: { clock_in: pin, clock_out: pout, reason } });
  if (user.role === 'worker') await notify(att.job_owner, 'correction_review', `${att.worker_name} requested a correction for ${att.work_date}.`);
  return { id: r.insertId };
}

async function decideCorrection(id, user, req, decision, note) {
  const corr = (await query('SELECT * FROM attendance_corrections WHERE id = ?', [id]))[0];
  if (!corr) throw notFound('Correction request not found.');
  if (corr.status !== 'pending') throw conflict('This request has already been decided.');
  const att = await getAttendance(corr.attendance_id);
  const requester = (await query('SELECT role FROM users WHERE id = ?', [corr.requested_by]))[0];
  if (corr.requested_by === user.id) throw forbidden('You cannot approve your own correction request.');
  if (user.role === 'supervisor') {
    assertCanManage(user, att);
    if (requester?.role === 'supervisor') throw forbidden('Corrections requested by a supervisor must be reviewed by an administrator.');
  } else if (user.role !== 'admin') throw forbidden();
  if (!['approve', 'reject'].includes(decision)) throw bad('Decision must be approve or reject.');
  if (decision === 'reject' && (!note || note.trim().length < 3)) throw bad('Please give a reason for rejecting.');

  await tx(async (conn) => {
    const now = T.nowStr();
    if (decision === 'reject') {
      await conn.query("UPDATE attendance_corrections SET status='rejected', reviewed_by=?, reviewed_at=?, review_note=? WHERE id=?", [user.id, now, (note || '').slice(0, 250), id]);
      await audit({ req, userId: user.id, action: 'CORRECTION_REJECTED', entity: 'attendance_corrections', entityId: id, next: { note }, conn });
      return;
    }
    const locked = await query('SELECT payroll_item_id FROM wage_calculations WHERE attendance_id = ?', [att.id], conn);
    if (locked.length && locked[0].payroll_item_id) throw conflict('This attendance is already in payroll and cannot be changed.');
    const hours = T.hoursBetween(corr.proposed_clock_in, corr.proposed_clock_out);
    const rules = await getRules(conn);
    const start = T.combine(att.work_date, att.shift_start);
    const late = corr.proposed_clock_in > T.addMinutes(start, rules.late_grace_minutes) ? 1 : 0;
    await conn.query(
      `UPDATE attendance SET clock_in=?, clock_out=?, total_hours=?, attendance_status='Completed', is_late=?, approval_status='Pending Approval',
         approved_by=NULL, approved_at=NULL, supervisor_note=NULL WHERE id=?`, [corr.proposed_clock_in, corr.proposed_clock_out, hours, late, att.id]);
    if (locked.length) await conn.query('DELETE FROM wage_calculations WHERE attendance_id = ?', [att.id]);
    await conn.query("UPDATE attendance_corrections SET status='approved', reviewed_by=?, reviewed_at=?, review_note=? WHERE id=?", [user.id, now, (note || '').slice(0, 250), id]);
    await audit({ req, userId: user.id, action: 'CORRECTION_APPROVED', entity: 'attendance', entityId: att.id,
      previous: { clock_in: corr.original_clock_in, clock_out: corr.original_clock_out, approval_status: att.approval_status },
      next: { clock_in: corr.proposed_clock_in, clock_out: corr.proposed_clock_out, total_hours: hours, approval_status: 'Pending Approval' }, conn });
  });
  await notify(att.worker_id, 'correction_decision', `Your correction request for ${att.work_date} was ${decision === 'approve' ? 'approved. Attendance is waiting for re-approval' : 'rejected'}.`);
  return { ok: true };
}

module.exports = { ATT_SELECT, getAttendance, assertCanManage, clockIn, clockOut, scanBadge, approve, reject, requestCorrection, createCorrection, decideCorrection };
