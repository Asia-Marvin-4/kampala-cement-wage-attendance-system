const { pool, query, tx } = require('../config/db');
const { notify } = require('./notificationService');
const { audit } = require('../utils/audit');
const { bad, notFound, conflict } = require('../utils/httpError');
const T = require('../utils/time');

async function createPeriod(user, req, { name, period_type, start_date, end_date }) {
  if (!name || name.trim().length < 3) throw bad('Give the payroll period a name.');
  if (!['daily', 'weekly', 'biweekly', 'monthly'].includes(period_type)) throw bad('Choose a valid period type.');
  if (!T.isValidDate(start_date) || !T.isValidDate(end_date)) throw bad('Please give valid start and end dates.');
  if (end_date < start_date) throw bad('End date cannot be before the start date.');

  const id = await tx(async (conn) => {
    const groups = await query(
      `SELECT worker_id, COUNT(DISTINCT work_date) AS days, SUM(total_hours) AS hours, SUM(basic_pay) AS normal_pay,
              SUM(overtime_pay) AS overtime_pay, SUM(total_pay) AS total_pay
       FROM wage_calculations WHERE payroll_item_id IS NULL AND work_date BETWEEN ? AND ? GROUP BY worker_id FOR UPDATE`,
      [start_date, end_date], conn);
    if (!groups.length) throw bad('There are no approved, unpaid wages in this date range.');
    const [p] = await conn.query('INSERT INTO payroll_periods (name, period_type, start_date, end_date, created_by) VALUES (?,?,?,?,?)', [name.trim(), period_type, start_date, end_date, user.id]);
    for (const g of groups) {
      const [it] = await conn.query(
        'INSERT INTO payroll_items (period_id, worker_id, days_worked, total_hours, normal_pay, overtime_pay, total_pay) VALUES (?,?,?,?,?,?,?)',
        [p.insertId, g.worker_id, g.days, g.hours, g.normal_pay, g.overtime_pay, g.total_pay]);
      await conn.query('UPDATE wage_calculations SET payroll_item_id = ? WHERE payroll_item_id IS NULL AND worker_id = ? AND work_date BETWEEN ? AND ?', [it.insertId, g.worker_id, start_date, end_date]);
    }
    await audit({ req, userId: user.id, action: 'PAYROLL_CREATED', entity: 'payroll_periods', entityId: p.insertId, next: { name, period_type, start_date, end_date, workers: groups.length }, conn });
    return p.insertId;
  });
  return getPeriod(id);
}

async function getPeriod(id) {
  const p = (await query(
    `SELECT pp.*, cu.full_name AS created_by_name, au.full_name AS approved_by_name FROM payroll_periods pp
     JOIN users cu ON cu.id = pp.created_by LEFT JOIN users au ON au.id = pp.approved_by WHERE pp.id = ?`, [id]))[0];
  if (!p) throw notFound('Payroll period not found.');
  const items = await query(
    `SELECT pi.*, u.full_name AS worker_name, wp.worker_code, pay.reference, pay.payment_date, pay.method, ps.id AS payslip_id, ps.payslip_no
     FROM payroll_items pi JOIN users u ON u.id = pi.worker_id LEFT JOIN worker_profiles wp ON wp.user_id = u.id
     LEFT JOIN payments pay ON pay.payroll_item_id = pi.id LEFT JOIN payslips ps ON ps.payroll_item_id = pi.id
     WHERE pi.period_id = ? ORDER BY u.full_name`, [id]);
  p.items = items;
  p.totals = items.reduce((t, i) => ({
    total: t.total + i.total_pay, paid: t.paid + (i.status === 'Paid' ? i.total_pay : 0), workers: t.workers + 1,
  }), { total: 0, paid: 0, workers: 0 });
  p.totals.unpaid = p.totals.total - p.totals.paid;
  return p;
}

async function approvePeriod(user, req, id) {
  const p = (await query('SELECT * FROM payroll_periods WHERE id = ?', [id]))[0];
  if (!p) throw notFound('Payroll period not found.');
  if (p.status !== 'Draft') throw conflict(`This payroll is already ${p.status}.`);
  await pool.query("UPDATE payroll_periods SET status='Approved', approved_by=?, approved_at=? WHERE id=?", [user.id, T.nowStr(), id]);
  await audit({ req, userId: user.id, action: 'PAYROLL_APPROVED', entity: 'payroll_periods', entityId: id, previous: { status: 'Draft' }, next: { status: 'Approved' } });
  return getPeriod(id);
}

async function deleteDraft(user, req, id) {
  await tx(async (conn) => {
    const p = (await query('SELECT * FROM payroll_periods WHERE id = ? FOR UPDATE', [id], conn))[0];
    if (!p) throw notFound('Payroll period not found.');
    if (p.status !== 'Draft') throw conflict('Only a draft payroll can be deleted.');
    await conn.query('UPDATE wage_calculations SET payroll_item_id = NULL WHERE payroll_item_id IN (SELECT id FROM payroll_items WHERE period_id = ?)', [id]);
    await conn.query('DELETE FROM payroll_items WHERE period_id = ?', [id]);
    await conn.query('DELETE FROM payroll_periods WHERE id = ?', [id]);
    await audit({ req, userId: user.id, action: 'PAYROLL_DELETED', entity: 'payroll_periods', entityId: id, previous: { name: p.name, status: p.status }, conn });
  });
  return { ok: true };
}

async function recordPayment(user, req, { payroll_item_id, method, reference, payment_date }) {
  if (!['cash', 'mobile_money', 'bank_transfer'].includes(method)) throw bad('Choose a payment method.');
  if (!reference || reference.trim().length < 3) throw bad('Enter a payment reference (at least 3 characters).');
  if (!T.isValidDate(payment_date)) throw bad('Enter a valid payment date.');
  if (payment_date > T.todayStr()) throw bad('Payment date cannot be in the future.');

  const out = await tx(async (conn) => {
    const item = (await query('SELECT pi.*, pp.status AS period_status, pp.name AS period_name FROM payroll_items pi JOIN payroll_periods pp ON pp.id = pi.period_id WHERE pi.id = ? FOR UPDATE', [payroll_item_id], conn))[0];
    if (!item) throw notFound('Payroll item not found.');
    if (item.period_status !== 'Approved') throw conflict('The payroll must be approved before payments are recorded.');
    if (item.status === 'Paid') throw conflict('This wage is already marked as paid.');
    const [pay] = await conn.query('INSERT INTO payments (payroll_item_id, amount, method, reference, payment_date, recorded_by) VALUES (?,?,?,?,?,?)', [payroll_item_id, item.total_pay, method, reference.trim(), payment_date, user.id]);
    await conn.query("UPDATE payroll_items SET status = 'Paid' WHERE id = ?", [payroll_item_id]);
    const no = `PS-${payment_date.slice(0, 4)}${payment_date.slice(5, 7)}-${String(payroll_item_id).padStart(5, '0')}`;
    const [ps] = await conn.query('INSERT INTO payslips (payslip_no, payroll_item_id, worker_id) VALUES (?,?,?)', [no, payroll_item_id, item.worker_id]);
    const left = await query("SELECT COUNT(*) AS n FROM payroll_items WHERE period_id = ? AND status = 'Unpaid'", [item.period_id], conn);
    if (left[0].n === 0) await conn.query("UPDATE payroll_periods SET status = 'Closed' WHERE id = ?", [item.period_id]);
    await audit({ req, userId: user.id, action: 'PAYMENT_RECORDED', entity: 'payments', entityId: pay.insertId, next: { payroll_item_id, amount: item.total_pay, method, reference, payment_date }, conn });
    await audit({ req, userId: user.id, action: 'PAYSLIP_GENERATED', entity: 'payslips', entityId: ps.insertId, next: { payslip_no: no }, conn });
    return { item, payslipId: ps.insertId, payslipNo: no, paymentId: pay.insertId };
  });
  await notify(out.item.worker_id, 'payment', `Payment of UGX ${out.item.total_pay.toLocaleString('en-US')} for ${out.item.period_name} has been recorded.`, { sms: true });
  await notify(out.item.worker_id, 'payslip', `Your payslip ${out.payslipNo} is now available.`);
  return { payment_id: out.paymentId, payslip_id: out.payslipId, payslip_no: out.payslipNo, amount: out.item.total_pay };
}

async function payAll(user, req, { period_id, method, reference_prefix, payment_date }) {
  if (!reference_prefix || reference_prefix.trim().length < 2) throw bad('Enter a reference prefix.');
  const items = await query("SELECT id FROM payroll_items WHERE period_id = ? AND status = 'Unpaid'", [period_id]);
  if (!items.length) throw bad('There are no unpaid items in this payroll.');
  const done = [];
  for (const it of items) done.push(await recordPayment(user, req, { payroll_item_id: it.id, method, reference: `${reference_prefix.trim()}-${it.id}`, payment_date }));
  return { paid: done.length };
}

async function getPayslipData(payslipId) {
  const ps = (await query(
    `SELECT ps.*, pi.period_id, pi.days_worked, pi.total_hours, pi.normal_pay, pi.overtime_pay, pi.total_pay, pi.status AS item_status,
            pp.name AS period_name, pp.start_date, pp.end_date,
            u.full_name AS worker_name, u.phone AS worker_phone, wp.worker_code,
            pay.method, pay.reference, pay.payment_date
     FROM payslips ps JOIN payroll_items pi ON pi.id = ps.payroll_item_id JOIN payroll_periods pp ON pp.id = pi.period_id
     JOIN users u ON u.id = ps.worker_id LEFT JOIN worker_profiles wp ON wp.user_id = u.id
     LEFT JOIN payments pay ON pay.payroll_item_id = pi.id WHERE ps.id = ?`, [payslipId]))[0];
  if (!ps) throw notFound('Payslip not found.');
  ps.lines = await query(
    `SELECT wc.*, j.title AS job_title FROM wage_calculations wc JOIN assignments a ON a.id = wc.assignment_id JOIN jobs j ON j.id = a.job_id
     WHERE wc.payroll_item_id = ? ORDER BY wc.work_date`, [ps.payroll_item_id]);
  return ps;
}

module.exports = { createPeriod, getPeriod, approvePeriod, deleteDraft, recordPayment, payAll, getPayslipData };
