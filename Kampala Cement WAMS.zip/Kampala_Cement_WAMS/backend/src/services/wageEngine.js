// The wage calculation engine. Pure functions only (no database), so it can be tested with known answers.
//
// Hourly worker:  normal pay   = normal hours x hourly rate
//                 overtime pay = overtime hours x hourly rate x overtime multiplier
// Daily worker:   normal pay   = full daily rate when hours >= daily_min_hours,
//                                otherwise (daily rate / normal hours per day) x hours worked
//                 overtime pay = overtime hours x (daily rate / normal hours per day) x multiplier
// Normal hours = hours up to the daily limit (default 8). Overtime hours = hours beyond it.
// Every money value is rounded to the nearest whole shilling.

function round2(n) { return Math.round(n * 100) / 100; }
function roundMoney(n) { return Math.round(n); }

function calculateWage({ rateType, rate, totalHours, rules }) {
  const normalLimit = Number(rules.normal_hours_per_day);
  const multiplier = Number(rules.overtime_multiplier);
  const dailyMin = Number(rules.daily_min_hours ?? 0);

  if (!['hourly', 'daily'].includes(rateType)) throw new Error('Invalid rate type');
  if (!Number.isFinite(Number(rate)) || Number(rate) < 0) throw new Error('Invalid rate');
  if (!Number.isFinite(Number(totalHours)) || Number(totalHours) < 0) throw new Error('Invalid hours');
  if (Number(totalHours) > 24) throw new Error('Hours worked cannot be more than 24 in one shift');
  if (!(normalLimit > 0)) throw new Error('Invalid normal hours rule');
  if (!(multiplier >= 1)) throw new Error('Invalid overtime multiplier');

  const hours = round2(Number(totalHours));
  const r = Number(rate);
  const normalHours = Math.min(hours, normalLimit);
  const overtimeHours = round2(Math.max(0, hours - normalLimit));
  const hourlyEquivalent = rateType === 'hourly' ? r : r / normalLimit;

  let basicPay;
  if (rateType === 'hourly') {
    basicPay = normalHours * r;
  } else {
    basicPay = hours >= dailyMin ? r : hourlyEquivalent * normalHours;
  }
  const overtimePay = overtimeHours * hourlyEquivalent * multiplier;

  const basic = roundMoney(basicPay);
  const overtime = roundMoney(overtimePay);
  return {
    rate_type: rateType,
    rate: r,
    total_hours: hours,
    normal_hours: round2(normalHours),
    overtime_hours: overtimeHours,
    overtime_multiplier: multiplier,
    basic_pay: basic,
    overtime_pay: overtime,
    total_pay: basic + overtime,
  };
}

module.exports = { calculateWage, round2, roundMoney };
