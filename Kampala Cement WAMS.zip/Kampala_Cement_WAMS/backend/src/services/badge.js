const crypto = require('crypto');
const QRCode = require('qrcode');
const env = require('../config/env');

// A worker's QR badge holds "WORKERCODE.signature". The signature stops people from inventing codes.
function sign(code) {
  return crypto.createHmac('sha256', env.JWT_SECRET).update('badge:' + code).digest('hex').slice(0, 12);
}
function makeToken(code) { return `${code}.${sign(code)}`; }
function readToken(token) {
  const m = /^([A-Z0-9]{3,20})\.([a-f0-9]{12})$/.exec(String(token || '').trim());
  if (!m) return null;
  const a = Buffer.from(sign(m[1])), b = Buffer.from(m[2]);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  return m[1];
}
async function qrDataUrl(token) {
  return QRCode.toDataURL(token, { margin: 1, width: 260 });
}
module.exports = { makeToken, readToken, qrDataUrl };
