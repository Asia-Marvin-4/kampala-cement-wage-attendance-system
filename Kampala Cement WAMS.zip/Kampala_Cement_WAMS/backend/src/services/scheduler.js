const cron = require('node-cron');
const env = require('../config/env');
const { pool, query } = require('../config/db');
const { getRules } = require('./rules');
const { notify } = require('./notificationService');
const { audit } = require('../utils/audit');
const T = require('../utils/time');

// Automatic checks. They run on a timer, with no one clicking anything.
async function markAbsent(rules) {
  const now = T.nowStr(), today = T.todayStr();
  const shifts = await query(
    `SELECT s.id, s.assignment_id, s.shift_date, s.end_time, a.worker_id, j.created_by, u.full_name, j.title
     FROM shifts s JOIN assignments a ON a.id = s.assignment_id JOIN jobs j ON j.id = a.job_id JOIN users u ON u.id = a.worker_id
     WHERE s.shift_date <= ? AND NOT EXISTS (SELECT 1 FROM attendance t WHERE t.shift_id = s.id)`, [today]);
  let n = 0;
  for (const s of shifts) {
    const end = T.combine(s.shift_date, s.end_time);
    if (now <= T.addMinutes(end, rules.absent_grace_minutes)) continue;
    const [r] = await pool.query(
      `INSERT IGNORE INTO attendance (worker_id, assignment_id, shift_id, work_date, attendance_status, approval_status, capture_method, approved_at)
       VALUES (?,?,?,?, 'Absent', 'Approved', 'system', ?)`, [s.worker_id, s.assignment_id, s.id, s.shift_date, now]);
    if (r.affectedRows) {
      n++;
      await audit({ userId: null, action: 'AUTO_MARKED_ABSENT', entity: 'attendance', entityId: r.insertId, next: { worker_id: s.worker_id, date: s.shift_date } });
      await notify(s.worker_id, 'absent', `You were marked absent for ${s.title} on ${s.shift_date} (no clock-in). Request a correction if this is wrong.`, { dedupeKey: `abs:${s.id}`, sms: true });
      await notify(s.created_by, 'absent_alert', `${s.full_name} did not clock in for ${s.title} on ${s.shift_date}.`, { dedupeKey: `abs-sup:${s.id}` });
    }
  }
  return n;
}

async function flagMissedClockOut(rules) {
  const now = T.nowStr();
  const rows = await query(
    `SELECT att.id, att.worker_id, att.work_date, s.end_time, j.created_by, u.full_name
     FROM attendance att JOIN shifts s ON s.id = att.shift_id JOIN assignments a ON a.id = att.assignment_id JOIN jobs j ON j.id = a.job_id JOIN users u ON u.id = att.worker_id
     WHERE att.attendance_status = 'In Progress'`);
  let n = 0;
  for (const r of rows) {
    const end = T.combine(r.work_date, r.end_time);
    if (now <= T.addMinutes(end, rules.missed_clockout_grace_minutes)) continue;
    await pool.query("UPDATE attendance SET attendance_status = 'Missed Clock-out', approval_status = 'Pending Approval' WHERE id = ? AND attendance_status = 'In Progress'", [r.id]);
    n++;
    await audit({ userId: null, action: 'AUTO_FLAGGED_MISSED_CLOCKOUT', entity: 'attendance', entityId: r.id });
    await notify(r.worker_id, 'missed_clockout', `You did not clock out on ${r.work_date}. Request a correction with your real finishing time.`, { dedupeKey: `mco:${r.id}`, sms: true });
    await notify(r.created_by, 'missed_clockout_alert', `${r.full_name} did not clock out on ${r.work_date}.`, { dedupeKey: `mco-sup:${r.id}` });
  }
  return n;
}

async function remindPayments() {
  const today = T.todayStr();
  const periods = await query(
    `SELECT pp.id, pp.name, COUNT(*) AS unpaid FROM payroll_periods pp JOIN payroll_items pi ON pi.period_id = pp.id
     WHERE pp.status = 'Approved' AND pi.status = 'Unpaid' GROUP BY pp.id, pp.name`);
  if (!periods.length) return 0;
  const finance = await query("SELECT id FROM users WHERE role IN ('finance') AND status = 'active'");
  let n = 0;
  for (const p of periods) for (const f of finance) {
    const id = await notify(f.id, 'payment_due', `${p.unpaid} wage payment(s) are still unpaid in "${p.name}".`, { dedupeKey: `due:${p.id}:${f.id}:${today}` });
    if (id) n++;
  }
  return n;
}

async function runAutomation() {
  const rules = await getRules();
  const result = { marked_absent: await markAbsent(rules), flagged_missed_clockout: await flagMissedClockOut(rules), payment_reminders: await remindPayments() };
  return result;
}

function startScheduler() {
  if (!env.AUTOMATION_ENABLED) { console.log('[automation] disabled'); return; }
  if (!cron.validate(env.AUTOMATION_CRON)) { console.warn('[automation] invalid cron expression, not started'); return; }
  cron.schedule(env.AUTOMATION_CRON, async () => {
    try {
      const r = await runAutomation();
      if (r.marked_absent || r.flagged_missed_clockout || r.payment_reminders) console.log('[automation]', JSON.stringify(r));
    } catch (e) { console.error('[automation] error:', e.message); }
  });
  console.log(`[automation] scheduled (${env.AUTOMATION_CRON})`);
}
module.exports = { startScheduler, runAutomation };
