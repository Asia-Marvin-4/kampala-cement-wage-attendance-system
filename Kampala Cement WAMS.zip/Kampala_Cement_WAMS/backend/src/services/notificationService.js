const { pool } = require('../config/db');
const env = require('../config/env');
const { getRules } = require('./rules');

async function sendSms(phone, message) {
  if (env.SMS_PROVIDER === 'console') { console.log(`[sms:console] to ${phone}: ${message}`); return true; }
  if (env.SMS_PROVIDER === 'twilio') {
    const sid = env.SMS_API_KEY, token = env.SMS_API_SECRET;
    const body = new URLSearchParams({ To: phone, From: env.SMS_FROM, Body: message });
    const res = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
      method: 'POST',
      headers: { Authorization: 'Basic ' + Buffer.from(`${sid}:${token}`).toString('base64'), 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
    });
    if (!res.ok) throw new Error('SMS provider returned ' + res.status);
    return true;
  }
  return false;
}

// Creates an in-app notification. Optionally tries SMS too. This function never throws:
// if SMS (or anything else here) fails, the main operation still succeeds.
async function notify(userId, type, message, { dedupeKey = null, sms = false, conn = pool } = {}) {
  try {
    if (dedupeKey) {
      const [dup] = await conn.query('SELECT id FROM notifications WHERE dedupe_key = ? LIMIT 1', [dedupeKey]);
      if (dup.length) return null;
    }
    const [r] = await conn.query('INSERT INTO notifications (user_id, type, message, dedupe_key) VALUES (?,?,?,?)', [userId, type, message.slice(0, 250), dedupeKey]);
    if (sms) {
      let status = 'skipped';
      try {
        const rules = await getRules();
        const [u] = await conn.query('SELECT phone FROM users WHERE id = ?', [userId]);
        if (rules.sms_enabled && env.SMS_PROVIDER !== 'none' && u[0]?.phone) {
          status = (await sendSms(u[0].phone, message)) ? 'sent' : 'skipped';
        }
      } catch (e) {
        status = 'failed';
        console.error('[sms] failed:', e.message);
      }
      await conn.query('UPDATE notifications SET sms_status = ? WHERE id = ?', [status, r.insertId]);
    }
    return r.insertId;
  } catch (err) {
    console.error('[notify] failed:', err.message);
    return null;
  }
}

module.exports = { notify };
