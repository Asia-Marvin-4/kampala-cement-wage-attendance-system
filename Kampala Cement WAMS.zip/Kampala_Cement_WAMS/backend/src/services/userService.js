const bcrypt = require('bcryptjs');
const { pool } = require('../config/db');

async function hashPassword(p) { return bcrypt.hash(p, 12); }

// Creates the user row and the matching profile row (worker or employer/staff)
async function createUser(conn, { full_name, email, phone, password, role, status }) {
  const hash = await hashPassword(password);
  const [r] = await conn.query('INSERT INTO users (full_name, email, phone, password_hash, role, status) VALUES (?,?,?,?,?,?)', [full_name.trim(), email.trim().toLowerCase(), phone || null, hash, role, status]);
  await ensureProfile(conn, r.insertId, role);
  return r.insertId;
}
async function ensureProfile(conn, userId, role) {
  if (role === 'worker') {
    const [e] = await conn.query('SELECT id FROM worker_profiles WHERE user_id = ?', [userId]);
    if (!e.length) await conn.query('INSERT INTO worker_profiles (user_id, worker_code) VALUES (?,?)', [userId, 'KCW' + String(userId).padStart(4, '0')]);
  } else {
    const [e] = await conn.query('SELECT id FROM employer_profiles WHERE user_id = ?', [userId]);
    if (!e.length) await conn.query('INSERT INTO employer_profiles (user_id) VALUES (?)', [userId]);
  }
}
module.exports = { hashPassword, createUser, ensureProfile };
