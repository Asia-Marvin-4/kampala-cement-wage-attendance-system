const { pool } = require('../config/db');
const { bad } = require('../utils/httpError');

// Default business rules. The administrator can change these in the system (nothing is hard-coded in the wage engine).
const DEFAULT_RULES = [
  ['company_name', 'Kampala Cement Co. Ltd', 'Company name shown on payslips and reports', 'text'],
  ['normal_hours_per_day', '8', 'Normal working hours per day. Hours beyond this are overtime', 'number'],
  ['overtime_multiplier', '1.5', 'Overtime pay multiplier (1.5 = time and a half)', 'number'],
  ['daily_min_hours', '4', 'Minimum hours for a daily-rate worker to earn the full day rate', 'number'],
  ['late_grace_minutes', '15', 'Minutes after shift start before a clock-in counts as late', 'number'],
  ['early_clockin_minutes', '60', 'How many minutes before shift start a worker may clock in', 'number'],
  ['absent_grace_minutes', '120', 'Minutes after shift end before a shift with no clock-in is marked absent', 'number'],
  ['missed_clockout_grace_minutes', '60', 'Minutes after shift end before an open clock-in is flagged as a missed clock-out', 'number'],
  ['sms_enabled', 'false', 'Send SMS notifications (true or false). The system works without SMS', 'boolean'],
  ['worksite_lat', '', 'Optional worksite latitude for the location check (leave blank to disable)', 'text'],
  ['worksite_lng', '', 'Optional worksite longitude for the location check', 'text'],
  ['worksite_radius_m', '500', 'Allowed distance from the worksite in metres', 'number'],
];
const META = Object.fromEntries(DEFAULT_RULES.map(([k, v, d, t]) => [k, { def: v, desc: d, type: t }]));

async function getRules(conn = pool) {
  const [rows] = await conn.query('SELECT rule_key, rule_value FROM wage_rules');
  const raw = Object.fromEntries(DEFAULT_RULES.map(([k, v]) => [k, v]));
  for (const r of rows) raw[r.rule_key] = r.rule_value;
  const out = {};
  for (const [k, v] of Object.entries(raw)) {
    const t = META[k]?.type;
    if (t === 'number') out[k] = Number(v);
    else if (t === 'boolean') out[k] = String(v) === 'true';
    else out[k] = v;
  }
  return out;
}

function validateRule(key, value) {
  const meta = META[key];
  if (!meta) throw bad('Unknown rule.');
  const v = String(value ?? '').trim();
  if (meta.type === 'number') {
    const n = Number(v);
    if (v === '' || !Number.isFinite(n) || n < 0) throw bad('This rule must be a positive number.');
    if (key === 'overtime_multiplier' && n < 1) throw bad('Overtime multiplier must be 1 or more.');
    if (key === 'normal_hours_per_day' && (n <= 0 || n > 24)) throw bad('Normal hours must be between 1 and 24.');
  }
  if (meta.type === 'boolean' && !['true', 'false'].includes(v)) throw bad('This rule must be true or false.');
  if (key === 'company_name' && v.length < 2) throw bad('Company name is too short.');
  if (['worksite_lat', 'worksite_lng'].includes(key) && v !== '' && !Number.isFinite(Number(v))) throw bad('Coordinates must be numbers.');
  return v;
}

module.exports = { DEFAULT_RULES, META, getRules, validateRule };
