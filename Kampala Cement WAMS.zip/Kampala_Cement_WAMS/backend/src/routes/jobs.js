const router = require('express').Router();
const { body } = require('express-validator');
const { pool, query } = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');
const { handleValidation } = require('../middleware/validate');
const { bad, notFound, forbidden, conflict } = require('../utils/httpError');
const { audit } = require('../utils/audit');
const { notify } = require('../services/notificationService');
const T = require('../utils/time');

router.use(authenticate);

async function loadJob(id) {
  const j = (await query('SELECT * FROM jobs WHERE id = ?', [id]))[0];
  if (!j) throw notFound('Job not found.');
  return j;
}
function ownsJob(user, job) {
  if (user.role === 'admin') return;
  if (user.role === 'supervisor' && job.created_by === user.id) return;
  throw forbidden('You can only manage your own jobs.');
}
const dateOpt = (f) => body(f).optional({ values: 'falsy' }).custom(T.isValidDate).withMessage('Enter a valid date.');

// ---------- Jobs ----------
router.get('/jobs', async (req, res) => {
  const params = [];
  let sql = `SELECT j.*, u.full_name AS created_by_name,
      (SELECT COUNT(*) FROM assignments a WHERE a.job_id = j.id AND a.status = 'active') AS active_workers
    FROM jobs j JOIN users u ON u.id = j.created_by`;
  const where = [];
  if (req.user.role === 'supervisor') { where.push('j.created_by = ?'); params.push(req.user.id); }
  if (req.user.role === 'worker') { where.push('EXISTS (SELECT 1 FROM assignments a WHERE a.job_id = j.id AND a.worker_id = ?)'); params.push(req.user.id); }
  if (['active', 'completed', 'cancelled'].includes(req.query.status)) { where.push('j.status = ?'); params.push(req.query.status); }
  if (where.length) sql += ' WHERE ' + where.join(' AND ');
  res.json(await query(sql + ' ORDER BY j.created_at DESC', params));
});

router.post('/jobs', authorize('supervisor', 'admin'),
  body('title').trim().isLength({ min: 3, max: 150 }).withMessage('Enter a job title (at least 3 characters).'),
  body('start_date').custom(T.isValidDate).withMessage('Enter a valid start date.'),
  dateOpt('end_date'), handleValidation,
  async (req, res) => {
    const b = req.body;
    if (b.end_date && b.end_date < b.start_date) throw bad('End date cannot be before the start date.');
    const [r] = await pool.query('INSERT INTO jobs (title, description, location, start_date, end_date, created_by) VALUES (?,?,?,?,?,?)', [b.title.trim(), (b.description || '').slice(0, 1000) || null, (b.location || '').slice(0, 150) || null, b.start_date, b.end_date || null, req.user.id]);
    await audit({ req, action: 'JOB_CREATED', entity: 'jobs', entityId: r.insertId, next: { title: b.title, start_date: b.start_date } });
    res.status(201).json({ id: r.insertId });
  });

router.put('/jobs/:id', authorize('supervisor', 'admin'),
  body('title').trim().isLength({ min: 3, max: 150 }).withMessage('Enter a job title (at least 3 characters).'),
  body('start_date').custom(T.isValidDate).withMessage('Enter a valid start date.'),
  dateOpt('end_date'), body('status').isIn(['active', 'completed', 'cancelled']).withMessage('Choose a status.'), handleValidation,
  async (req, res) => {
    const job = await loadJob(req.params.id); ownsJob(req.user, job);
    const b = req.body;
    if (b.end_date && b.end_date < b.start_date) throw bad('End date cannot be before the start date.');
    await pool.query('UPDATE jobs SET title=?, description=?, location=?, start_date=?, end_date=?, status=? WHERE id=?', [b.title.trim(), (b.description || '').slice(0, 1000) || null, (b.location || '').slice(0, 150) || null, b.start_date, b.end_date || null, b.status, job.id]);
    await audit({ req, action: 'JOB_UPDATED', entity: 'jobs', entityId: job.id, previous: { title: job.title, status: job.status }, next: { title: b.title, status: b.status } });
    res.json({ ok: true });
  });

// ---------- Assignments (worker <-> job, with the agreed pay rate) ----------
router.get('/assignments', async (req, res) => {
  const params = [], where = [];
  if (req.user.role === 'worker') { where.push('a.worker_id = ?'); params.push(req.user.id); }
  if (req.user.role === 'supervisor') { where.push('j.created_by = ?'); params.push(req.user.id); }
  if (req.query.job_id) { where.push('a.job_id = ?'); params.push(req.query.job_id); }
  if (['active', 'ended'].includes(req.query.status)) { where.push('a.status = ?'); params.push(req.query.status); }
  res.json(await query(
    `SELECT a.*, j.title AS job_title, j.location, j.status AS job_status, u.full_name AS worker_name, wp.worker_code
     FROM assignments a JOIN jobs j ON j.id = a.job_id JOIN users u ON u.id = a.worker_id LEFT JOIN worker_profiles wp ON wp.user_id = u.id
     ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY a.created_at DESC LIMIT 500`, params));
});

const rateRules = [
  body('rate_type').isIn(['hourly', 'daily']).withMessage('Choose hourly or daily rate.'),
  body('rate').isFloat({ gt: 0, max: 100000000 }).withMessage('Enter a rate greater than zero.'),
];
router.post('/assignments', authorize('supervisor', 'admin'),
  body('job_id').isInt({ min: 1 }).withMessage('Choose a job.'), body('worker_id').isInt({ min: 1 }).withMessage('Choose a worker.'), ...rateRules, handleValidation,
  async (req, res) => {
    const job = await loadJob(req.body.job_id); ownsJob(req.user, job);
    if (job.status !== 'active') throw bad('You can only assign workers to an active job.');
    const w = (await query("SELECT id, full_name FROM users WHERE id = ? AND role = 'worker' AND status = 'active'", [req.body.worker_id]))[0];
    if (!w) throw bad('That worker is not active or does not exist.');
    const dup = await query('SELECT id, status FROM assignments WHERE job_id = ? AND worker_id = ?', [job.id, w.id]);
    if (dup.length) throw conflict('This worker is already assigned to this job.');
    const [r] = await pool.query('INSERT INTO assignments (job_id, worker_id, rate_type, rate, assigned_by) VALUES (?,?,?,?,?)', [job.id, w.id, req.body.rate_type, req.body.rate, req.user.id]);
    await audit({ req, action: 'WORKER_ASSIGNED', entity: 'assignments', entityId: r.insertId, next: { job_id: job.id, worker_id: w.id, rate_type: req.body.rate_type, rate: req.body.rate } });
    await notify(w.id, 'assignment', `You were assigned to "${job.title}" at UGX ${Number(req.body.rate).toLocaleString('en-US')} per ${req.body.rate_type === 'hourly' ? 'hour' : 'day'}.`, { sms: true });
    res.status(201).json({ id: r.insertId });
  });

router.put('/assignments/:id', authorize('supervisor', 'admin'), ...rateRules, body('status').isIn(['active', 'ended']).withMessage('Choose a status.'), handleValidation, async (req, res) => {
  const a = (await query('SELECT a.*, j.created_by FROM assignments a JOIN jobs j ON j.id = a.job_id WHERE a.id = ?', [req.params.id]))[0];
  if (!a) throw notFound('Assignment not found.');
  ownsJob(req.user, { created_by: a.created_by });
  await pool.query('UPDATE assignments SET rate_type=?, rate=?, status=? WHERE id=?', [req.body.rate_type, req.body.rate, req.body.status, a.id]);
  await audit({ req, action: 'ASSIGNMENT_UPDATED', entity: 'assignments', entityId: a.id, previous: { rate_type: a.rate_type, rate: a.rate, status: a.status }, next: { rate_type: req.body.rate_type, rate: req.body.rate, status: req.body.status } });
  res.json({ ok: true });
});

// ---------- Shifts ----------
const timeRe = /^([01]\d|2[0-3]):[0-5]\d$/;
router.get('/shifts', async (req, res) => {
  const params = [], where = [];
  if (req.user.role === 'worker') { where.push('a.worker_id = ?'); params.push(req.user.id); }
  if (req.user.role === 'supervisor') { where.push('j.created_by = ?'); params.push(req.user.id); }
  if (req.query.from && T.isValidDate(req.query.from)) { where.push('s.shift_date >= ?'); params.push(req.query.from); }
  if (req.query.to && T.isValidDate(req.query.to)) { where.push('s.shift_date <= ?'); params.push(req.query.to); }
  if (req.query.assignment_id) { where.push('s.assignment_id = ?'); params.push(req.query.assignment_id); }
  res.json(await query(
    `SELECT s.*, a.worker_id, u.full_name AS worker_name, j.title AS job_title, att.id AS attendance_id, att.attendance_status
     FROM shifts s JOIN assignments a ON a.id = s.assignment_id JOIN jobs j ON j.id = a.job_id JOIN users u ON u.id = a.worker_id
     LEFT JOIN attendance att ON att.shift_id = s.id
     ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY s.shift_date DESC, s.start_time LIMIT 500`, params));
});

router.post('/shifts', authorize('supervisor', 'admin'),
  body('assignment_id').isInt({ min: 1 }).withMessage('Choose an assignment.'),
  body('start_time').matches(timeRe).withMessage('Enter the start time (HH:MM).'),
  body('end_time').matches(timeRe).withMessage('Enter the end time (HH:MM).'),
  body('shift_date').optional({ values: 'falsy' }).custom(T.isValidDate).withMessage('Enter a valid date.'),
  body('from_date').optional({ values: 'falsy' }).custom(T.isValidDate).withMessage('Enter a valid start date.'),
  body('to_date').optional({ values: 'falsy' }).custom(T.isValidDate).withMessage('Enter a valid end date.'),
  handleValidation,
  async (req, res) => {
    const b = req.body;
    const a = (await query('SELECT a.*, j.created_by, j.title FROM assignments a JOIN jobs j ON j.id = a.job_id WHERE a.id = ?', [b.assignment_id]))[0];
    if (!a) throw notFound('Assignment not found.');
    ownsJob(req.user, { created_by: a.created_by });
    if (a.status !== 'active') throw bad('This assignment has ended.');
    if (b.end_time <= b.start_time) throw bad('End time must be after start time (overnight shifts are not supported in this version).');
    const from = b.from_date || b.shift_date, to = b.to_date || b.shift_date;
    if (!from) throw bad('Choose a shift date.');
    if (to < from) throw bad('The end date cannot be before the start date.');
    if (req.user.role !== 'admin' && from < T.todayStr()) throw bad('You cannot create shifts in the past.');
    const dates = [];
    for (let d = from; d <= to && dates.length <= 31; d = T.addDays(d, 1)) {
      const dow = new Date(T.toMs(d)).getUTCDay();
      if (b.skip_weekends && (dow === 0 || dow === 6)) continue;
      dates.push(d);
    }
    if (dates.length > 31) throw bad('You can create at most 31 shifts at a time.');
    if (!dates.length) throw bad('No working days in that range.');
    let created = 0;
    for (const d of dates) {
      const [r] = await pool.query('INSERT IGNORE INTO shifts (assignment_id, shift_date, start_time, end_time, created_by) VALUES (?,?,?,?,?)', [a.id, d, b.start_time + ':00', b.end_time + ':00', req.user.id]);
      created += r.affectedRows;
    }
    await audit({ req, action: 'SHIFTS_CREATED', entity: 'assignments', entityId: a.id, next: { from, to, start: b.start_time, end: b.end_time, created } });
    if (created) await notify(a.worker_id, 'shift', `${created} shift(s) scheduled for "${a.title}" from ${from}${to !== from ? ' to ' + to : ''}, ${b.start_time} to ${b.end_time}.`);
    res.status(201).json({ created });
  });

router.delete('/shifts/:id', authorize('supervisor', 'admin'), async (req, res) => {
  const s = (await query('SELECT s.*, j.created_by FROM shifts s JOIN assignments a ON a.id = s.assignment_id JOIN jobs j ON j.id = a.job_id WHERE s.id = ?', [req.params.id]))[0];
  if (!s) throw notFound('Shift not found.');
  ownsJob(req.user, { created_by: s.created_by });
  const att = await query('SELECT id FROM attendance WHERE shift_id = ?', [s.id]);
  if (att.length) throw conflict('This shift already has attendance and cannot be deleted.');
  await pool.query('DELETE FROM shifts WHERE id = ?', [s.id]);
  await audit({ req, action: 'SHIFT_DELETED', entity: 'shifts', entityId: s.id, previous: { date: s.shift_date, start: s.start_time, end: s.end_time } });
  res.json({ ok: true });
});

module.exports = router;
