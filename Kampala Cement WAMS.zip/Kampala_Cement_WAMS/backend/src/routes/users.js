const router = require('express').Router();
const { body, param } = require('express-validator');
const { pool, query, tx } = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');
const { handleValidation, strongPassword, PASSWORD_MESSAGE } = require('../middleware/validate');
const { bad, notFound, conflict, forbidden } = require('../utils/httpError');
const { audit } = require('../utils/audit');
const { createUser, ensureProfile, hashPassword } = require('../services/userService');
const { notify } = require('../services/notificationService');
const badge = require('../services/badge');

router.use(authenticate);
const ROLES = ['worker', 'supervisor', 'finance', 'admin'];
const phoneRule = body('phone').optional({ values: 'falsy' }).matches(/^\+?[0-9 ]{9,15}$/).withMessage('Enter a valid phone number.');

// ---------- Administrator: manage users ----------
router.get('/users', authorize('admin'), async (req, res) => {
  const where = [], params = [];
  if (ROLES.includes(req.query.role)) { where.push('u.role = ?'); params.push(req.query.role); }
  if (['pending', 'active', 'inactive'].includes(req.query.status)) { where.push('u.status = ?'); params.push(req.query.status); }
  if (req.query.q) { where.push('(u.full_name LIKE ? OR u.email LIKE ?)'); params.push(`%${req.query.q}%`, `%${req.query.q}%`); }
  const rows = await query(
    `SELECT u.id, u.full_name, u.email, u.phone, u.role, u.status, u.created_at, wp.worker_code
     FROM users u LEFT JOIN worker_profiles wp ON wp.user_id = u.id ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY u.created_at DESC LIMIT 500`, params);
  res.json(rows);
});

router.post('/users', authorize('admin'),
  body('full_name').trim().isLength({ min: 2, max: 120 }).withMessage('Enter the full name.'),
  body('email').trim().isEmail().withMessage('Enter a valid email address.'),
  phoneRule,
  body('role').isIn(ROLES).withMessage('Choose a role.'),
  body('password').custom(strongPassword).withMessage(PASSWORD_MESSAGE),
  handleValidation,
  async (req, res) => {
    const exists = await query('SELECT id FROM users WHERE email = ?', [req.body.email.toLowerCase()]);
    if (exists.length) throw conflict('An account with this email already exists.');
    const id = await tx((conn) => createUser(conn, { ...req.body, status: 'active' }));
    await audit({ req, action: 'USER_CREATED', entity: 'users', entityId: id, next: { email: req.body.email, role: req.body.role } });
    res.status(201).json({ id });
  });

router.put('/users/:id', authorize('admin'),
  body('full_name').trim().isLength({ min: 2, max: 120 }).withMessage('Enter the full name.'),
  body('email').trim().isEmail().withMessage('Enter a valid email address.'),
  phoneRule, handleValidation,
  async (req, res) => {
    const u = (await query('SELECT * FROM users WHERE id = ?', [req.params.id]))[0];
    if (!u) throw notFound('User not found.');
    const dup = await query('SELECT id FROM users WHERE email = ? AND id <> ?', [req.body.email.toLowerCase(), u.id]);
    if (dup.length) throw conflict('Another account already uses this email.');
    await pool.query('UPDATE users SET full_name=?, email=?, phone=? WHERE id=?', [req.body.full_name.trim(), req.body.email.toLowerCase(), req.body.phone || null, u.id]);
    await audit({ req, action: 'USER_UPDATED', entity: 'users', entityId: u.id, previous: { full_name: u.full_name, email: u.email, phone: u.phone }, next: { full_name: req.body.full_name, email: req.body.email, phone: req.body.phone } });
    res.json({ ok: true });
  });

router.patch('/users/:id/status', authorize('admin'), body('status').isIn(['active', 'inactive', 'pending']).withMessage('Invalid status.'), handleValidation, async (req, res) => {
  const u = (await query('SELECT * FROM users WHERE id = ?', [req.params.id]))[0];
  if (!u) throw notFound('User not found.');
  if (u.id === req.user.id && req.body.status !== 'active') throw forbidden('You cannot deactivate your own account.');
  await pool.query('UPDATE users SET status = ? WHERE id = ?', [req.body.status, u.id]);
  await audit({ req, action: 'USER_STATUS_CHANGED', entity: 'users', entityId: u.id, previous: { status: u.status }, next: { status: req.body.status } });
  if (req.body.status === 'active' && u.status !== 'active') await notify(u.id, 'account', 'Your account is now active. Welcome!');
  res.json({ ok: true });
});

router.put('/users/:id/role', authorize('admin'), body('role').isIn(ROLES).withMessage('Choose a role.'), handleValidation, async (req, res) => {
  const u = (await query('SELECT * FROM users WHERE id = ?', [req.params.id]))[0];
  if (!u) throw notFound('User not found.');
  if (u.id === req.user.id) throw forbidden('You cannot change your own role.');
  await tx(async (conn) => {
    await conn.query('UPDATE users SET role = ? WHERE id = ?', [req.body.role, u.id]);
    await ensureProfile(conn, u.id, req.body.role);
  });
  await audit({ req, action: 'USER_ROLE_CHANGED', entity: 'users', entityId: u.id, previous: { role: u.role }, next: { role: req.body.role } });
  res.json({ ok: true });
});

router.post('/users/:id/reset-password', authorize('admin'), body('password').custom(strongPassword).withMessage(PASSWORD_MESSAGE), handleValidation, async (req, res) => {
  const u = (await query('SELECT id FROM users WHERE id = ?', [req.params.id]))[0];
  if (!u) throw notFound('User not found.');
  await pool.query('UPDATE users SET password_hash = ? WHERE id = ?', [await hashPassword(req.body.password), u.id]);
  await audit({ req, action: 'PASSWORD_RESET_BY_ADMIN', entity: 'users', entityId: u.id });
  res.json({ ok: true });
});

// ---------- Own profile ----------
router.get('/profile', async (req, res) => {
  const base = (await query('SELECT id, full_name, email, phone, role, status FROM users WHERE id = ?', [req.user.id]))[0];
  const prof = req.user.role === 'worker'
    ? (await query('SELECT worker_code, skills, address, emergency_contact FROM worker_profiles WHERE user_id = ?', [req.user.id]))[0]
    : (await query('SELECT section, position_title FROM employer_profiles WHERE user_id = ?', [req.user.id]))[0];
  res.json({ ...base, ...(prof || {}) });
});

router.put('/profile',
  body('full_name').trim().isLength({ min: 2, max: 120 }).withMessage('Enter your full name.'),
  phoneRule, handleValidation,
  async (req, res) => {
    const b = req.body;
    await pool.query('UPDATE users SET full_name = ?, phone = ? WHERE id = ?', [b.full_name.trim(), b.phone || null, req.user.id]);
    if (req.user.role === 'worker') {
      await pool.query('UPDATE worker_profiles SET skills = ?, address = ?, emergency_contact = ? WHERE user_id = ?', [(b.skills || '').slice(0, 250) || null, (b.address || '').slice(0, 250) || null, (b.emergency_contact || '').slice(0, 120) || null, req.user.id]);
    } else {
      await pool.query('UPDATE employer_profiles SET section = ?, position_title = ? WHERE user_id = ?', [(b.section || '').slice(0, 120) || null, (b.position_title || '').slice(0, 120) || null, req.user.id]);
    }
    await audit({ req, action: 'PROFILE_UPDATED', entity: 'users', entityId: req.user.id });
    res.json({ ok: true });
  });

// ---------- Workers list and QR badge ----------
router.get('/workers', authorize('supervisor', 'finance', 'admin'), async (req, res) => {
  const params = [];
  let where = "u.role = 'worker' AND u.status = 'active'";
  if (req.query.q) { where += ' AND (u.full_name LIKE ? OR wp.worker_code LIKE ?)'; params.push(`%${req.query.q}%`, `%${req.query.q}%`); }
  const rows = await query(
    `SELECT u.id, u.full_name, u.phone, u.email, wp.worker_code, wp.skills,
       (SELECT COUNT(*) FROM assignments a WHERE a.worker_id = u.id AND a.status = 'active') AS active_assignments
     FROM users u LEFT JOIN worker_profiles wp ON wp.user_id = u.id WHERE ${where} ORDER BY u.full_name`, params);
  res.json(rows);
});

async function badgeFor(userId) {
  const w = (await query('SELECT u.full_name, wp.worker_code FROM users u JOIN worker_profiles wp ON wp.user_id = u.id WHERE u.id = ? AND u.role = \'worker\'', [userId]))[0];
  if (!w) throw notFound('Worker not found.');
  const token = badge.makeToken(w.worker_code);
  return { worker_name: w.full_name, worker_code: w.worker_code, token, qr: await badge.qrDataUrl(token) };
}
router.get('/workers/me/badge', authorize('worker'), async (req, res) => res.json(await badgeFor(req.user.id)));
router.get('/workers/:id/badge', authorize('supervisor', 'admin'), param('id').isInt(), handleValidation, async (req, res) => res.json(await badgeFor(req.params.id)));

module.exports = router;
