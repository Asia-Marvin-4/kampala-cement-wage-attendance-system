const router = require('express').Router();
const { body } = require('express-validator');
const { query } = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');
const { handleValidation } = require('../middleware/validate');
const { forbidden, notFound } = require('../utils/httpError');
const payroll = require('../services/payrollService');
const { buildPayslipPdf } = require('../services/payslipPdf');
const { getRules } = require('../services/rules');
const T = require('../utils/time');

router.use(authenticate);

// ---------- Wage calculations (traceable: each row shows exactly how the pay was worked out) ----------
router.get('/wages', async (req, res) => {
  const where = [], params = [];
  if (req.user.role === 'worker') { where.push('wc.worker_id = ?'); params.push(req.user.id); }
  if (req.user.role === 'supervisor') { where.push('j.created_by = ?'); params.push(req.user.id); }
  const q = req.query;
  if (q.from && T.isValidDate(q.from)) { where.push('wc.work_date >= ?'); params.push(q.from); }
  if (q.to && T.isValidDate(q.to)) { where.push('wc.work_date <= ?'); params.push(q.to); }
  if (q.worker_id && req.user.role !== 'worker') { where.push('wc.worker_id = ?'); params.push(q.worker_id); }
  if (q.unassigned === '1') where.push('wc.payroll_item_id IS NULL');
  res.json(await query(
    `SELECT wc.*, u.full_name AS worker_name, wp.worker_code, j.title AS job_title, att.clock_in, att.clock_out,
            pi.status AS payment_status, pp.name AS payroll_name
     FROM wage_calculations wc JOIN attendance att ON att.id = wc.attendance_id JOIN users u ON u.id = wc.worker_id
     LEFT JOIN worker_profiles wp ON wp.user_id = u.id JOIN assignments a ON a.id = wc.assignment_id JOIN jobs j ON j.id = a.job_id
     LEFT JOIN payroll_items pi ON pi.id = wc.payroll_item_id LEFT JOIN payroll_periods pp ON pp.id = pi.period_id
     ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY wc.work_date DESC, wc.id DESC LIMIT 500`, params));
});

// ---------- Payroll ----------
router.get('/payroll', authorize('finance', 'admin'), async (req, res) => {
  res.json(await query(
    `SELECT pp.*, (SELECT COUNT(*) FROM payroll_items pi WHERE pi.period_id = pp.id) AS workers,
            (SELECT COALESCE(SUM(total_pay),0) FROM payroll_items pi WHERE pi.period_id = pp.id) AS total_pay,
            (SELECT COALESCE(SUM(total_pay),0) FROM payroll_items pi WHERE pi.period_id = pp.id AND pi.status='Paid') AS paid_pay
     FROM payroll_periods pp ORDER BY pp.created_at DESC LIMIT 200`));
});
router.get('/payroll/:id', authorize('finance', 'admin'), async (req, res) => res.json(await payroll.getPeriod(req.params.id)));
router.post('/payroll', authorize('finance', 'admin'),
  body('name').isString().withMessage('Give the payroll a name.'),
  body('period_type').isString().withMessage('Choose a period type.'),
  body('start_date').isString().withMessage('Enter the start date.'),
  body('end_date').isString().withMessage('Enter the end date.'), handleValidation,
  async (req, res) => res.status(201).json(await payroll.createPeriod(req.user, req, req.body)));
router.post('/payroll/:id/approve', authorize('finance', 'admin'), async (req, res) => res.json(await payroll.approvePeriod(req.user, req, req.params.id)));
router.delete('/payroll/:id', authorize('finance', 'admin'), async (req, res) => res.json(await payroll.deleteDraft(req.user, req, req.params.id)));

// ---------- Payments ----------
router.get('/payments', async (req, res) => {
  const where = [], params = [];
  if (req.user.role === 'worker') { where.push('pi.worker_id = ?'); params.push(req.user.id); }
  else if (!['finance', 'admin'].includes(req.user.role)) throw forbidden();
  res.json(await query(
    `SELECT pay.*, pi.worker_id, pi.period_id, u.full_name AS worker_name, wp.worker_code, pp.name AS period_name, ps.id AS payslip_id, ps.payslip_no, rb.full_name AS recorded_by_name
     FROM payments pay JOIN payroll_items pi ON pi.id = pay.payroll_item_id JOIN users u ON u.id = pi.worker_id LEFT JOIN worker_profiles wp ON wp.user_id = u.id
     JOIN payroll_periods pp ON pp.id = pi.period_id LEFT JOIN payslips ps ON ps.payroll_item_id = pi.id JOIN users rb ON rb.id = pay.recorded_by
     ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY pay.created_at DESC LIMIT 500`, params));
});
const payRules = [
  body('method').isIn(['cash', 'mobile_money', 'bank_transfer']).withMessage('Choose a payment method.'),
  body('payment_date').isString().withMessage('Enter the payment date.'),
];
router.post('/payments', authorize('finance'), body('payroll_item_id').isInt({ min: 1 }).withMessage('Choose a payroll item.'), body('reference').isString().withMessage('Enter a payment reference.'), ...payRules, handleValidation,
  async (req, res) => res.status(201).json(await payroll.recordPayment(req.user, req, req.body)));
router.post('/payments/bulk', authorize('finance'), body('period_id').isInt({ min: 1 }).withMessage('Choose a payroll.'), body('reference_prefix').isString().withMessage('Enter a reference prefix.'), ...payRules, handleValidation,
  async (req, res) => res.status(201).json(await payroll.payAll(req.user, req, req.body)));

// ---------- Payslips ----------
async function loadPayslipFor(user, id) {
  const ps = await payroll.getPayslipData(id);
  if (user.role === 'worker' && ps.worker_id !== user.id) throw forbidden('You can only open your own payslips.');
  if (user.role === 'supervisor') throw forbidden();
  return ps;
}
router.get('/payslips', async (req, res) => {
  const where = [], params = [];
  if (req.user.role === 'worker') { where.push('ps.worker_id = ?'); params.push(req.user.id); }
  else if (!['finance', 'admin'].includes(req.user.role)) throw forbidden();
  res.json(await query(
    `SELECT ps.id, ps.payslip_no, ps.generated_at, pi.total_pay, pp.name AS period_name, pp.start_date, pp.end_date, u.full_name AS worker_name, wp.worker_code
     FROM payslips ps JOIN payroll_items pi ON pi.id = ps.payroll_item_id JOIN payroll_periods pp ON pp.id = pi.period_id JOIN users u ON u.id = ps.worker_id LEFT JOIN worker_profiles wp ON wp.user_id = u.id
     ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY ps.generated_at DESC LIMIT 500`, params));
});
router.get('/payslips/:id', async (req, res) => res.json(await loadPayslipFor(req.user, req.params.id)));
router.get('/payslips/:id/download', async (req, res) => {
  const ps = await loadPayslipFor(req.user, req.params.id);
  const rules = await getRules();
  const pdf = await buildPayslipPdf(ps, rules.company_name);
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${ps.payslip_no}.pdf"`);
  res.send(pdf);
});

module.exports = router;
