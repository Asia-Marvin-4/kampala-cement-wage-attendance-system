const router = require('express').Router();
const { body } = require('express-validator');
const { query } = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');
const { handleValidation } = require('../middleware/validate');
const { bad } = require('../utils/httpError');
const svc = require('../services/attendanceService');
const T = require('../utils/time');

router.use(authenticate);

function scope(user, params, where) {
  if (user.role === 'worker') { where.push('att.worker_id = ?'); params.push(user.id); }
  if (user.role === 'supervisor') { where.push('j.created_by = ?'); params.push(user.id); }
}

router.get('/attendance', async (req, res) => {
  const where = [], params = [];
  scope(req.user, params, where);
  const q = req.query;
  if (q.from && T.isValidDate(q.from)) { where.push('att.work_date >= ?'); params.push(q.from); }
  if (q.to && T.isValidDate(q.to)) { where.push('att.work_date <= ?'); params.push(q.to); }
  if (q.approval) { where.push('att.approval_status = ?'); params.push(q.approval); }
  if (q.status) { where.push('att.attendance_status = ?'); params.push(q.status); }
  if (q.worker_id && req.user.role !== 'worker') { where.push('att.worker_id = ?'); params.push(q.worker_id); }
  if (q.job_id) { where.push('j.id = ?'); params.push(q.job_id); }
  const rows = await query(`${svc.ATT_SELECT} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY att.work_date DESC, att.id DESC LIMIT 500`, params);
  res.json(rows);
});

// Worker's "today" screen: today's shifts and what has been recorded for them
router.get('/attendance/today', authorize('worker'), async (req, res) => {
  const today = T.todayStr();
  const shifts = await query(
    `SELECT s.id AS shift_id, s.shift_date, s.start_time, s.end_time, j.title AS job_title, j.location, a.rate_type, a.rate,
            att.id AS attendance_id, att.clock_in, att.clock_out, att.total_hours, att.attendance_status, att.approval_status, att.is_late
     FROM shifts s JOIN assignments a ON a.id = s.assignment_id JOIN jobs j ON j.id = a.job_id
     LEFT JOIN attendance att ON att.shift_id = s.id
     WHERE a.worker_id = ? AND s.shift_date = ? ORDER BY s.start_time`, [req.user.id, today]);
  const open = await query("SELECT id, clock_in FROM attendance WHERE worker_id = ? AND attendance_status = 'In Progress' LIMIT 1", [req.user.id]);
  res.json({ now: T.nowStr(), today, shifts, clocked_in: open[0] || null });
});

const locRules = [
  body('lat').optional({ values: 'falsy' }).isFloat({ min: -90, max: 90 }).withMessage('Invalid latitude.'),
  body('lng').optional({ values: 'falsy' }).isFloat({ min: -180, max: 180 }).withMessage('Invalid longitude.'),
];
router.post('/attendance/clock-in', authorize('worker'), ...locRules, handleValidation, async (req, res) => {
  res.status(201).json(await svc.clockIn({ workerId: req.user.id, lat: req.body.lat, lng: req.body.lng, req }));
});
router.post('/attendance/clock-out', authorize('worker'), ...locRules, handleValidation, async (req, res) => {
  res.json(await svc.clockOut({ workerId: req.user.id, lat: req.body.lat, lng: req.body.lng, req }));
});
// Supervisor scans a worker's QR badge (clock in, or clock out if already in)
router.post('/attendance/scan', authorize('supervisor', 'admin'), body('code').isString().notEmpty().withMessage('Scan or type the badge code.'), handleValidation, async (req, res) => {
  res.json(await svc.scanBadge({ token: req.body.code, req, actor: req.user }));
});

router.put('/attendance/:id/approve', authorize('supervisor', 'admin'), async (req, res) => res.json(await svc.approve(req.params.id, req.user, req)));
router.put('/attendance/:id/reject', authorize('supervisor', 'admin'), body('note').isString().withMessage('Give a reason.'), handleValidation, async (req, res) => res.json(await svc.reject(req.params.id, req.user, req, req.body.note)));
router.put('/attendance/:id/request-correction', authorize('supervisor', 'admin'), body('note').isString().withMessage('Give a reason.'), handleValidation, async (req, res) => res.json(await svc.requestCorrection(req.params.id, req.user, req, req.body.note)));

// ---------- Corrections ----------
router.get('/corrections', async (req, res) => {
  const where = [], params = [];
  if (req.user.role === 'worker') { where.push('att.worker_id = ?'); params.push(req.user.id); }
  if (req.user.role === 'supervisor') { where.push('j.created_by = ?'); params.push(req.user.id); }
  if (['pending', 'approved', 'rejected'].includes(req.query.status)) { where.push('c.status = ?'); params.push(req.query.status); }
  res.json(await query(
    `SELECT c.*, att.work_date, w.full_name AS worker_name, j.title AS job_title, rb.full_name AS requested_by_name, rv.full_name AS reviewed_by_name, rb.role AS requested_by_role
     FROM attendance_corrections c JOIN attendance att ON att.id = c.attendance_id JOIN users w ON w.id = att.worker_id
     JOIN assignments a ON a.id = att.assignment_id JOIN jobs j ON j.id = a.job_id JOIN users rb ON rb.id = c.requested_by LEFT JOIN users rv ON rv.id = c.reviewed_by
     ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY c.created_at DESC LIMIT 300`, params));
});
router.post('/corrections', authorize('worker', 'supervisor'),
  body('attendance_id').isInt({ min: 1 }).withMessage('Choose an attendance record.'),
  body('proposed_clock_in').notEmpty().withMessage('Enter the corrected clock-in time.'),
  body('proposed_clock_out').notEmpty().withMessage('Enter the corrected clock-out time.'),
  body('reason').isString().withMessage('Give a reason.'), handleValidation,
  async (req, res) => res.status(201).json(await svc.createCorrection(req.user, req, req.body)));
router.put('/corrections/:id/decision', authorize('supervisor', 'admin'), body('decision').isIn(['approve', 'reject']).withMessage('Decision must be approve or reject.'), handleValidation,
  async (req, res) => res.json(await svc.decideCorrection(req.params.id, req.user, req, req.body.decision, req.body.note)));

module.exports = router;
