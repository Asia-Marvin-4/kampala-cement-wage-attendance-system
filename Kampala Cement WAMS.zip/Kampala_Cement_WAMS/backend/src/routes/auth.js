const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { body } = require('express-validator');
const rateLimit = require('express-rate-limit');
const env = require('../config/env');
const { pool, query, tx } = require('../config/db');
const { authenticate } = require('../middleware/auth');
const { handleValidation, strongPassword, PASSWORD_MESSAGE } = require('../middleware/validate');
const { HttpError, bad } = require('../utils/httpError');
const { audit } = require('../utils/audit');
const { createUser, hashPassword } = require('../services/userService');
const { notify } = require('../services/notificationService');

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: env.NODE_ENV === 'test' ? 1000 : 30, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many login attempts. Please wait 15 minutes and try again.' },
});

const phoneRule = body('phone').optional({ values: 'falsy' }).matches(/^\+?[0-9 ]{9,15}$/).withMessage('Enter a valid phone number.');

router.post('/register',
  body('full_name').trim().isLength({ min: 2, max: 120 }).withMessage('Enter your full name.'),
  body('email').trim().isEmail().withMessage('Enter a valid email address.'),
  phoneRule,
  body('password').custom(strongPassword).withMessage(PASSWORD_MESSAGE),
  handleValidation,
  async (req, res) => {
    const exists = await query('SELECT id FROM users WHERE email = ?', [req.body.email.toLowerCase()]);
    if (exists.length) throw new HttpError(409, 'An account with this email already exists.');
    // Self-registration is for workers only. An administrator must activate the account.
    const id = await tx((conn) => createUser(conn, { ...req.body, role: 'worker', status: 'pending' }));
    await audit({ req, userId: id, action: 'USER_REGISTERED', entity: 'users', entityId: id, next: { email: req.body.email, role: 'worker' } });
    const admins = await query("SELECT id FROM users WHERE role = 'admin' AND status = 'active'");
    for (const a of admins) await notify(a.id, 'activation', `${req.body.full_name} registered and is waiting for activation.`);
    res.status(201).json({ message: 'Registration received. An administrator will activate your account.' });
  });

router.post('/login', loginLimiter,
  body('email').trim().isEmail().withMessage('Enter a valid email address.'),
  body('password').isString().notEmpty().withMessage('Enter your password.'),
  handleValidation,
  async (req, res) => {
    const email = req.body.email.toLowerCase();
    const recent = await query("SELECT COUNT(*) AS n FROM audit_logs WHERE action = 'LOGIN_FAILED' AND entity_id = ? AND created_at > (NOW() - INTERVAL 15 MINUTE)", [email]);
    if (recent[0].n >= 5) throw new HttpError(429, 'This account is temporarily locked after too many failed attempts. Try again in 15 minutes.');
    const u = (await query('SELECT * FROM users WHERE email = ?', [email]))[0];
    const ok = u ? await bcrypt.compare(req.body.password, u.password_hash) : await bcrypt.compare(req.body.password, '$2a$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvalidinv');
    if (!u || !ok) {
      await audit({ req, userId: u ? u.id : null, action: 'LOGIN_FAILED', entity: 'users', entityId: email });
      throw new HttpError(401, 'Wrong email or password.');
    }
    if (u.status === 'pending') throw new HttpError(403, 'Your account is waiting for activation by an administrator.');
    if (u.status === 'inactive') throw new HttpError(403, 'This account has been deactivated. Contact an administrator.');
    const jti = crypto.randomBytes(16).toString('hex');
    const token = jwt.sign({ sub: u.id, role: u.role, jti }, env.JWT_SECRET, { expiresIn: `${env.JWT_EXPIRES_HOURS}h` });
    await audit({ req, userId: u.id, action: 'LOGIN', entity: 'users', entityId: u.id });
    res.json({ token, user: { id: u.id, full_name: u.full_name, email: u.email, role: u.role } });
  });

router.post('/logout', authenticate, async (req, res) => {
  await pool.query('INSERT IGNORE INTO revoked_tokens (jti, expires_at) VALUES (?, FROM_UNIXTIME(?))', [req.user.jti, req.user.exp]);
  await pool.query('DELETE FROM revoked_tokens WHERE expires_at < NOW()');
  await audit({ req, action: 'LOGOUT', entity: 'users', entityId: req.user.id });
  res.json({ message: 'Logged out.' });
});

router.get('/me', authenticate, (req, res) => {
  const { id, full_name, email, phone, role } = req.user;
  res.json({ id, full_name, email, phone, role });
});

router.post('/change-password', authenticate,
  body('current_password').notEmpty().withMessage('Enter your current password.'),
  body('new_password').custom(strongPassword).withMessage(PASSWORD_MESSAGE),
  handleValidation,
  async (req, res) => {
    const u = (await query('SELECT password_hash FROM users WHERE id = ?', [req.user.id]))[0];
    if (!(await bcrypt.compare(req.body.current_password, u.password_hash))) throw bad('Your current password is not correct.');
    await pool.query('UPDATE users SET password_hash = ? WHERE id = ?', [await hashPassword(req.body.new_password), req.user.id]);
    await audit({ req, action: 'PASSWORD_CHANGED', entity: 'users', entityId: req.user.id });
    res.json({ message: 'Password changed.' });
  });

module.exports = router;
