const router = require('express').Router();
const { pool, query } = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');
const { bad, notFound, forbidden } = require('../utils/httpError');
const { audit } = require('../utils/audit');
const { getRules, validateRule, META } = require('../services/rules');
const { runAutomation } = require('../services/scheduler');
const { toCsv } = require('../utils/csv');
const T = require('../utils/time');

router.use(authenticate);

// ---------- Notifications ----------
router.get('/notifications', async (req, res) => {
  const rows = await query('SELECT id, type, message, is_read, created_at FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 60', [req.user.id]);
  const unread = (await query('SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND is_read = 0', [req.user.id]))[0].n;
  res.json({ unread, items: rows });
});
router.put('/notifications/read-all', async (req, res) => {
  await pool.query('UPDATE notifications SET is_read = 1 WHERE user_id = ?', [req.user.id]);
  res.json({ ok: true });
});
router.put('/notifications/:id/read', async (req, res) => {
  await pool.query('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
  res.json({ ok: true });
});

// ---------- Wage and system rules (admin edits, others may read) ----------
router.get('/rules', authorize('admin', 'finance', 'supervisor'), async (req, res) => {
  const current = await getRules();
  const rows = await query('SELECT rule_key, updated_at FROM wage_rules');
  const upd = Object.fromEntries(rows.map((r) => [r.rule_key, r.updated_at]));
  res.json(Object.entries(META).map(([key, m]) => ({ key, value: String(current[key]), description: m.desc, type: m.type, updated_at: upd[key] || null })));
});
router.put('/rules/:key', authorize('admin'), async (req, res) => {
  const key = req.params.key;
  const value = validateRule(key, req.body.value);
  const before = (await getRules())[key];
  await pool.query('INSERT INTO wage_rules (rule_key, rule_value, description, updated_by) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE rule_value = VALUES(rule_value), updated_by = VALUES(updated_by)', [key, value, META[key].desc, req.user.id]);
  await audit({ req, action: 'RULE_CHANGED', entity: 'wage_rules', entityId: key, previous: { value: before }, next: { value } });
  res.json({ ok: true });
});

// ---------- Audit trail (read only) ----------
router.get('/audit', authorize('admin'), async (req, res) => {
  const where = [], params = [];
  if (req.query.action) { where.push('a.action = ?'); params.push(req.query.action); }
  if (req.query.user_id) { where.push('a.user_id = ?'); params.push(req.query.user_id); }
  if (req.query.from && T.isValidDate(req.query.from)) { where.push('a.created_at >= ?'); params.push(req.query.from + ' 00:00:00'); }
  if (req.query.to && T.isValidDate(req.query.to)) { where.push('a.created_at <= ?'); params.push(req.query.to + ' 23:59:59'); }
  const rows = await query(
    `SELECT a.*, u.full_name AS user_name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
     ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY a.id DESC LIMIT 300`, params);
  res.json(rows);
});
router.get('/audit/actions', authorize('admin'), async (req, res) => {
  res.json((await query('SELECT DISTINCT action FROM audit_logs ORDER BY action')).map((r) => r.action));
});
router.get('/audit/suspicious', authorize('admin'), async (req, res) => {
  const failed = await query(
    `SELECT entity_id AS email, COUNT(*) AS attempts, MAX(created_at) AS last_attempt, MAX(ip_address) AS ip_address
     FROM audit_logs WHERE action = 'LOGIN_FAILED' AND created_at > (NOW() - INTERVAL 24 HOUR) GROUP BY entity_id HAVING attempts >= 3 ORDER BY attempts DESC`);
  const location = await query(
    `SELECT att.id, att.work_date, u.full_name AS worker_name, att.clock_in, att.capture_method FROM attendance att JOIN users u ON u.id = att.worker_id
     WHERE att.location_flag = 1 ORDER BY att.id DESC LIMIT 25`);
  const rejected = await query(
    `SELECT u.full_name AS worker_name, COUNT(*) AS rejected_count FROM attendance att JOIN users u ON u.id = att.worker_id
     WHERE att.approval_status = 'Rejected' GROUP BY att.worker_id, u.full_name HAVING rejected_count >= 2 ORDER BY rejected_count DESC LIMIT 25`);
  res.json({ failed_logins: failed, outside_worksite: location, repeated_rejections: rejected });
});

router.post('/admin/run-automation', authorize('admin'), async (req, res) => {
  const result = await runAutomation();
  await audit({ req, action: 'AUTOMATION_RUN_MANUAL', next: result });
  res.json(result);
});

// ---------- Dashboards ----------
router.get('/dashboard', async (req, res) => {
  const role = req.user.role, uid = req.user.id, today = T.todayStr(), month = today.slice(0, 7);
  const one = async (sql, p = []) => (await query(sql, p))[0];
  const unread = (await one('SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND is_read = 0', [uid])).n;

  if (role === 'worker') {
    const wage = await one(`SELECT COALESCE(SUM(wc.total_pay),0) AS v FROM wage_calculations wc LEFT JOIN payroll_items pi ON pi.id = wc.payroll_item_id
                           WHERE wc.worker_id = ? AND (wc.payroll_item_id IS NULL OR pi.status = 'Unpaid')`, [uid]);
    const hours = await one(`SELECT COALESCE(SUM(total_hours),0) AS v FROM attendance WHERE worker_id = ? AND approval_status = 'Approved' AND work_date >= ?`, [uid, T.addDays(today, -6)]);
    const assignments = await query(`SELECT a.id, j.title, j.location, a.rate_type, a.rate FROM assignments a JOIN jobs j ON j.id = a.job_id WHERE a.worker_id = ? AND a.status = 'active' AND j.status = 'active'`, [uid]);
    const payments = await query(`SELECT pay.amount, pay.payment_date, pay.reference, pp.name AS period_name, ps.id AS payslip_id FROM payments pay JOIN payroll_items pi ON pi.id = pay.payroll_item_id JOIN payroll_periods pp ON pp.id = pi.period_id LEFT JOIN payslips ps ON ps.payroll_item_id = pi.id WHERE pi.worker_id = ? ORDER BY pay.id DESC LIMIT 5`, [uid]);
    return res.json({ role, unread, current_wage: wage.v, hours_last_7_days: hours.v, assignments, recent_payments: payments });
  }
  if (role === 'supervisor') {
    const own = 'j.created_by = ?';
    const j = `FROM attendance att JOIN assignments a ON a.id = att.assignment_id JOIN jobs j ON j.id = a.job_id`;
    return res.json({
      role, unread,
      workers: (await one(`SELECT COUNT(DISTINCT a.worker_id) AS n FROM assignments a JOIN jobs j ON j.id = a.job_id WHERE a.status = 'active' AND ${own}`, [uid])).n,
      on_shift: (await one(`SELECT COUNT(*) AS n ${j} WHERE att.attendance_status = 'In Progress' AND ${own}`, [uid])).n,
      pending_approvals: (await one(`SELECT COUNT(*) AS n ${j} WHERE att.approval_status = 'Pending Approval' AND att.attendance_status IN ('Completed','Missed Clock-out') AND ${own}`, [uid])).n,
      today_attendance: (await one(`SELECT COUNT(*) AS n ${j} WHERE att.work_date = ? AND att.attendance_status <> 'Absent' AND ${own}`, [today, uid])).n,
      active_jobs: (await one(`SELECT COUNT(*) AS n FROM jobs j WHERE j.status = 'active' AND ${own}`, [uid])).n,
      problems: {
        late_today: (await one(`SELECT COUNT(*) AS n ${j} WHERE att.work_date = ? AND att.is_late = 1 AND ${own}`, [today, uid])).n,
        absent_today: (await one(`SELECT COUNT(*) AS n ${j} WHERE att.work_date = ? AND att.attendance_status = 'Absent' AND ${own}`, [today, uid])).n,
        missed_clockout: (await one(`SELECT COUNT(*) AS n ${j} WHERE att.attendance_status = 'Missed Clock-out' AND ${own}`, [uid])).n,
        pending_corrections: (await one(`SELECT COUNT(*) AS n FROM attendance_corrections c JOIN attendance att ON att.id = c.attendance_id JOIN assignments a ON a.id = att.assignment_id JOIN jobs j ON j.id = a.job_id WHERE c.status = 'pending' AND ${own}`, [uid])).n,
      },
      wage_summary: await one(`SELECT COALESCE(SUM(wc.total_pay),0) AS month_total, COALESCE(SUM(wc.overtime_pay),0) AS month_overtime FROM wage_calculations wc JOIN assignments a ON a.id = wc.assignment_id JOIN jobs j ON j.id = a.job_id WHERE ${own} AND wc.work_date LIKE ?`, [uid, month + '%']),
    });
  }
  if (role === 'finance') {
    const cur = await one("SELECT id, name, status, start_date, end_date FROM payroll_periods WHERE status IN ('Draft','Approved') ORDER BY id DESC LIMIT 1");
    return res.json({
      role, unread, current_period: cur || null,
      pending_payroll: (await one('SELECT COALESCE(SUM(total_pay),0) AS v, COUNT(*) AS n FROM wage_calculations WHERE payroll_item_id IS NULL')),
      approved_payroll: (await one("SELECT COALESCE(SUM(pi.total_pay),0) AS v, COUNT(DISTINCT pp.id) AS n FROM payroll_items pi JOIN payroll_periods pp ON pp.id = pi.period_id WHERE pp.status = 'Approved'")),
      total_wages: (await one('SELECT COALESCE(SUM(total_pay),0) AS v FROM payroll_items')).v,
      paid_wages: (await one("SELECT COALESCE(SUM(total_pay),0) AS v FROM payroll_items WHERE status = 'Paid'")).v,
      unpaid_wages: (await one("SELECT COALESCE(SUM(total_pay),0) AS v FROM payroll_items WHERE status = 'Unpaid'")).v,
      recent_payments: await query('SELECT pay.amount, pay.payment_date, pay.reference, u.full_name AS worker_name FROM payments pay JOIN payroll_items pi ON pi.id = pay.payroll_item_id JOIN users u ON u.id = pi.worker_id ORDER BY pay.id DESC LIMIT 6'),
    });
  }
  // admin
  const roles = await query("SELECT role, COUNT(*) AS n FROM users WHERE status = 'active' GROUP BY role");
  const rc = Object.fromEntries(roles.map((r) => [r.role, r.n]));
  return res.json({
    role, unread,
    total_users: (await one('SELECT COUNT(*) AS n FROM users')).n,
    pending_activation: (await one("SELECT COUNT(*) AS n FROM users WHERE status = 'pending'")).n,
    workers: rc.worker || 0, supervisors: rc.supervisor || 0, finance_users: rc.finance || 0, admins: rc.admin || 0,
    active_jobs: (await one("SELECT COUNT(*) AS n FROM jobs WHERE status = 'active'")).n,
    attendance_today: await one("SELECT COUNT(*) AS records, SUM(attendance_status='In Progress') AS on_shift, SUM(attendance_status='Absent') AS absent, SUM(is_late=1) AS late FROM attendance WHERE work_date = ?", [today]),
    payroll: await one("SELECT COUNT(*) AS periods, SUM(status='Draft') AS draft, SUM(status='Approved') AS approved, SUM(status='Closed') AS closed FROM payroll_periods"),
    recent_activity: await query('SELECT a.action, a.entity, a.created_at, u.full_name AS user_name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id ORDER BY a.id DESC LIMIT 8'),
  });
});

// ---------- Reports (JSON, or CSV with ?format=csv) ----------
function reportScope(user, where, params) {
  if (user.role === 'supervisor') { where.push('j.created_by = ?'); params.push(user.id); }
  else if (!['finance', 'admin'].includes(user.role)) throw forbidden('Reports are not available for your role.');
}
function dateScope(q, col, where, params) {
  if (q.from && T.isValidDate(q.from)) { where.push(`${col} >= ?`); params.push(q.from); }
  if (q.to && T.isValidDate(q.to)) { where.push(`${col} <= ?`); params.push(q.to); }
}
function send(req, res, name, rows, columns) {
  if (req.query.format === 'csv') {
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${name}.csv"`);
    return res.send('\ufeff' + toCsv(rows, columns));
  }
  res.json(rows);
}

router.get('/reports/attendance', async (req, res) => {
  const where = [], params = [];
  reportScope(req.user, where, params); dateScope(req.query, 'att.work_date', where, params);
  if (req.query.job_id) { where.push('j.id = ?'); params.push(req.query.job_id); }
  const rows = await query(
    `SELECT att.work_date, u.full_name AS worker_name, wp.worker_code, j.title AS job_title, att.clock_in, att.clock_out, att.total_hours,
            att.attendance_status, IF(att.is_late,'Yes','No') AS late, att.approval_status, att.capture_method
     FROM attendance att JOIN users u ON u.id = att.worker_id LEFT JOIN worker_profiles wp ON wp.user_id = u.id
     JOIN assignments a ON a.id = att.assignment_id JOIN jobs j ON j.id = a.job_id
     ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY att.work_date DESC, u.full_name LIMIT 5000`, params);
  send(req, res, 'attendance-report', rows, [
    { key: 'work_date', label: 'Date' }, { key: 'worker_name', label: 'Worker' }, { key: 'worker_code', label: 'Worker ID' }, { key: 'job_title', label: 'Job' },
    { key: 'clock_in', label: 'Clock in' }, { key: 'clock_out', label: 'Clock out' }, { key: 'total_hours', label: 'Hours' },
    { key: 'attendance_status', label: 'Status' }, { key: 'late', label: 'Late' }, { key: 'approval_status', label: 'Approval' }, { key: 'capture_method', label: 'Captured by' }]);
});

router.get('/reports/wages', async (req, res) => {
  const where = [], params = [];
  reportScope(req.user, where, params); dateScope(req.query, 'wc.work_date', where, params);
  const rows = await query(
    `SELECT wc.work_date, u.full_name AS worker_name, wp.worker_code, j.title AS job_title, wc.rate_type, wc.rate, wc.total_hours, wc.normal_hours, wc.overtime_hours,
            wc.basic_pay, wc.overtime_pay, wc.total_pay, COALESCE(pi.status, 'Not in payroll') AS payment_status
     FROM wage_calculations wc JOIN users u ON u.id = wc.worker_id LEFT JOIN worker_profiles wp ON wp.user_id = u.id
     JOIN assignments a ON a.id = wc.assignment_id JOIN jobs j ON j.id = a.job_id LEFT JOIN payroll_items pi ON pi.id = wc.payroll_item_id
     ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY wc.work_date DESC, u.full_name LIMIT 5000`, params);
  send(req, res, 'wage-report', rows, [
    { key: 'work_date', label: 'Date' }, { key: 'worker_name', label: 'Worker' }, { key: 'worker_code', label: 'Worker ID' }, { key: 'job_title', label: 'Job' },
    { key: 'rate_type', label: 'Rate type' }, { key: 'rate', label: 'Rate (UGX)' }, { key: 'total_hours', label: 'Hours' }, { key: 'normal_hours', label: 'Normal hours' },
    { key: 'overtime_hours', label: 'Overtime hours' }, { key: 'basic_pay', label: 'Basic pay' }, { key: 'overtime_pay', label: 'Overtime pay' },
    { key: 'total_pay', label: 'Total pay' }, { key: 'payment_status', label: 'Payment' }]);
});

router.get('/reports/overtime', async (req, res) => {
  const where = ['wc.overtime_hours > 0'], params = [];
  reportScope(req.user, where, params); dateScope(req.query, 'wc.work_date', where, params);
  const rows = await query(
    `SELECT u.full_name AS worker_name, wp.worker_code, COUNT(*) AS shifts_with_overtime, SUM(wc.overtime_hours) AS overtime_hours, SUM(wc.overtime_pay) AS overtime_pay
     FROM wage_calculations wc JOIN users u ON u.id = wc.worker_id LEFT JOIN worker_profiles wp ON wp.user_id = u.id
     JOIN assignments a ON a.id = wc.assignment_id JOIN jobs j ON j.id = a.job_id
     WHERE ${where.join(' AND ')} GROUP BY wc.worker_id, u.full_name, wp.worker_code ORDER BY overtime_hours DESC`, params);
  send(req, res, 'overtime-report', rows, [
    { key: 'worker_name', label: 'Worker' }, { key: 'worker_code', label: 'Worker ID' }, { key: 'shifts_with_overtime', label: 'Shifts with overtime' },
    { key: 'overtime_hours', label: 'Overtime hours' }, { key: 'overtime_pay', label: 'Overtime pay (UGX)' }]);
});

router.get('/reports/payroll/:id', authorize('finance', 'admin'), async (req, res) => {
  const rows = await query(
    `SELECT pp.name AS payroll, u.full_name AS worker_name, wp.worker_code, pi.days_worked, pi.total_hours, pi.normal_pay, pi.overtime_pay, pi.total_pay, pi.status,
            pay.payment_date, pay.method, pay.reference
     FROM payroll_items pi JOIN payroll_periods pp ON pp.id = pi.period_id JOIN users u ON u.id = pi.worker_id LEFT JOIN worker_profiles wp ON wp.user_id = u.id
     LEFT JOIN payments pay ON pay.payroll_item_id = pi.id WHERE pi.period_id = ? ORDER BY u.full_name`, [req.params.id]);
  if (!rows.length) throw notFound('Payroll not found.');
  send(req, res, 'payroll-report', rows, [
    { key: 'payroll', label: 'Payroll' }, { key: 'worker_name', label: 'Worker' }, { key: 'worker_code', label: 'Worker ID' }, { key: 'days_worked', label: 'Days' },
    { key: 'total_hours', label: 'Hours' }, { key: 'normal_pay', label: 'Normal pay' }, { key: 'overtime_pay', label: 'Overtime pay' }, { key: 'total_pay', label: 'Total pay' },
    { key: 'status', label: 'Status' }, { key: 'payment_date', label: 'Payment date' }, { key: 'method', label: 'Method' }, { key: 'reference', label: 'Reference' }]);
});

module.exports = router;
