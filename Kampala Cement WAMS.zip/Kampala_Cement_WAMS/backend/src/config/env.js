const path = require('path');
const crypto = require('crypto');
require('dotenv').config({ path: path.join(__dirname, '..', '..', '.env'), quiet: true });

const env = {
  PORT: parseInt(process.env.PORT || '3000', 10),
  NODE_ENV: process.env.NODE_ENV || 'development',
  DB_HOST: process.env.DB_HOST || 'localhost',
  DB_PORT: parseInt(process.env.DB_PORT || '3306', 10),
  DB_USER: process.env.DB_USER || 'root',
  DB_PASSWORD: process.env.DB_PASSWORD || '',
  DB_NAME: process.env.DB_NAME || 'kc_wams',
  JWT_SECRET: process.env.JWT_SECRET,
  JWT_EXPIRES_HOURS: parseInt(process.env.JWT_EXPIRES_HOURS || '8', 10),
  SMS_PROVIDER: (process.env.SMS_PROVIDER || 'none').toLowerCase(),
  SMS_API_KEY: process.env.SMS_API_KEY || '',
  SMS_API_SECRET: process.env.SMS_API_SECRET || '',
  SMS_FROM: process.env.SMS_FROM || '',
  AUTOMATION_ENABLED: (process.env.AUTOMATION_ENABLED || 'true') === 'true',
  AUTOMATION_CRON: process.env.AUTOMATION_CRON || '*/10 * * * *',
  TIMEZONE: 'Africa/Kampala',
};

if (!env.JWT_SECRET || env.JWT_SECRET.startsWith('change-this')) {
  if (env.NODE_ENV === 'production') {
    throw new Error('JWT_SECRET must be set to a long random value in production.');
  }
  env.JWT_SECRET = crypto.randomBytes(32).toString('hex');
  console.warn('[warn] JWT_SECRET not set in .env. Using a temporary secret: everyone will be logged out when the server restarts.');
}

module.exports = env;
