const mysql = require('mysql2/promise');
const env = require('./env');

const pool = mysql.createPool({
  host: env.DB_HOST,
  port: env.DB_PORT,
  user: env.DB_USER,
  password: env.DB_PASSWORD,
  database: env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  dateStrings: true,      // DATE/DATETIME come back as plain text, no timezone surprises
  decimalNumbers: true,   // DECIMAL columns come back as numbers
});

// Every connection uses Kampala time (UTC+3) so stored times match what people see on the clock
pool.pool.on('connection', (c) => c.query("SET time_zone = '+03:00'"));

// Run a query with parameters (values are always escaped: protects against SQL injection)
async function query(sql, params = [], conn = pool) {
  const [rows] = await conn.query(sql, params);
  return rows;
}

// Run several queries as one all-or-nothing transaction
async function tx(fn) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

module.exports = { pool, query, tx };
