const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const env = require('./config/env');
const { notFoundHandler, errorHandler } = require('./middleware/errorHandler');

const app = express();
app.set('trust proxy', false);

app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      'script-src': ["'self'"],
      'img-src': ["'self'", 'data:'],
      'upgrade-insecure-requests': null,   // lets the app run over plain http://localhost
    },
  },
  hsts: env.NODE_ENV === 'production',
}));
app.use(cors({ origin: false }));
app.use(express.json({ limit: '100kb' }));

app.use('/api', rateLimit({ windowMs: 60 * 1000, limit: env.NODE_ENV === 'test' ? 100000 : 300, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many requests. Please slow down.' } }));

app.get('/api/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));
app.use('/api/auth', require('./routes/auth'));
app.use('/api', require('./routes/users'));
app.use('/api', require('./routes/jobs'));
app.use('/api', require('./routes/attendance'));
app.use('/api', require('./routes/money'));
app.use('/api', require('./routes/misc'));

// Frontend files and local copies of Bootstrap, Roboto font and the QR reader (work without internet)
const nm = path.join(__dirname, '..', 'node_modules');
app.use('/vendor/bootstrap', express.static(path.join(nm, 'bootstrap', 'dist')));
app.use('/vendor/roboto', express.static(path.join(nm, '@fontsource', 'roboto')));
app.use('/vendor/jsqr', express.static(path.join(nm, 'jsqr', 'dist')));
app.use(express.static(path.join(__dirname, '..', '..', 'frontend')));

app.use(notFoundHandler);
app.use(errorHandler);

module.exports = app;
