const { pool } = require('../config/db');

function clientIp(req) {
  if (!req) return null;
  return (req.ip || req.socket?.remoteAddress || '').replace('::ffff:', '') || null;
}

// Writes one row to the audit trail. Never throws (an audit failure must not break the user's action).
async function audit({ req, userId, action, entity = null, entityId = null, previous = null, next = null, conn = pool }) {
  try {
    const uid = userId ?? req?.user?.id ?? null;
    await conn.query(
      'INSERT INTO audit_logs (user_id, action, entity, entity_id, previous_value, new_value, ip_address) VALUES (?,?,?,?,?,?,?)',
      [uid, action, entity, entityId === null ? null : String(entityId),
        previous === null ? null : JSON.stringify(previous),
        next === null ? null : JSON.stringify(next), clientIp(req)]
    );
  } catch (err) {
    console.error('[audit] failed to write log:', err.message);
  }
}
module.exports = { audit, clientIp };
