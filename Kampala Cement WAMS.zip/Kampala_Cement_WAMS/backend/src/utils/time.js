// All stored date-times are plain "YYYY-MM-DD HH:MM:SS" text in Kampala local time.
const TZ = 'Africa/Kampala';
const fmt = new Intl.DateTimeFormat('en-CA', {
  timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit',
  hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23',
});

function parts(date = new Date()) {
  const o = {};
  for (const p of fmt.formatToParts(date)) o[p.type] = p.value;
  return o;
}
function nowStr(date = new Date()) {
  const p = parts(date);
  return `${p.year}-${p.month}-${p.day} ${p.hour}:${p.minute}:${p.second}`;
}
function todayStr(date = new Date()) {
  const p = parts(date);
  return `${p.year}-${p.month}-${p.day}`;
}
// Treat the text as plain numbers (no timezone) so differences are exact
function toMs(str) {
  const m = /^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?/.exec(str || '');
  if (!m) return NaN;
  return Date.UTC(+m[1], +m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0));
}
function fromMs(ms) {
  const d = new Date(ms);
  const z = (n) => String(n).padStart(2, '0');
  return `${d.getUTCFullYear()}-${z(d.getUTCMonth() + 1)}-${z(d.getUTCDate())} ${z(d.getUTCHours())}:${z(d.getUTCMinutes())}:${z(d.getUTCSeconds())}`;
}
function hoursBetween(a, b) {
  const h = (toMs(b) - toMs(a)) / 3600000;
  return Math.round(h * 100) / 100;
}
function addMinutes(str, minutes) { return fromMs(toMs(str) + minutes * 60000); }
function combine(date, time) {
  const t = String(time).slice(0, 8);
  return `${date} ${t.length === 5 ? t + ':00' : t}`;
}
function isValidDate(s) { return /^\d{4}-\d{2}-\d{2}$/.test(s || '') && !isNaN(toMs(s)); }
function isValidDateTime(s) { return /^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(:\d{2})?$/.test(s || '') && !isNaN(toMs(s)); }
function normalizeDateTime(s) {
  const t = s.replace('T', ' ');
  return t.length === 16 ? t + ':00' : t;
}
function addDays(dateStr, n) { return fromMs(toMs(dateStr) + n * 86400000).slice(0, 10); }

module.exports = { nowStr, todayStr, toMs, fromMs, hoursBetween, addMinutes, combine, isValidDate, isValidDateTime, normalizeDateTime, addDays };
