@echo off
title Setup - Digital Wage and Attendance System
cd /d "%~dp0backend"
echo.
echo === Step 1: install packages (skipped if already present) ===
if not exist node_modules (
  call npm install
)
echo.
echo === Step 2: create database, tables and demo data ===
echo (MySQL must be running. In XAMPP click START next to MySQL.)
call node scripts\setup-db.js
echo.
echo If you saw "Database setup finished", double-click start.bat next.
pause
