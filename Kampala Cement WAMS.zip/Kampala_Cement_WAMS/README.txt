DIGITAL WAGE AND ATTENDANCE MANAGEMENT SYSTEM
Case study: Kampala Cement   |   Academic prototype (BSc Information Technology)

All demo data in this package is TEST/DEMO DATA. It is not real Kampala Cement data.

--------------------------------------------------------------
1. WHAT YOU NEED (install once)
--------------------------------------------------------------
a) Node.js 18 or newer (LTS version).  Download: https://nodejs.org
   Check it:  open Command Prompt and type   node -v
b) MySQL 8 or MariaDB. The easiest way on Windows is XAMPP (https://www.apachefriends.org):
   install it, open the XAMPP Control Panel and click START next to MySQL.
   (XAMPP's default is user root with an EMPTY password, which is what this package expects.)

--------------------------------------------------------------
2. SET UP AND RUN (Windows)
--------------------------------------------------------------
1. Extract the zip folder anywhere, for example C:\kc-wams
2. Make sure MySQL is running (green in XAMPP).
3. Double-click   setup.bat    (first time only). It installs the packages (if needed), creates the
   database, all tables, the default wage rules and the demo data.
4. Double-click   start.bat     The system starts. Open your browser at:
        http://localhost:3000
5. To stop the system, close the black window (or press Ctrl+C in it).

Do it by hand instead (any operating system):
        cd backend
        npm install              (only needed if the node_modules folder is missing)
        npm run setup-db
        npm start

If your MySQL has a password, or a different user, open  backend\.env  in Notepad and change
DB_USER and DB_PASSWORD, then run setup again.

--------------------------------------------------------------
3. DEMO LOGINS (TEST/DEMO DATA)
--------------------------------------------------------------
  Administrator    admin@wams.test        Admin@12345
  Supervisor       supervisor@wams.test   Super@12345
  Finance officer  finance@wams.test      Finance@12345
  Workers          worker1@wams.test, worker2@wams.test, worker3@wams.test     Worker@12345

Change these passwords before showing the system to anyone outside your project group.
To start again from a clean demo:   cd backend   then   npm run setup-db -- --reset
For a database with no demo data:   npm run setup-db -- --reset --no-demo
(this creates only one administrator: admin@wams.test / Admin@12345)

--------------------------------------------------------------
4. TRY THE COMPLETE WORKFLOW (about 10 minutes)
--------------------------------------------------------------
 1. Log in as the SUPERVISOR. Open Jobs and create a job, then Assignments and assign a worker with a
    rate, then Shifts and create a shift for today (the demo already has open shifts for today).
 2. Log in as WORKER ONE (use a second browser or a private window). On the dashboard press Clock in,
    then Clock out.
 3. Back as the SUPERVISOR open Attendance and press Approve. The wage engine calculates the pay
    automatically.
 4. As the worker, open My wages and press "How?" to see the full calculation.
 5. Log in as FINANCE. Open Payroll, press Create payroll, then Approve payroll, then Pay all
    (or record each payment). Payslips are generated automatically.
 6. As the worker, open Payments & payslips and download the PDF payslip.
 7. Log in as the ADMINISTRATOR and open Audit log to see every important action, Users to
    activate accounts, and Wage & system rules to change the overtime multiplier or normal hours.
 8. QR clock-in: the worker opens My QR badge. The supervisor opens QR scan station and scans it
    with the laptop camera (or types the badge code shown under the QR image).

--------------------------------------------------------------
5. RUN THE AUTOMATED TESTS
--------------------------------------------------------------
        cd backend
        npm test
The tests create their own temporary databases (kc_wams_test, kc_wams_perf) and do not touch your
main data. See docs\05_TESTING.txt for the list of test cases and results.

--------------------------------------------------------------
6. FOLDERS
--------------------------------------------------------------
  backend\src\        server code (routes, services, middleware, config)
  backend\scripts\    database setup script
  backend\tests\      automated tests
  frontend\           the web pages (HTML, CSS, JavaScript)
  database\schema.sql the database design (tables)
  docs\               requirements, architecture, database, API, testing, user manual, security

--------------------------------------------------------------
7. COMMON PROBLEMS
--------------------------------------------------------------
"Could not connect to the database"  -> MySQL is not running, or DB_USER / DB_PASSWORD in backend\.env
                                         are wrong. Start MySQL in XAMPP and check .env.
"Port 3000 already in use"           -> change PORT in backend\.env (for example 3001) and use that port.
"The database tables do not exist"   -> run setup.bat (or npm run setup-db) first.
Camera does not start on the scan page -> allow camera access in the browser. The camera works on
                                         http://localhost; on another computer HTTPS is required.
        Use the badge code box as a fallback.
You are logged out after restarting the server -> set JWT_SECRET in backend\.env (the supplied file
                                         already has one).

--------------------------------------------------------------
8. HONEST NOTES FOR YOUR REPORT
--------------------------------------------------------------
- Everything described in this package has been implemented and tested in the author's test
  environment (see docs\05_TESTING.txt). Re-run the tests on your own laptop and report YOUR results.
- SMS sending is built (Twilio) but switched off by default and was not tested against a real SMS
  account. The system works without it; notifications always appear inside the system.
- The optional location check is built but needs a real phone with GPS to demonstrate.
- Deployment to a public server (HTTPS, domain) is described in docs\07_DEPLOYMENT_AND_SECURITY.txt
  but has not been done.
- The usability (SUS) evaluation has NOT been done. It needs real participants. Do not invent results.
- Kampala Cement does not use this system. It is an academic prototype built for the case study.
