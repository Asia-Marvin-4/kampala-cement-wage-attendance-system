@echo off
title Digital Wage and Attendance System (close this window to stop)
cd /d "%~dp0backend"
start "" http://localhost:3000
call node src\server.js
pause
