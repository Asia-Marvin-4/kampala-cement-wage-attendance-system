(function () {
  const $ = (id) => document.getElementById(id);
  const msg = (text, type) => { $('msg').innerHTML = text ? `<div class="alert alert-${type || 'danger'} py-2">${text.replace(/</g, '&lt;')}</div>` : ''; };
  if (localStorage.getItem('wams_token')) location.replace('/app.html');

  document.querySelectorAll('[data-tab]').forEach((b) => b.addEventListener('click', () => {
    document.querySelectorAll('[data-tab]').forEach((x) => x.classList.toggle('active', x === b));
    $('loginForm').classList.toggle('d-none', b.dataset.tab !== 'login');
    $('registerForm').classList.toggle('d-none', b.dataset.tab !== 'register');
    msg('');
  }));

  async function post(path, body) {
    const res = await fetch('/api/auth/' + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Something went wrong.');
    return data;
  }
  $('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault(); msg('');
    try {
      const d = await post('login', { email: $('lemail').value, password: $('lpass').value });
      localStorage.setItem('wams_token', d.token);
      localStorage.setItem('wams_user', JSON.stringify(d.user));
      location.replace('/app.html');
    } catch (err) { msg(err.message); }
  });
  $('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault(); msg('');
    try {
      const d = await post('register', { full_name: $('rname').value, email: $('remail').value, phone: $('rphone').value, password: $('rpass').value });
      msg(d.message, 'success'); e.target.reset();
    } catch (err) { msg(err.message); }
  });
})();
