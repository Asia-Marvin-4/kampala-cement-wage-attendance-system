// Worker screens
App.nav.worker = [
  { id: 'dashboard', label: 'Dashboard' }, { id: 'jobs', label: 'My jobs & shifts' }, { id: 'attendance', label: 'My attendance' },
  { id: 'wages', label: 'My wages' }, { id: 'payments', label: 'Payments & payslips' }, { id: 'badge', label: 'My QR badge' }, { id: 'notifications', label: 'Notifications' },
];

function getLocation() {
  return new Promise((resolve) => {
    if (!navigator.geolocation) return resolve({});
    navigator.geolocation.getCurrentPosition((p) => resolve({ lat: p.coords.latitude, lng: p.coords.longitude }), () => resolve({}), { timeout: 6000, maximumAge: 60000 });
  });
}

App.views['worker.dashboard'] = async (box) => {
  const [dash, today] = await Promise.all([App.get('/dashboard'), App.get('/attendance/today')]);
  const open = today.clocked_in;
  const free = today.shifts.filter((s) => !s.attendance_id);
  const clockBlock = open
    ? `<div class="mb-2">You clocked in at <strong>${App.t5(open.clock_in.slice(11))}</strong>. Time worked so far: <strong id="elapsed">-</strong></div>
       <button class="btn btn-danger btn-clock" data-act="out">Clock out</button>`
    : free.length
      ? `<div class="mb-2">Next shift: <strong>${App.esc(free[0].job_title)}</strong>, ${App.t5(free[0].start_time)} to ${App.t5(free[0].end_time)}</div>
         <button class="btn btn-success btn-clock" data-act="in">Clock in</button>`
      : `<div class="mb-1">${today.shifts.length ? 'Your shift(s) for today are already recorded.' : 'You have no shift scheduled today.'}</div><div class="small opacity-75">Ask your supervisor if you think this is wrong.</div>`;
  box.innerHTML = App.title(`Welcome, ${App.user.full_name.split(' ')[0]}`) + `
    <div class="card clock-card mb-3"><div class="card-body text-center py-4">
      <div class="small opacity-75">${today.today} (Kampala time)</div><div class="clock-time" id="clockNow">${today.now.slice(11, 19)}</div>
      <div class="my-3">${clockBlock}</div>
      <div class="form-check d-inline-block text-start small"><input class="form-check-input" type="checkbox" id="shareLoc"><label class="form-check-label" for="shareLoc">Share my location with this clock-in (optional)</label></div>
    </div></div>
    <div class="row g-3 mb-3">${App.stat('Wage not yet paid', App.money(dash.current_wage), 'approved attendance')}${App.stat('Hours (last 7 days)', App.num(dash.hours_last_7_days), 'approved')}
      ${App.stat('Active jobs', dash.assignments.length)}${App.stat('Unread alerts', dash.unread)}</div>
    <div class="row g-3"><div class="col-lg-6">${App.card('Current assignment(s)', App.table([
      { label: 'Job', key: 'title' }, { label: 'Location', key: 'location' }, { label: 'Rate', render: (a) => App.rateLabel(a.rate_type, a.rate) }], dash.assignments, 'No active assignment.'))}</div>
    <div class="col-lg-6">${App.card('Recent payments', App.table([
      { label: 'Date', key: 'payment_date' }, { label: 'Payroll', key: 'period_name' }, { label: 'Amount', render: (p) => App.money(p.amount) },
      { label: '', render: (p) => (p.payslip_id ? `<button class="btn btn-sm btn-outline-primary" data-act="slip" data-id="${p.payslip_id}">Payslip</button>` : '') }], dash.recent_payments, 'No payments yet.'))}</div></div>`;

  const tick = () => {
    const p = App.nowParts(); const el = box.querySelector('#clockNow'); if (el) el.textContent = `${p.hour}:${p.minute}:${new Date().toTimeString().slice(6, 8)}`;
    const e = box.querySelector('#elapsed');
    if (e && open) { const [h, m] = [+p.hour, +p.minute]; const [ih, im] = [+open.clock_in.slice(11, 13), +open.clock_in.slice(14, 16)]; let mins = h * 60 + m - (ih * 60 + im); if (mins < 0) mins += 1440; e.textContent = `${Math.floor(mins / 60)} h ${mins % 60} min`; }
  };
  tick(); App._timer = setInterval(tick, 1000);
  const where = async () => (box.querySelector('#shareLoc').checked ? getLocation() : {});
  App.on(box, {
    in: async () => { const r = await App.post('/attendance/clock-in', await where()); App.toast(`Clocked in at ${r.clock_in.slice(11, 16)}${r.is_late ? ' (late)' : ''}.`); App.refresh(); },
    out: async () => { const r = await App.post('/attendance/clock-out', await where()); App.toast(`Clocked out. Hours worked: ${r.total_hours}.`); App.refresh(); },
    slip: async (d) => App.download(`/payslips/${d.id}/download`, `payslip-${d.id}.pdf`),
  });
};

App.views['worker.jobs'] = async (box) => {
  const today = App.today();
  const [asg, shifts] = await Promise.all([App.get('/assignments'), App.get('/shifts' + App.qs({ from: today }))]);
  box.innerHTML = App.title('My jobs & shifts')
    + App.card('My assignments', App.table([{ label: 'Job', key: 'job_title' }, { label: 'Location', key: 'location' }, { label: 'Rate', render: (a) => App.rateLabel(a.rate_type, a.rate) }, { label: 'Status', render: (a) => App.badge(a.status) }], asg, 'You have not been assigned to any job yet.'))
    + App.card('Upcoming shifts', App.table([{ label: 'Date', key: 'shift_date' }, { label: 'Job', key: 'job_title' }, { label: 'Start', render: (s) => App.t5(s.start_time) }, { label: 'End', render: (s) => App.t5(s.end_time) }, { label: 'Attendance', render: (s) => (s.attendance_status ? App.badge(s.attendance_status) : '<span class="text-muted">not yet</span>') }], shifts.slice().reverse(), 'No upcoming shifts.'));
};

function correctionModal(a, after) {
  const toLocal = (s) => (s ? s.slice(0, 16).replace(' ', 'T') : '');
  return App.modal({
    title: `Request correction for ${a.work_date}`, submit: 'Send request',
    html: '<p class="small text-muted">Enter the correct times. Your supervisor will review the request. The original times stay in the audit trail.</p>',
    fields: [
      { name: 'proposed_clock_in', label: 'Correct clock-in', type: 'datetime-local', value: toLocal(a.clock_in) || `${a.work_date}T${App.t5(a.shift_start)}`, required: true },
      { name: 'proposed_clock_out', label: 'Correct clock-out', type: 'datetime-local', value: toLocal(a.clock_out) || `${a.work_date}T${App.t5(a.shift_end)}`, required: true },
      { name: 'reason', label: 'Reason', type: 'textarea', required: true }],
    onSubmit: async (v) => { await App.post('/corrections', { attendance_id: a.id, ...v }); App.toast('Correction request sent.'); },
  }).then((ok) => ok && after());
}

App.views['worker.attendance'] = async (box) => {
  const [rows, corr] = await Promise.all([App.get('/attendance'), App.get('/corrections')]);
  const pend = new Set(corr.filter((c) => c.status === 'pending').map((c) => c.attendance_id));
  box.innerHTML = App.title('My attendance') + App.card('Attendance history', App.table([
    { label: 'Date', key: 'work_date' }, { label: 'Job', key: 'job_title' }, { label: 'In', render: (a) => App.t5((a.clock_in || '').slice(11)) }, { label: 'Out', render: (a) => App.t5((a.clock_out || '').slice(11)) },
    { label: 'Hours', render: (a) => (a.total_hours ?? '-') }, { label: 'Status', render: (a) => App.badge(a.attendance_status) + (a.is_late ? ' <span class="badge badge-late">Late</span>' : '') },
    { label: 'Approval', render: (a) => App.badge(a.approval_status) + (a.supervisor_note ? `<div class="small text-muted">${App.esc(a.supervisor_note)}</div>` : '') },
    { label: '', render: (a) => (!a.payroll_item_id && a.attendance_status !== 'In Progress' && ['Pending Approval', 'Correction Requested', 'Rejected'].includes(a.approval_status) || a.attendance_status === 'Absent' && !a.payroll_item_id
      ? (pend.has(a.id) ? '<span class="small text-muted">correction pending</span>' : `<button class="btn btn-sm btn-outline-secondary" data-act="corr" data-id="${a.id}">Request correction</button>`) : '') }], rows, 'No attendance yet.'))
    + App.card('My correction requests', App.table([{ label: 'Date', key: 'work_date' }, { label: 'Asked for', render: (c) => `${App.dt(c.proposed_clock_in)} to ${App.t5(c.proposed_clock_out.slice(11))}` }, { label: 'Reason', key: 'reason' }, { label: 'Status', render: (c) => App.badge(c.status) }], corr, 'No correction requests.'));
  App.on(box, { corr: (d) => correctionModal(rows.find((r) => String(r.id) === d.id), App.refresh) });
};

function wageExplain(w) {
  const lines = [`Hours worked: ${w.total_hours} (normal ${w.normal_hours} + overtime ${w.overtime_hours})`];
  if (w.rate_type === 'hourly') lines.push(`Basic pay: ${w.normal_hours} h x ${App.money(w.rate)} = ${App.money(w.basic_pay)}`);
  else lines.push(`Basic pay: daily rate ${App.money(w.rate)} = ${App.money(w.basic_pay)}`);
  if (w.overtime_hours > 0) lines.push(`Overtime pay: ${w.overtime_hours} h x ${App.money(w.rate_type === 'hourly' ? w.rate : Math.round(w.rate / w.normal_hours * 100) / 100)} x ${w.overtime_multiplier} = ${App.money(w.overtime_pay)}`);
  lines.push(`<strong>Total pay: ${App.money(w.total_pay)}</strong>`);
  return `<p class="mb-1"><strong>${App.esc(w.job_title)}</strong>, ${w.work_date}<br><span class="text-muted small">Clock in ${App.dt(w.clock_in)} &middot; Clock out ${App.dt(w.clock_out)}</span></p>` + lines.map((l) => `<div>${l}</div>`).join('') + `<hr><div class="small text-muted">Payment status: ${App.esc(w.payment_status || 'Not in payroll yet')}${w.payroll_name ? ' (' + App.esc(w.payroll_name) + ')' : ''}</div>`;
}
App.wageExplain = wageExplain;

App.views['worker.wages'] = async (box) => {
  const rows = await App.get('/wages');
  const total = rows.reduce((s, r) => s + r.total_pay, 0);
  box.innerHTML = App.title('My wages') + App.card('Calculated wages (from approved attendance)', App.table([
    { label: 'Date', key: 'work_date' }, { label: 'Job', key: 'job_title' }, { label: 'Hours', key: 'total_hours' }, { label: 'Normal', key: 'normal_hours' }, { label: 'OT', key: 'overtime_hours' },
    { label: 'Basic', render: (w) => App.num(w.basic_pay) }, { label: 'Overtime', render: (w) => App.num(w.overtime_pay) }, { label: 'Total (UGX)', render: (w) => `<strong>${App.num(w.total_pay)}</strong>` },
    { label: 'Payment', render: (w) => App.badge(w.payment_status || 'Unpaid') }, { label: '', render: (w) => `<button class="btn btn-sm btn-outline-primary" data-act="how" data-id="${w.id}">How?</button>` }], rows, 'No approved attendance yet, so no wages calculated.')
    + `<div class="p-3 border-top fw-bold">Total earned (all records): ${App.money(total)}</div>`);
  App.on(box, { how: (d) => App.modal({ title: 'How this wage was calculated', html: wageExplain(rows.find((r) => String(r.id) === d.id)), noFooter: true }) });
};

App.views['worker.payments'] = async (box) => {
  const [pays, slips] = await Promise.all([App.get('/payments'), App.get('/payslips')]);
  box.innerHTML = App.title('Payments & payslips')
    + App.card('Payment history', App.table([{ label: 'Date', key: 'payment_date' }, { label: 'Payroll', key: 'period_name' }, { label: 'Amount', render: (p) => App.money(p.amount) }, { label: 'Method', render: (p) => App.ucfirst(p.method) }, { label: 'Reference', key: 'reference' }], pays, 'No payments yet.'))
    + App.card('My payslips', App.table([{ label: 'Payslip', key: 'payslip_no' }, { label: 'Period', render: (s) => `${App.esc(s.period_name)} (${s.start_date} to ${s.end_date})` }, { label: 'Total', render: (s) => App.money(s.total_pay) },
      { label: '', render: (s) => `<button class="btn btn-sm btn-primary" style="background:#1f3a5f;border-color:#1f3a5f" data-act="pdf" data-id="${s.id}" data-no="${App.esc(s.payslip_no)}">Download PDF</button>` }], slips, 'No payslips yet.'));
  App.on(box, { pdf: (d) => App.download(`/payslips/${d.id}/download`, `${d.no}.pdf`) });
};

App.views['worker.badge'] = async (box) => {
  const b = await App.get('/workers/me/badge');
  box.innerHTML = App.title('My QR badge', '<button class="btn btn-outline-secondary btn-sm no-print" data-act="print">Print</button>')
    + `<div class="card"><div class="card-body text-center qr-box"><img alt="QR badge" src="${b.qr}"><h5 class="mt-3 mb-0">${App.esc(b.worker_name)}</h5><div class="text-muted">${App.esc(b.worker_code)}</div><div class="small mt-2">Badge code: <code>${App.esc(b.token)}</code></div>
    <p class="small text-muted mt-3 mb-0">Your supervisor can scan this code at the gate or work area to clock you in and out. Do not share a photo of it.</p></div></div>`;
  App.on(box, { print: () => window.print() });
};
