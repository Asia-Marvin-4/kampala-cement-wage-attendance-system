// System administrator screens
App.nav.admin = [
  { id: 'dashboard', label: 'Dashboard' }, { id: 'users', label: 'Users' }, { id: 'rules', label: 'Wage & system rules' }, { id: 'attendance', label: 'Attendance' },
  { id: 'corrections', label: 'Corrections' }, { id: 'audit', label: 'Audit log' }, { id: 'security', label: 'Security & automation' }, { id: 'reports', label: 'Reports' }, { id: 'notifications', label: 'Notifications' },
];

App.views['admin.dashboard'] = async (box) => {
  const d = await App.get('/dashboard');
  const a = d.attendance_today, p = d.payroll;
  box.innerHTML = App.title('Administrator dashboard') + `<div class="row g-3 mb-3">
    ${App.stat('Total users', d.total_users, d.pending_activation ? `<a href="#/users?status=pending">${d.pending_activation} waiting for activation</a>` : 'none waiting')}${App.stat('Workers', d.workers)}${App.stat('Supervisors', d.supervisors)}${App.stat('Finance users', d.finance_users)}
    ${App.stat('Active jobs', d.active_jobs)}${App.stat('Attendance today', a.records || 0, `on shift ${a.on_shift || 0}, absent ${a.absent || 0}, late ${a.late || 0}`)}
    ${App.stat('Payrolls', p.periods || 0, `draft ${p.draft || 0}, approved ${p.approved || 0}, closed ${p.closed || 0}`)}</div>`
    + App.card('Recent system activity', App.table([{ label: 'When', render: (x) => App.dt(x.created_at) }, { label: 'User', render: (x) => App.esc(x.user_name || 'System') }, { label: 'Action', render: (x) => `<code>${App.esc(x.action)}</code>` }, { label: 'Entity', key: 'entity' }], d.recent_activity), '<a class="btn btn-sm btn-outline-primary" href="#/audit">Open audit log</a>');
};

function userModal(u, after) {
  return App.modal({
    title: u ? 'Edit user' : 'Create user', submit: u ? 'Save' : 'Create user',
    fields: [{ name: 'full_name', label: 'Full name', value: u?.full_name || '', required: true }, { name: 'email', label: 'Email (login)', type: 'email', value: u?.email || '', required: true }, { name: 'phone', label: 'Phone', value: u?.phone || '' },
      ...(u ? [] : [{ name: 'role', label: 'Role', type: 'select', options: ['worker', 'supervisor', 'finance', 'admin'].map((r) => ({ value: r, label: App.ucfirst(r) })) },
        { name: 'password', label: 'Temporary password', type: 'password', required: true, help: 'At least 8 characters, with uppercase, lowercase and a number.' }])],
    onSubmit: async (v) => { if (u) await App.put(`/users/${u.id}`, v); else await App.post('/users', v); App.toast('Saved.'); },
  }).then((ok) => ok && after());
}

App.views['admin.users'] = async (box) => {
  const hash = new URLSearchParams(location.hash.split('?')[1] || '');
  const f = { role: hash.get('role') || '', status: hash.get('status') || '', q: hash.get('q') || '' };
  const rows = await App.get('/users' + App.qs(f));
  const sel = (arr, cur, blank) => `<option value="">${blank}</option>` + arr.map((x) => `<option value="${x}" ${x === cur ? 'selected' : ''}>${App.ucfirst(x)}</option>`).join('');
  box.innerHTML = App.title('Users', '<button class="btn btn-primary" style="background:#1f3a5f;border-color:#1f3a5f" data-act="new">Create user</button>') + `<form class="row g-2 mb-3" id="uf">
    <div class="col-md-4"><input class="form-control" name="q" placeholder="Search name or email" value="${App.esc(f.q)}"></div>
    <div class="col-6 col-md-3"><select class="form-select" name="role">${sel(['worker', 'supervisor', 'finance', 'admin'], f.role, 'All roles')}</select></div>
    <div class="col-6 col-md-3"><select class="form-select" name="status">${sel(['pending', 'active', 'inactive'], f.status, 'All statuses')}</select></div>
    <div class="col-md-2"><button class="btn btn-outline-primary w-100">Filter</button></div></form>`
    + App.card(`${rows.length} user(s)`, App.table([{ label: 'Name', render: (u) => `${App.esc(u.full_name)}<div class="small text-muted">${App.esc(u.worker_code || '')}</div>` }, { label: 'Email', key: 'email' }, { label: 'Phone', key: 'phone' },
      { label: 'Role', render: (u) => App.ucfirst(u.role) }, { label: 'Status', render: (u) => App.badge(u.status) },
      { label: '', render: (u) => `<div class="btn-group btn-group-sm">
        ${u.status !== 'active' ? `<button class="btn btn-success" data-act="status" data-id="${u.id}" data-s="active">Activate</button>` : `<button class="btn btn-outline-warning" data-act="status" data-id="${u.id}" data-s="inactive">Deactivate</button>`}
        <button class="btn btn-outline-secondary" data-act="edit" data-id="${u.id}">Edit</button><button class="btn btn-outline-secondary" data-act="role" data-id="${u.id}">Role</button><button class="btn btn-outline-secondary" data-act="pw" data-id="${u.id}">Password</button></div>` }], rows, 'No users match.'));
  box.querySelector('#uf').addEventListener('submit', (e) => { e.preventDefault(); location.hash = '#/users' + App.qs(App.formValues(e.target)); });
  const find = (id) => rows.find((u) => String(u.id) === id);
  App.on(box, {
    new: () => userModal(null, App.refresh), edit: (d) => userModal(find(d.id), App.refresh),
    status: async (d) => { await App.patch(`/users/${d.id}/status`, { status: d.s }); App.toast(d.s === 'active' ? 'Account activated.' : 'Account deactivated.'); App.refresh(); },
    role: (d) => App.modal({ title: `Change role: ${find(d.id).full_name}`, html: '<p class="small text-muted">Role changes are recorded in the audit log.</p>', fields: [{ name: 'role', label: 'New role', type: 'select', value: find(d.id).role, options: ['worker', 'supervisor', 'finance', 'admin'].map((r) => ({ value: r, label: App.ucfirst(r) })) }],
      onSubmit: async (v) => { await App.put(`/users/${d.id}/role`, v); App.toast('Role changed.'); } }).then((ok) => ok && App.refresh()),
    pw: (d) => App.modal({ title: `Reset password: ${find(d.id).full_name}`, fields: [{ name: 'password', label: 'New password', type: 'password', required: true }], onSubmit: async (v) => { await App.post(`/users/${d.id}/reset-password`, v); App.toast('Password reset.'); } }),
  });
};

App.views['admin.rules'] = async (box) => {
  const rows = await App.get('/rules');
  box.innerHTML = App.title('Wage & system rules') + '<div class="alert alert-info py-2">These rules are used by the wage engine and the automation. Changing a rule affects future calculations only. Every change is recorded in the audit log.</div>'
    + App.card('Rules', App.table([{ label: 'Rule', render: (r) => `<code>${App.esc(r.key)}</code>` }, { label: 'What it does', key: 'description' }, { label: 'Value', render: (r) => `<strong>${App.esc(r.value) || '<span class="text-muted">(blank)</span>'}</strong>` }, { label: 'Last changed', render: (r) => App.dt(r.updated_at) },
      { label: '', render: (r) => `<button class="btn btn-sm btn-outline-primary" data-act="edit" data-k="${r.key}">Change</button>` }], rows));
  App.on(box, { edit: (d) => { const r = rows.find((x) => x.key === d.k); return App.modal({ title: r.key, html: `<p class="small text-muted">${App.esc(r.description)}</p>`,
    fields: [r.type === 'boolean' ? { name: 'value', label: 'Value', type: 'select', value: r.value, options: [{ value: 'true', label: 'true' }, { value: 'false', label: 'false' }] } : { name: 'value', label: 'Value', value: r.value, type: r.type === 'number' ? 'number' : 'text', step: 'any' }],
    onSubmit: async (v) => { await App.put(`/rules/${r.key}`, v); App.toast('Rule updated.'); } }).then((ok) => ok && App.refresh()); } });
};

App.views['admin.audit'] = async (box) => {
  const hash = new URLSearchParams(location.hash.split('?')[1] || '');
  const f = { action: hash.get('action') || '', from: hash.get('from') || '', to: hash.get('to') || '' };
  const [rows, actions] = await Promise.all([App.get('/audit' + App.qs(f)), App.get('/audit/actions')]);
  const short = (s) => (s ? App.esc(s.length > 70 ? s.slice(0, 70) + '...' : s) : '');
  box.innerHTML = App.title('Audit log') + `<div class="alert alert-secondary py-2">The audit log is read-only. Nobody, including administrators, can edit or delete these records.</div>
    <form class="row g-2 mb-3" id="auf"><div class="col-md-4"><select class="form-select" name="action"><option value="">All actions</option>${actions.map((a) => `<option ${a === f.action ? 'selected' : ''}>${App.esc(a)}</option>`).join('')}</select></div>
    <div class="col-6 col-md-3"><input class="form-control" type="date" name="from" value="${f.from}"></div><div class="col-6 col-md-3"><input class="form-control" type="date" name="to" value="${f.to}"></div><div class="col-md-2"><button class="btn btn-outline-primary w-100">Filter</button></div></form>`
    + App.card(`${rows.length} record(s) (latest 300)`, App.table([{ label: 'When', render: (a) => App.dt(a.created_at) }, { label: 'User', render: (a) => App.esc(a.user_name || (a.user_id ? '#' + a.user_id : 'System')) }, { label: 'Action', render: (a) => `<code>${App.esc(a.action)}</code>` },
      { label: 'Entity', render: (a) => App.esc(a.entity ? `${a.entity} ${a.entity_id || ''}` : '') }, { label: 'Before', render: (a) => `<span class="small">${short(a.previous_value)}</span>` }, { label: 'After', render: (a) => `<span class="small">${short(a.new_value)}</span>` }, { label: 'IP', key: 'ip_address' },
      { label: '', render: (a) => `<button class="btn btn-sm btn-link" data-act="view" data-id="${a.id}">Details</button>` }], rows, 'No audit records for this filter.'));
  box.querySelector('#auf').addEventListener('submit', (e) => { e.preventDefault(); location.hash = '#/audit' + App.qs(App.formValues(e.target)); });
  App.on(box, { view: (d) => { const a = rows.find((x) => String(x.id) === d.id); const pretty = (s) => { try { return JSON.stringify(JSON.parse(s), null, 2); } catch { return s || '-'; } };
    App.modal({ title: `Audit record #${a.id}`, noFooter: true, size: 'modal-lg', html: `<dl class="row mb-0"><dt class="col-sm-3">When</dt><dd class="col-sm-9">${App.dt(a.created_at)}</dd><dt class="col-sm-3">User</dt><dd class="col-sm-9">${App.esc(a.user_name || 'System')}</dd>
      <dt class="col-sm-3">Action</dt><dd class="col-sm-9"><code>${App.esc(a.action)}</code></dd><dt class="col-sm-3">Entity</dt><dd class="col-sm-9">${App.esc(a.entity || '-')} ${App.esc(a.entity_id || '')}</dd><dt class="col-sm-3">IP address</dt><dd class="col-sm-9">${App.esc(a.ip_address || '-')}</dd>
      <dt class="col-sm-3">Before</dt><dd class="col-sm-9"><pre class="small mb-2">${App.esc(pretty(a.previous_value))}</pre></dd><dt class="col-sm-3">After</dt><dd class="col-sm-9"><pre class="small mb-0">${App.esc(pretty(a.new_value))}</pre></dd></dl>` }); } });
};

App.views['admin.security'] = async (box) => {
  const s = await App.get('/audit/suspicious');
  box.innerHTML = App.title('Security & automation', '<button class="btn btn-outline-primary" data-act="run">Run automatic checks now</button>')
    + '<div class="alert alert-info py-2">Automatic checks run every 10 minutes: shifts with no clock-in are marked absent, clock-ins with no clock-out are flagged, and finance is reminded about unpaid wages.</div>'
    + App.card('Repeated failed logins (last 24 hours)', App.table([{ label: 'Email tried', key: 'email' }, { label: 'Attempts', key: 'attempts' }, { label: 'Last attempt', render: (x) => App.dt(x.last_attempt) }, { label: 'IP', key: 'ip_address' }], s.failed_logins, 'None. Accounts lock for 15 minutes after 5 failed attempts.'))
    + App.card('Clock-ins outside the worksite area', App.table([{ label: 'Date', key: 'work_date' }, { label: 'Worker', key: 'worker_name' }, { label: 'Clock-in', render: (x) => App.dt(x.clock_in) }, { label: 'Captured by', key: 'capture_method' }], s.outside_worksite, 'None (the location check is optional and set under Wage & system rules).'))
    + App.card('Workers with repeated rejected attendance', App.table([{ label: 'Worker', key: 'worker_name' }, { label: 'Rejected records', key: 'rejected_count' }], s.repeated_rejections, 'None.'));
  App.on(box, { run: async () => { const r = await App.post('/admin/run-automation'); App.toast(`Done. Marked absent: ${r.marked_absent}. Missed clock-outs flagged: ${r.flagged_missed_clockout}. Reminders: ${r.payment_reminders}.`); } });
};
App.views['admin.reports'] = App.views['common.reports'];
