// Finance / payroll screens
App.nav.finance = [
  { id: 'dashboard', label: 'Dashboard' }, { id: 'wages', label: 'Approved wages' }, { id: 'payroll', label: 'Payroll' }, { id: 'payments', label: 'Payments' },
  { id: 'payslips', label: 'Payslips' }, { id: 'reports', label: 'Reports' }, { id: 'notifications', label: 'Notifications' },
];

App.views['finance.dashboard'] = async (box) => {
  const d = await App.get('/dashboard');
  box.innerHTML = App.title('Finance dashboard') + `<div class="row g-3 mb-3">
    ${App.stat('Current payroll', d.current_period ? App.esc(d.current_period.name) : 'None', d.current_period ? App.badge(d.current_period.status) : 'Create one from Payroll')}
    ${App.stat('Pending (not in payroll)', App.money(d.pending_payroll.v), d.pending_payroll.n + ' approved shift(s)')}
    ${App.stat('Approved payroll', App.money(d.approved_payroll.v), d.approved_payroll.n + ' payroll(s)')}
    ${App.stat('Total wages', App.money(d.total_wages))}${App.stat('Paid wages', App.money(d.paid_wages))}${App.stat('Unpaid wages', App.money(d.unpaid_wages))}</div>`
    + App.card('Recent payments', App.table([{ label: 'Date', key: 'payment_date' }, { label: 'Worker', key: 'worker_name' }, { label: 'Amount', render: (p) => App.money(p.amount) }, { label: 'Reference', key: 'reference' }], d.recent_payments, 'No payments yet.'));
};

App.views['finance.wages'] = async (box) => {
  const rows = await App.get('/wages' + App.qs({ from: App.addDays(App.today(), -60) }));
  const open = rows.filter((r) => !r.payroll_item_id);
  box.innerHTML = App.title('Approved wages') + `<div class="row g-3 mb-3">${App.stat('Not yet in a payroll', App.money(open.reduce((s, r) => s + r.total_pay, 0)), open.length + ' shift(s)')}${App.stat('All shown', App.money(rows.reduce((s, r) => s + r.total_pay, 0)), rows.length + ' shift(s), last 60 days')}</div>`
    + App.card('Wage calculations (every figure traces back to an approved attendance record)', App.table([
      { label: 'Date', key: 'work_date' }, { label: 'Worker', render: (w) => `${App.esc(w.worker_name)} <span class="text-muted small">${App.esc(w.worker_code || '')}</span>` }, { label: 'Job', key: 'job_title' },
      { label: 'Hours', key: 'total_hours' }, { label: 'OT h', key: 'overtime_hours' }, { label: 'Rate', render: (w) => App.rateLabel(w.rate_type, w.rate) }, { label: 'Total', render: (w) => `<strong>${App.num(w.total_pay)}</strong>` },
      { label: 'Payroll', render: (w) => (w.payroll_name ? `${App.esc(w.payroll_name)} ${App.badge(w.payment_status)}` : '<span class="text-muted">not yet</span>') },
      { label: '', render: (w) => `<button class="btn btn-sm btn-outline-primary" data-act="how" data-id="${w.id}">Details</button>` }], rows, 'No approved wages yet.'));
  App.on(box, { how: (d) => App.modal({ title: `${rows.find((r) => String(r.id) === d.id).worker_name}: wage details`, html: App.wageExplain(rows.find((r) => String(r.id) === d.id)), noFooter: true }) });
};

function periodCols(canPay) {
  return [
    { label: 'Worker', render: (i) => `${App.esc(i.worker_name)} <span class="text-muted small">${App.esc(i.worker_code || '')}</span>` }, { label: 'Days', key: 'days_worked' }, { label: 'Hours', key: 'total_hours' },
    { label: 'Normal pay', render: (i) => App.num(i.normal_pay) }, { label: 'Overtime', render: (i) => App.num(i.overtime_pay) }, { label: 'Total (UGX)', render: (i) => `<strong>${App.num(i.total_pay)}</strong>` },
    { label: 'Status', render: (i) => App.badge(i.status) + (i.reference ? `<div class="small text-muted">${App.esc(i.reference)}</div>` : '') },
    { label: '', render: (i) => (i.status === 'Unpaid' && canPay ? `<button class="btn btn-sm btn-success" data-act="pay" data-id="${i.id}">Record payment</button>` : i.payslip_id ? `<button class="btn btn-sm btn-outline-primary" data-act="pdf" data-id="${i.payslip_id}" data-no="${App.esc(i.payslip_no)}">Payslip</button>` : '') },
  ];
}

async function payModal(item, after) {
  return App.modal({
    title: `Record payment: ${item.worker_name}`, submit: 'Record payment',
    html: `<p>Amount due: <strong>${App.money(item.total_pay)}</strong></p>`,
    fields: [{ name: 'method', label: 'Payment method', type: 'select', options: [{ value: 'cash', label: 'Cash' }, { value: 'mobile_money', label: 'Mobile money' }, { value: 'bank_transfer', label: 'Bank transfer' }] },
      { name: 'reference', label: 'Payment reference', required: true, placeholder: 'e.g. receipt or transaction number' }, { name: 'payment_date', label: 'Payment date', type: 'date', value: App.today(), required: true }],
    onSubmit: async (v) => { await App.post('/payments', { payroll_item_id: item.id, ...v }); App.toast('Payment recorded. Payslip generated and worker notified.'); },
  }).then((ok) => ok && after());
}

App.views['finance.payroll'] = async (box) => {
  const id = new URLSearchParams(location.hash.split('?')[1] || '').get('id');
  if (id) return payrollDetail(box, id);
  const rows = await App.get('/payroll');
  box.innerHTML = App.title('Payroll', '<button class="btn btn-primary" style="background:#1f3a5f;border-color:#1f3a5f" data-act="new">Create payroll</button>')
    + App.card('Payroll periods', App.table([{ label: 'Name', key: 'name' }, { label: 'Type', render: (p) => App.ucfirst(p.period_type) }, { label: 'Dates', render: (p) => `${p.start_date} to ${p.end_date}` }, { label: 'Workers', key: 'workers' },
      { label: 'Total', render: (p) => App.money(p.total_pay) }, { label: 'Paid', render: (p) => App.money(p.paid_pay) }, { label: 'Status', render: (p) => App.badge(p.status) },
      { label: '', render: (p) => `<a class="btn btn-sm btn-outline-primary" href="#/payroll?id=${p.id}">Open</a>` }], rows, 'No payroll created yet.'));
  App.on(box, { new: () => {
    const t = App.today();
    return App.modal({ title: 'Create payroll', submit: 'Create payroll',
      html: '<p class="small text-muted">The system collects all approved wages in the date range that are not yet in a payroll, and groups them per worker.</p>',
      fields: [{ name: 'name', label: 'Name', value: `Payroll ${App.addDays(t, -6)} to ${t}`, required: true }, { name: 'period_type', label: 'Period type', type: 'select', value: 'weekly', options: ['daily', 'weekly', 'biweekly', 'monthly'].map((x) => ({ value: x, label: App.ucfirst(x) })) },
        { name: 'start_date', label: 'From', type: 'date', value: App.addDays(t, -6), required: true }, { name: 'end_date', label: 'To', type: 'date', value: t, required: true }],
      onSubmit: async (v) => { const p = await App.post('/payroll', v); location.hash = `#/payroll?id=${p.id}`; } }); } });
};

async function payrollDetail(box, id) {
  const p = await App.get(`/payroll/${id}`);
  const canPay = p.status === 'Approved' && App.user.role === 'finance';
  const unpaid = p.items.filter((i) => i.status === 'Unpaid').length;
  box.innerHTML = App.title(p.name, '<a class="btn btn-outline-secondary btn-sm" href="#/payroll">Back</a>') + `<div class="row g-3 mb-3">
    ${App.stat('Status', App.badge(p.status), `${p.period_type}, ${p.start_date} to ${p.end_date}`)}${App.stat('Workers', p.totals.workers)}${App.stat('Total wages', App.money(p.totals.total))}${App.stat('Paid', App.money(p.totals.paid), 'unpaid ' + App.money(p.totals.unpaid))}</div>
    <div class="d-flex flex-wrap gap-2 mb-3">
      ${p.status === 'Draft' ? '<button class="btn btn-primary" style="background:#1f3a5f;border-color:#1f3a5f" data-act="approve">Approve payroll</button><button class="btn btn-outline-danger" data-act="delete">Delete draft</button>' : ''}
      ${canPay && unpaid ? `<button class="btn btn-success" data-act="payall">Pay all (${unpaid})</button>` : ''}
      <button class="btn btn-outline-secondary" data-act="csv">Download CSV</button></div>
    ${p.status === 'Draft' ? '<div class="alert alert-info py-2">Review the totals below. Payments can be recorded only after the payroll is approved.</div>' : ''}`
    + App.card('Payroll items', App.table(periodCols(canPay), p.items));
  App.on(box, {
    approve: async () => { if (!confirm('Approve this payroll? You will not be able to delete it afterwards.')) return; await App.post(`/payroll/${id}/approve`); App.toast('Payroll approved.'); App.refresh(); },
    delete: async () => { if (!confirm('Delete this draft payroll? The wages return to the pending list.')) return; await App.del(`/payroll/${id}`); App.toast('Draft deleted.'); location.hash = '#/payroll'; },
    csv: () => App.download(`/reports/payroll/${id}?format=csv`, 'payroll-report.csv'),
    pay: (d) => payModal(p.items.find((i) => String(i.id) === d.id), App.refresh),
    pdf: (d) => App.download(`/payslips/${d.id}/download`, `${d.no}.pdf`),
    payall: () => App.modal({ title: 'Pay all workers', submit: 'Record all payments', html: `<p>This records a payment for ${unpaid} worker(s) and generates their payslips.</p>`,
      fields: [{ name: 'method', label: 'Payment method', type: 'select', options: [{ value: 'cash', label: 'Cash' }, { value: 'mobile_money', label: 'Mobile money' }, { value: 'bank_transfer', label: 'Bank transfer' }] },
        { name: 'reference_prefix', label: 'Reference prefix', required: true, value: `PAY-${p.id}`, help: 'Each payment gets this prefix plus a number.' }, { name: 'payment_date', label: 'Payment date', type: 'date', value: App.today(), required: true }],
      onSubmit: async (v) => { const r = await App.post('/payments/bulk', { period_id: Number(id), ...v }); App.toast(`${r.paid} payment(s) recorded.`); } }).then((ok) => ok && App.refresh()),
  });
}

App.views['finance.payments'] = async (box) => {
  const rows = await App.get('/payments');
  box.innerHTML = App.title('Payments') + App.card(`${rows.length} payment(s)`, App.table([{ label: 'Date', key: 'payment_date' }, { label: 'Worker', render: (p) => `${App.esc(p.worker_name)} <span class="text-muted small">${App.esc(p.worker_code || '')}</span>` },
    { label: 'Payroll', key: 'period_name' }, { label: 'Amount', render: (p) => App.money(p.amount) }, { label: 'Method', render: (p) => App.ucfirst(p.method) }, { label: 'Reference', key: 'reference' }, { label: 'Recorded by', key: 'recorded_by_name' },
    { label: '', render: (p) => (p.payslip_id ? `<button class="btn btn-sm btn-outline-primary" data-act="pdf" data-id="${p.payslip_id}" data-no="${App.esc(p.payslip_no)}">Payslip</button>` : '') }], rows, 'No payments recorded yet.'));
  App.on(box, { pdf: (d) => App.download(`/payslips/${d.id}/download`, `${d.no}.pdf`) });
};

const payslipsView = async (box) => {
  const rows = await App.get('/payslips');
  box.innerHTML = App.title('Payslips') + App.card(`${rows.length} payslip(s)`, App.table([{ label: 'Payslip', key: 'payslip_no' }, { label: 'Worker', render: (s) => `${App.esc(s.worker_name)} <span class="text-muted small">${App.esc(s.worker_code || '')}</span>` },
    { label: 'Period', render: (s) => `${App.esc(s.period_name)}` }, { label: 'Total', render: (s) => App.money(s.total_pay) }, { label: 'Generated', render: (s) => App.dt(s.generated_at) },
    { label: '', render: (s) => `<button class="btn btn-sm btn-primary" style="background:#1f3a5f;border-color:#1f3a5f" data-act="pdf" data-id="${s.id}" data-no="${App.esc(s.payslip_no)}">Download PDF</button>` }], rows, 'No payslips yet. They are created when payments are recorded.'));
  App.on(box, { pdf: (d) => App.download(`/payslips/${d.id}/download`, `${d.no}.pdf`) });
};
App.views['finance.payslips'] = payslipsView;
App.views['finance.reports'] = App.views['common.reports'];
App.views['finance.payroll.detail'] = null;
