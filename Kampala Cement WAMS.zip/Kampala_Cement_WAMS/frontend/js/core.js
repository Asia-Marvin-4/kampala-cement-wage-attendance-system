// Core helpers shared by every screen: API calls, formatting, tables, forms, modals.
window.App = { views: {}, nav: {}, user: null };

App.esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
App.money = (n) => 'UGX ' + Number(n || 0).toLocaleString('en-US');
App.num = (n) => Number(n || 0).toLocaleString('en-US');
App.dt = (s) => (s ? String(s).slice(0, 16).replace('T', ' ') : '-');
App.t5 = (s) => (s ? String(s).slice(0, 5) : '-');
const kampala = new Intl.DateTimeFormat('en-CA', { timeZone: 'Africa/Kampala', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' });
App.nowParts = () => { const o = {}; kampala.formatToParts(new Date()).forEach((p) => { o[p.type] = p.value; }); return o; };
App.today = () => { const p = App.nowParts(); return `${p.year}-${p.month}-${p.day}`; };
App.addDays = (d, n) => { const t = new Date(d + 'T00:00:00Z'); t.setUTCDate(t.getUTCDate() + n); return t.toISOString().slice(0, 10); };

const GOOD = ['Approved', 'active', 'Paid', 'Completed', 'Closed', 'approved', 'sent'];
const WARN = ['Pending Approval', 'pending', 'Draft', 'In Progress', 'Unpaid'];
const BAD = ['Rejected', 'inactive', 'Absent', 'Missed Clock-out', 'rejected', 'cancelled'];
App.badge = (t) => {
  const cls = GOOD.includes(t) ? 'success' : WARN.includes(t) ? 'warning text-dark' : BAD.includes(t) ? 'danger' : t === 'Correction Requested' ? 'info text-dark' : 'secondary';
  return `<span class="badge bg-${cls}">${App.esc(t)}</span>`;
};

App.token = () => localStorage.getItem('wams_token');
App.logoutLocal = () => { localStorage.removeItem('wams_token'); localStorage.removeItem('wams_user'); location.replace('/index.html'); };

App.api = async (method, path, body) => {
  const res = await fetch('/api' + path, { method, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + App.token() }, body: body ? JSON.stringify(body) : undefined });
  if (res.status === 401) { App.logoutLocal(); throw new Error('Please log in again.'); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed.');
  return data;
};
App.get = (p) => App.api('GET', p);
App.post = (p, b) => App.api('POST', p, b || {});
App.put = (p, b) => App.api('PUT', p, b || {});
App.patch = (p, b) => App.api('PATCH', p, b || {});
App.del = (p) => App.api('DELETE', p);
App.qs = (o) => { const p = new URLSearchParams(); Object.entries(o).forEach(([k, v]) => { if (v !== '' && v != null) p.set(k, v); }); const s = p.toString(); return s ? '?' + s : ''; };

App.download = async (path, filename) => {
  const res = await fetch('/api' + path, { headers: { Authorization: 'Bearer ' + App.token() } });
  if (!res.ok) { const d = await res.json().catch(() => ({})); throw new Error(d.error || 'Download failed.'); }
  const url = URL.createObjectURL(await res.blob());
  const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
};

App.toast = (msg, type = 'success') => {
  const box = document.getElementById('toasts');
  const el = document.createElement('div');
  el.className = `toast align-items-center text-bg-${type} border-0`;
  el.innerHTML = `<div class="d-flex"><div class="toast-body">${App.esc(msg)}</div><button class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" type="button"></button></div>`;
  box.appendChild(el);
  const t = new bootstrap.Toast(el, { delay: 4500 }); t.show();
  el.addEventListener('hidden.bs.toast', () => el.remove());
};
App.fail = (e) => App.toast(e.message || String(e), 'danger');

App.stat = (label, value, sub) => `<div class="col-6 col-md-4 col-xl-3"><div class="card stat-card h-100"><div class="card-body"><div class="stat-label">${App.esc(label)}</div><div class="stat-value">${value}</div>${sub ? `<div class="small text-muted">${sub}</div>` : ''}</div></div></div>`;

// table(columns, rows): column = { label, key | render(row), cls }
App.table = (cols, rows, empty = 'Nothing to show yet.') => {
  if (!rows || !rows.length) return `<div class="text-muted p-3">${App.esc(empty)}</div>`;
  return `<div class="table-responsive"><table class="table table-hover table-sm align-middle mb-0"><thead><tr>${cols.map((c) => `<th>${App.esc(c.label)}</th>`).join('')}</tr></thead><tbody>${
    rows.map((r) => `<tr>${cols.map((c) => `<td class="${c.cls || ''}">${c.render ? c.render(r) : App.esc(r[c.key])}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
};
App.card = (title, body, actions = '') => `<div class="card mb-3"><div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2"><span>${title}</span><span>${actions}</span></div><div class="card-body p-0">${body}</div></div>`;
App.title = (t, actions = '') => `<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3"><h4 class="page-title mb-0">${App.esc(t)}</h4><div>${actions}</div></div>`;

// ---------- Forms and modals ----------
function fieldHtml(f) {
  const v = f.value ?? '', req = f.required ? 'required' : '', id = 'f_' + f.name;
  let input;
  if (f.type === 'select') input = `<select class="form-select" id="${id}" name="${f.name}" ${req}>${(f.options || []).map((o) => `<option value="${App.esc(o.value)}" ${String(o.value) === String(v) ? 'selected' : ''}>${App.esc(o.label)}</option>`).join('')}</select>`;
  else if (f.type === 'textarea') input = `<textarea class="form-control" id="${id}" name="${f.name}" rows="3" ${req} placeholder="${App.esc(f.placeholder || '')}">${App.esc(v)}</textarea>`;
  else if (f.type === 'checkbox') return `<div class="form-check mb-3"><input class="form-check-input" type="checkbox" id="${id}" name="${f.name}" ${v ? 'checked' : ''}><label class="form-check-label" for="${id}">${App.esc(f.label)}</label></div>`;
  else input = `<input class="form-control" id="${id}" name="${f.name}" type="${f.type || 'text'}" value="${App.esc(v)}" ${req} placeholder="${App.esc(f.placeholder || '')}" ${f.step ? `step="${f.step}"` : ''} ${f.min != null ? `min="${f.min}"` : ''}>`;
  return `<div class="mb-3"><label class="form-label" for="${id}">${App.esc(f.label)}${f.required ? ' <span class="text-danger">*</span>' : ''}</label>${input}${f.help ? `<div class="form-text">${App.esc(f.help)}</div>` : ''}</div>`;
}
App.fieldsHtml = (fields) => fields.map(fieldHtml).join('');
App.formValues = (form) => {
  const o = {};
  [...form.elements].forEach((el) => { if (!el.name) return; o[el.name] = el.type === 'checkbox' ? el.checked : el.value.trim(); });
  return o;
};

// modal({ title, fields | html, submit, size, onSubmit(values) }) shows a dialog; errors appear inside it
App.modal = ({ title, fields = [], html = '', submit = 'Save', size = '', onSubmit, noFooter }) => new Promise((resolve) => {
  const wrap = document.createElement('div');
  wrap.className = 'modal fade'; wrap.tabIndex = -1;
  wrap.innerHTML = `<div class="modal-dialog ${size}"><form class="modal-content" novalidate>
    <div class="modal-header"><h5 class="modal-title">${App.esc(title)}</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body"><div class="alert alert-danger py-2 d-none" data-err></div>${html}${App.fieldsHtml(fields)}</div>
    ${noFooter ? '' : `<div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary" style="background:#1f3a5f;border-color:#1f3a5f">${App.esc(submit)}</button></div>`}
  </form></div>`;
  document.body.appendChild(wrap);
  const m = new bootstrap.Modal(wrap);
  const form = wrap.querySelector('form'), err = wrap.querySelector('[data-err]');
  let done = false;
  form.addEventListener('submit', async (e) => {
    e.preventDefault(); err.classList.add('d-none');
    const btn = form.querySelector('[type=submit]'); if (btn) btn.disabled = true;
    try { await onSubmit(App.formValues(form), wrap); done = true; m.hide(); }
    catch (ex) { err.textContent = ex.message; err.classList.remove('d-none'); }
    finally { if (btn) btn.disabled = false; }
  });
  wrap.addEventListener('hidden.bs.modal', () => { wrap.remove(); resolve(done); });
  m.show();
  setTimeout(() => wrap.querySelector('input,select,textarea')?.focus(), 300);
});
App.ask = (title, label, submit = 'Send') => new Promise((resolve) => {
  let value = null;
  App.modal({ title, submit, fields: [{ name: 'note', label, type: 'textarea', required: true }], onSubmit: async (v) => { if (v.note.length < 3) throw new Error('Please write at least 3 characters.'); value = v.note; } }).then(() => resolve(value));
});

App.ucfirst = (s) => String(s || '').replace(/_/g, ' ').replace(/^./, (c) => c.toUpperCase());
App.rateLabel = (type, rate) => `${App.money(rate)} / ${type === 'hourly' ? 'hour' : 'day'}`;

// Wire click handlers by data-act inside a container
App.on = (container, handlers) => {
  container.onclick = async (e) => {
    const el = e.target.closest('[data-act]');
    if (!el || !container.contains(el)) return;
    const fn = handlers[el.dataset.act];
    if (!fn) return;
    try { await fn(el.dataset, el); } catch (ex) { App.fail(ex); }
  };
};
App.spinner = () => '<div class="text-center p-5"><div class="spinner-border text-secondary"></div></div>';
