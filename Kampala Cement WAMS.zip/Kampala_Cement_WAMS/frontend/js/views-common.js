// Screens shared by several roles: profile, notifications, reports.
App.views['common.profile'] = async (box) => {
  const p = await App.get('/profile');
  const worker = p.role === 'worker';
  box.innerHTML = App.title('My profile') + `<div class="card"><div class="card-body"><form id="pf" novalidate>
    <div class="row"><div class="col-md-6">${App.fieldsHtml([
      { name: 'full_name', label: 'Full name', value: p.full_name, required: true },
      { name: 'phone', label: 'Phone', value: p.phone || '', placeholder: '07XXXXXXXX' }])}
      <div class="mb-3"><label class="form-label">Email (login)</label><input class="form-control" value="${App.esc(p.email)}" disabled></div></div>
    <div class="col-md-6">${worker ? App.fieldsHtml([
      { name: 'skills', label: 'Skills', value: p.skills || '', placeholder: 'e.g. loading, forklift assistant' },
      { name: 'address', label: 'Address', value: p.address || '' },
      { name: 'emergency_contact', label: 'Emergency contact', value: p.emergency_contact || '' }])
      + `<div class="mb-3"><label class="form-label">Worker ID</label><input class="form-control" value="${App.esc(p.worker_code)}" disabled></div>`
      : App.fieldsHtml([{ name: 'section', label: 'Section / department', value: p.section || '' }, { name: 'position_title', label: 'Position', value: p.position_title || '' }])}</div></div>
    <button class="btn btn-primary" style="background:#1f3a5f;border-color:#1f3a5f">Save profile</button></form></div></div>`;
  box.querySelector('#pf').addEventListener('submit', async (e) => {
    e.preventDefault();
    try { await App.put('/profile', App.formValues(e.target)); App.toast('Profile saved.'); } catch (x) { App.fail(x); }
  });
};

App.views['common.notifications'] = async (box) => {
  const d = await App.get('/notifications');
  box.innerHTML = App.title('Notifications', '<button class="btn btn-outline-secondary btn-sm" data-act="all">Mark all as read</button>')
    + App.card('Latest', App.table([
      { label: 'When', render: (n) => App.dt(n.created_at) },
      { label: 'Message', render: (n) => `${n.is_read ? '' : '<span class="badge bg-primary me-1">new</span>'}${App.esc(n.message)}` }], d.items, 'No notifications yet.'));
  App.on(box, { all: async () => { await App.put('/notifications/read-all'); App.refresh(); } });
};

// Reports (supervisor: own jobs; finance and admin: everything)
App.views['common.reports'] = async (box) => {
  const today = App.today();
  box.innerHTML = App.title('Reports') + `<div class="card mb-3"><div class="card-body"><form class="row g-2 align-items-end" id="rf">
    <div class="col-md-3"><label class="form-label">Report</label><select class="form-select" name="type">
      <option value="attendance">Attendance report</option><option value="wages">Wage report</option><option value="overtime">Overtime report</option></select></div>
    <div class="col-md-3"><label class="form-label">From</label><input class="form-control" type="date" name="from" value="${App.addDays(today, -30)}"></div>
    <div class="col-md-3"><label class="form-label">To</label><input class="form-control" type="date" name="to" value="${today}"></div>
    <div class="col-md-3 d-flex gap-2"><button class="btn btn-primary" style="background:#1f3a5f;border-color:#1f3a5f">Show</button><button class="btn btn-outline-secondary" type="button" data-act="csv">Download CSV</button></div>
  </form></div></div><div id="rout"></div>`;
  const form = box.querySelector('#rf'), out = box.querySelector('#rout');
  const q = () => { const v = App.formValues(form); return { path: `/reports/${v.type}`, qs: App.qs({ from: v.from, to: v.to }) }; };
  const COLS = {
    attendance: [['work_date', 'Date'], ['worker_name', 'Worker'], ['job_title', 'Job'], ['clock_in', 'In'], ['clock_out', 'Out'], ['total_hours', 'Hours'], ['attendance_status', 'Status'], ['late', 'Late'], ['approval_status', 'Approval']],
    wages: [['work_date', 'Date'], ['worker_name', 'Worker'], ['job_title', 'Job'], ['total_hours', 'Hours'], ['overtime_hours', 'OT hours'], ['basic_pay', 'Basic'], ['overtime_pay', 'Overtime'], ['total_pay', 'Total (UGX)'], ['payment_status', 'Payment']],
    overtime: [['worker_name', 'Worker'], ['worker_code', 'ID'], ['shifts_with_overtime', 'Shifts'], ['overtime_hours', 'OT hours'], ['overtime_pay', 'OT pay (UGX)']],
  };
  async function run() {
    const { path, qs } = q(); const type = App.formValues(form).type;
    const rows = await App.get(path + qs);
    let extra = '';
    if (type === 'wages') extra = `<div class="p-3 border-top fw-bold">Total wages in this report: ${App.money(rows.reduce((s, r) => s + r.total_pay, 0))}</div>`;
    out.innerHTML = App.card(`${rows.length} record(s)`, App.table(COLS[type].map(([k, l]) => ({ label: l, key: k })), rows, 'No records for these dates.') + extra);
  }
  form.addEventListener('submit', async (e) => { e.preventDefault(); try { await run(); } catch (x) { App.fail(x); } });
  App.on(box, { csv: async () => { const { path, qs } = q(); const sep = qs ? '&' : '?'; await App.download(`${path}${qs}${sep}format=csv`, `${path.split('/').pop()}-report.csv`); } });
  await run();
};
