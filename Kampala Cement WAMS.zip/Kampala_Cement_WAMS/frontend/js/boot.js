// Starts the application: checks login, builds the menu for the user's role, and shows the right screen.
(async function () {
  if (!App.token()) return location.replace('/index.html');
  const $ = (id) => document.getElementById(id);
  try { App.user = await App.get('/auth/me'); } catch { return; }
  $('userName').textContent = App.user.full_name;
  $('userRole').textContent = App.ucfirst(App.user.role);
  if (['admin', 'finance', 'supervisor'].includes(App.user.role)) {
    try { const r = await App.get('/rules'); $('brandCompany').textContent = (r.find((x) => x.key === 'company_name') || {}).value || ''; } catch { /* optional */ }
  }

  const items = App.nav[App.user.role] || [];
  $('sideNav').innerHTML = items.map((i) => `<a class="nav-link" href="#/${i.id}" data-route="${i.id}">${App.esc(i.label)}</a>`).join('');

  async function route() {
    const id = (location.hash.replace(/^#\//, '') || 'dashboard').split('?')[0];
    const view = App.views[`${App.user.role}.${id}`] || App.views[`common.${id}`];
    document.querySelectorAll('#sideNav .nav-link').forEach((a) => a.classList.toggle('active', a.dataset.route === id));
    if (App._timer) { clearInterval(App._timer); App._timer = null; }
    if (App._stream) { App._stream.getTracks().forEach((t) => t.stop()); App._stream = null; }
    const box = $('view');
    if (!view) { box.innerHTML = '<div class="alert alert-warning">That page is not available for your role.</div>'; return; }
    box.innerHTML = App.spinner();
    try { await view(box); } catch (e) { box.innerHTML = `<div class="alert alert-danger">${App.esc(e.message)}</div>`; }
    window.scrollTo(0, 0);
  }
  window.addEventListener('hashchange', route);
  App.refresh = route;

  // Notifications bell
  async function loadBell() {
    try {
      const d = await App.get('/notifications');
      const c = $('bellCount'); c.textContent = d.unread; c.classList.toggle('d-none', !d.unread);
      $('bellList').innerHTML = d.items.length ? d.items.map((n) => `<div class="px-3 py-2 border-bottom notif-item ${n.is_read ? '' : 'unread'}"><div class="small">${App.esc(n.message)}</div><div class="text-muted" style="font-size:.7rem">${App.dt(n.created_at)}</div></div>`).join('') : '<div class="p-3 text-muted small">No notifications yet.</div>';
    } catch { /* ignore */ }
  }
  $('readAll').addEventListener('click', async () => { await App.put('/notifications/read-all'); loadBell(); });
  $('bellBtn').addEventListener('click', () => setTimeout(loadBell, 0));
  setInterval(loadBell, 60000);

  $('logoutBtn').addEventListener('click', async () => { try { await App.post('/auth/logout'); } catch { /* ignore */ } App.logoutLocal(); });
  $('changePw').addEventListener('click', () => App.modal({
    title: 'Change password', submit: 'Change password',
    fields: [{ name: 'current_password', label: 'Current password', type: 'password', required: true }, { name: 'new_password', label: 'New password', type: 'password', required: true, help: 'At least 8 characters, with uppercase, lowercase and a number.' }],
    onSubmit: async (v) => { await App.post('/auth/change-password', v); App.toast('Password changed.'); },
  }));

  loadBell();
  if (!location.hash) history.replaceState(null, '', '#/dashboard');
  route();
})();
