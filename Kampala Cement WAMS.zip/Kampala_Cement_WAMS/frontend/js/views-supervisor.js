// Supervisor screens (some are reused by the administrator)
App.nav.supervisor = [
  { id: 'dashboard', label: 'Dashboard' }, { id: 'workers', label: 'Workers' }, { id: 'jobs', label: 'Jobs' }, { id: 'assignments', label: 'Assignments' },
  { id: 'shifts', label: 'Shifts' }, { id: 'attendance', label: 'Attendance' }, { id: 'corrections', label: 'Corrections' }, { id: 'scan', label: 'QR scan station' },
  { id: 'reports', label: 'Reports' }, { id: 'notifications', label: 'Notifications' },
];

App.views['supervisor.dashboard'] = async (box) => {
  const [d, pending] = await Promise.all([App.get('/dashboard'), App.get('/attendance' + App.qs({ approval: 'Pending Approval' }))]);
  const ready = pending.filter((a) => a.attendance_status === 'Completed');
  box.innerHTML = App.title('Supervisor dashboard') + `<div class="row g-3 mb-3">
    ${App.stat('My workers', d.workers)}${App.stat('On shift now', d.on_shift)}${App.stat('Pending approvals', d.pending_approvals)}${App.stat("Today's attendance", d.today_attendance)}
    ${App.stat('Active jobs', d.active_jobs)}${App.stat('Wages this month', App.money(d.wage_summary.month_total), 'overtime ' + App.money(d.wage_summary.month_overtime))}
    ${App.stat('Late today', d.problems.late_today)}${App.stat('Absent today', d.problems.absent_today)}
    ${App.stat('Missed clock-outs', d.problems.missed_clockout)}${App.stat('Pending corrections', d.problems.pending_corrections)}</div>`
    + App.card('Attendance waiting for your approval', App.table(attendanceCols(false), ready.slice(0, 8), 'Nothing is waiting for approval.'), ready.length ? '<a class="btn btn-sm btn-outline-primary" href="#/attendance">Open attendance</a>' : '');
  attendanceHandlers(box, pending);
};

// ---------- Workers ----------
App.views['supervisor.workers'] = async (box) => {
  const rows = await App.get('/workers');
  box.innerHTML = App.title('Workers') + App.card(`${rows.length} active worker(s)`, App.table([
    { label: 'Worker ID', key: 'worker_code' }, { label: 'Name', key: 'full_name' }, { label: 'Phone', key: 'phone' }, { label: 'Skills', key: 'skills' }, { label: 'Active jobs', key: 'active_assignments' },
    { label: '', render: (w) => `<button class="btn btn-sm btn-outline-secondary" data-act="badge" data-id="${w.id}">QR badge</button>` }], rows, 'No active workers. An administrator must activate worker accounts.'));
  App.on(box, { badge: async (d) => { const b = await App.get(`/workers/${d.id}/badge`); App.modal({ title: b.worker_name, noFooter: true, html: `<div class="text-center qr-box"><img src="${b.qr}" alt="QR"><div class="mt-2 text-muted">${App.esc(b.worker_code)}</div><div class="small mt-1">Code: <code>${App.esc(b.token)}</code></div></div>` }); } });
};

// ---------- Jobs ----------
function jobModal(job, after) {
  const j = job || { start_date: App.today(), status: 'active' };
  return App.modal({
    title: job ? 'Edit job' : 'Create job', submit: job ? 'Save changes' : 'Create job',
    fields: [{ name: 'title', label: 'Job / task title', value: j.title || '', required: true, placeholder: 'e.g. Bag loading' }, { name: 'description', label: 'Description', type: 'textarea', value: j.description || '' },
      { name: 'location', label: 'Location', value: j.location || '' }, { name: 'start_date', label: 'Start date', type: 'date', value: j.start_date, required: true }, { name: 'end_date', label: 'End date (optional)', type: 'date', value: j.end_date || '' },
      ...(job ? [{ name: 'status', label: 'Status', type: 'select', value: j.status, options: [{ value: 'active', label: 'Active' }, { value: 'completed', label: 'Completed' }, { value: 'cancelled', label: 'Cancelled' }] }] : [])],
    onSubmit: async (v) => { if (job) await App.put(`/jobs/${job.id}`, v); else await App.post('/jobs', v); App.toast('Job saved.'); },
  }).then((ok) => ok && after());
}
App.views['supervisor.jobs'] = async (box) => {
  const rows = await App.get('/jobs');
  box.innerHTML = App.title('Jobs', '<button class="btn btn-primary" style="background:#1f3a5f;border-color:#1f3a5f" data-act="new">New job</button>') + App.card('My jobs', App.table([
    { label: 'Title', key: 'title' }, { label: 'Location', key: 'location' }, { label: 'Start', key: 'start_date' }, { label: 'End', render: (j) => j.end_date || '-' }, { label: 'Workers', key: 'active_workers' }, { label: 'Status', render: (j) => App.badge(j.status) },
    { label: '', render: (j) => `<button class="btn btn-sm btn-outline-secondary" data-act="edit" data-id="${j.id}">Edit</button>` }], rows, 'No jobs yet. Create the first one.'));
  App.on(box, { new: () => jobModal(null, App.refresh), edit: (d) => jobModal(rows.find((j) => String(j.id) === d.id), App.refresh) });
};

// ---------- Assignments ----------
async function assignModal(after, pre = {}) {
  const [jobs, workers] = await Promise.all([App.get('/jobs?status=active'), App.get('/workers')]);
  if (!jobs.length) throw new Error('Create a job first.');
  return App.modal({
    title: 'Assign worker to job', submit: 'Assign',
    fields: [{ name: 'job_id', label: 'Job', type: 'select', value: pre.job_id, options: jobs.map((j) => ({ value: j.id, label: j.title })) },
      { name: 'worker_id', label: 'Worker', type: 'select', options: workers.map((w) => ({ value: w.id, label: `${w.full_name} (${w.worker_code})` })) },
      { name: 'rate_type', label: 'Pay rate type', type: 'select', options: [{ value: 'hourly', label: 'Hourly rate' }, { value: 'daily', label: 'Daily rate' }] },
      { name: 'rate', label: 'Rate (UGX)', type: 'number', required: true, min: 1, step: '1', help: 'Hourly: pay per hour. Daily: pay per full day.' }],
    onSubmit: async (v) => { await App.post('/assignments', { ...v, rate: Number(v.rate) }); App.toast('Worker assigned. They have been notified.'); },
  }).then((ok) => ok && after());
}
App.views['supervisor.assignments'] = async (box) => {
  const rows = await App.get('/assignments');
  box.innerHTML = App.title('Assignments', '<button class="btn btn-primary" style="background:#1f3a5f;border-color:#1f3a5f" data-act="new">Assign worker</button>') + App.card('Worker assignments', App.table([
    { label: 'Job', key: 'job_title' }, { label: 'Worker', render: (a) => `${App.esc(a.worker_name)} <span class="text-muted small">${App.esc(a.worker_code)}</span>` }, { label: 'Rate', render: (a) => App.rateLabel(a.rate_type, a.rate) }, { label: 'Status', render: (a) => App.badge(a.status) },
    { label: '', render: (a) => `<button class="btn btn-sm btn-outline-secondary" data-act="edit" data-id="${a.id}">Change rate / end</button>` }], rows, 'No assignments yet.'));
  App.on(box, {
    new: () => assignModal(App.refresh),
    edit: (d) => { const a = rows.find((r) => String(r.id) === d.id); return App.modal({ title: `${a.worker_name}: ${a.job_title}`, fields: [
      { name: 'rate_type', label: 'Rate type', type: 'select', value: a.rate_type, options: [{ value: 'hourly', label: 'Hourly' }, { value: 'daily', label: 'Daily' }] },
      { name: 'rate', label: 'Rate (UGX)', type: 'number', value: a.rate, required: true, min: 1 },
      { name: 'status', label: 'Status', type: 'select', value: a.status, options: [{ value: 'active', label: 'Active' }, { value: 'ended', label: 'Ended' }] }],
      html: '<p class="small text-muted">A new rate applies to future approvals. Wages already calculated keep the rate they were calculated with.</p>',
      onSubmit: async (v) => { await App.put(`/assignments/${a.id}`, { ...v, rate: Number(v.rate) }); App.toast('Assignment updated.'); } }).then((ok) => ok && App.refresh()); },
  });
};

// ---------- Shifts ----------
App.views['supervisor.shifts'] = async (box) => {
  const today = App.today();
  const [asg, shifts] = await Promise.all([App.get('/assignments?status=active'), App.get('/shifts' + App.qs({ from: App.addDays(today, -7) }))]);
  box.innerHTML = App.title('Shifts') + App.card('Create shifts', `<form class="p-3" id="sf"><div class="row g-2">
    <div class="col-md-4"><label class="form-label">Assignment</label><select class="form-select" name="assignment_id" required>${asg.map((a) => `<option value="${a.id}">${App.esc(a.worker_name)} - ${App.esc(a.job_title)}</option>`).join('')}</select></div>
    <div class="col-6 col-md-2"><label class="form-label">From date</label><input class="form-control" type="date" name="from_date" value="${today}" min="${today}" required></div>
    <div class="col-6 col-md-2"><label class="form-label">To date</label><input class="form-control" type="date" name="to_date" value="${today}" min="${today}" required></div>
    <div class="col-6 col-md-2"><label class="form-label">Start</label><input class="form-control" type="time" name="start_time" value="08:00" required></div>
    <div class="col-6 col-md-2"><label class="form-label">End</label><input class="form-control" type="time" name="end_time" value="17:00" required></div></div>
    <div class="d-flex align-items-center gap-3 mt-2"><div class="form-check"><input class="form-check-input" type="checkbox" name="skip_weekends" id="skipw" checked><label class="form-check-label" for="skipw">Skip Saturdays and Sundays</label></div>
    <button class="btn btn-primary" style="background:#1f3a5f;border-color:#1f3a5f">Create shift(s)</button></div></form>`)
    + App.card('Shifts (last 7 days and upcoming)', App.table([{ label: 'Date', key: 'shift_date' }, { label: 'Worker', key: 'worker_name' }, { label: 'Job', key: 'job_title' }, { label: 'Time', render: (s) => `${App.t5(s.start_time)} - ${App.t5(s.end_time)}` },
      { label: 'Attendance', render: (s) => (s.attendance_status ? App.badge(s.attendance_status) : '<span class="text-muted">none</span>') },
      { label: '', render: (s) => (s.attendance_id ? '' : `<button class="btn btn-sm btn-outline-danger" data-act="del" data-id="${s.id}">Delete</button>`) }], shifts, 'No shifts yet.'));
  box.querySelector('#sf').addEventListener('submit', async (e) => {
    e.preventDefault(); const v = App.formValues(e.target);
    try { const r = await App.post('/shifts', { ...v, assignment_id: Number(v.assignment_id) }); App.toast(`${r.created} shift(s) created.`); App.refresh(); } catch (x) { App.fail(x); }
  });
  App.on(box, { del: async (d) => { if (!confirm('Delete this shift?')) return; await App.del(`/shifts/${d.id}`); App.toast('Shift deleted.'); App.refresh(); } });
};

// ---------- Attendance (also used by the administrator) ----------
function attendanceCols(withActions = true) {
  const cols = [
    { label: 'Date', key: 'work_date' }, { label: 'Worker', render: (a) => `${App.esc(a.worker_name)}<div class="small text-muted">${App.esc(a.worker_code || '')}</div>` }, { label: 'Job', key: 'job_title' },
    { label: 'In', render: (a) => App.t5((a.clock_in || '').slice(11)) + (a.capture_method === 'qr' ? ' <span class="badge bg-light text-dark border">QR</span>' : '') }, { label: 'Out', render: (a) => App.t5((a.clock_out || '').slice(11)) },
    { label: 'Hours', render: (a) => a.total_hours ?? '-' },
    { label: 'Status', render: (a) => App.badge(a.attendance_status) + (a.is_late ? ' <span class="badge badge-late">Late</span>' : '') + (a.location_flag ? ' <span class="badge bg-warning text-dark" title="Clock-in was outside the worksite area">Location</span>' : '') },
    { label: 'Approval', render: (a) => App.badge(a.approval_status) + (a.supervisor_note ? `<div class="small text-muted">${App.esc(a.supervisor_note)}</div>` : '') },
  ];
  if (withActions || true) cols.push({ label: '', render: (a) => {
    if (a.approval_status !== 'Pending Approval') return a.total_pay != null ? `<span class="small text-muted">${App.money(a.total_pay)}</span>` : '';
    if (a.attendance_status !== 'Completed') return '<span class="small text-muted">needs correction</span>';
    return `<div class="btn-group btn-group-sm"><button class="btn btn-success" data-act="approve" data-id="${a.id}">Approve</button><button class="btn btn-outline-danger" data-act="reject" data-id="${a.id}">Reject</button><button class="btn btn-outline-secondary" data-act="ask" data-id="${a.id}">Ask correction</button></div>`;
  } });
  return cols;
}
function attendanceHandlers(box, rows) {
  App.on(box, {
    approve: async (d) => { const r = await App.put(`/attendance/${d.id}/approve`); App.toast(`Approved. Wage calculated: ${App.money(r.total_pay)}.`); App.refresh(); },
    reject: async (d) => { const n = await App.ask('Reject attendance', 'Reason for rejecting'); if (n) { await App.put(`/attendance/${d.id}/reject`, { note: n }); App.toast('Attendance rejected.'); App.refresh(); } },
    ask: async (d) => { const n = await App.ask('Ask for a correction', 'What should the worker correct?'); if (n) { await App.put(`/attendance/${d.id}/request-correction`, { note: n }); App.toast('The worker was asked to correct this record.'); App.refresh(); } },
    approveAll: async () => {
      const ready = rows.filter((a) => a.approval_status === 'Pending Approval' && a.attendance_status === 'Completed');
      if (!ready.length || !confirm(`Approve ${ready.length} completed record(s)? Wages will be calculated automatically.`)) return;
      let n = 0; for (const a of ready) { try { await App.put(`/attendance/${a.id}/approve`); n++; } catch (e) { App.fail(e); } }
      App.toast(`${n} record(s) approved.`); App.refresh();
    },
  });
}
const attendanceView = async (box) => {
  const today = App.today();
  const hash = new URLSearchParams((location.hash.split('?')[1] || ''));
  const f = { from: hash.get('from') || App.addDays(today, -14), to: hash.get('to') || today, approval: hash.get('approval') || '', status: hash.get('status') || '' };
  const rows = await App.get('/attendance' + App.qs(f));
  const opt = (arr, cur, blank) => `<option value="">${blank}</option>` + arr.map((x) => `<option ${x === cur ? 'selected' : ''}>${x}</option>`).join('');
  box.innerHTML = App.title('Attendance', '<button class="btn btn-success" data-act="approveAll">Approve all completed</button>') + `<form class="row g-2 mb-3" id="af">
    <div class="col-6 col-md-2"><input class="form-control" type="date" name="from" value="${f.from}"></div><div class="col-6 col-md-2"><input class="form-control" type="date" name="to" value="${f.to}"></div>
    <div class="col-6 col-md-3"><select class="form-select" name="approval">${opt(['Pending Approval', 'Approved', 'Rejected', 'Correction Requested'], f.approval, 'Any approval status')}</select></div>
    <div class="col-6 col-md-3"><select class="form-select" name="status">${opt(['In Progress', 'Completed', 'Absent', 'Missed Clock-out'], f.status, 'Any attendance status')}</select></div>
    <div class="col-md-2"><button class="btn btn-outline-primary w-100">Filter</button></div></form>` + App.card(`${rows.length} record(s)`, App.table(attendanceCols(), rows, 'No attendance records for this filter.'));
  box.querySelector('#af').addEventListener('submit', (e) => { e.preventDefault(); const q = App.qs(App.formValues(e.target)); location.hash = '#/attendance' + q; });
  attendanceHandlers(box, rows);
};
App.views['supervisor.attendance'] = attendanceView;
App.views['admin.attendance'] = attendanceView;

// ---------- Corrections (also used by the administrator) ----------
const correctionsView = async (box) => {
  const rows = await App.get('/corrections');
  const pend = rows.filter((c) => c.status === 'pending');
  const colsBase = [{ label: 'Date', key: 'work_date' }, { label: 'Worker', key: 'worker_name' }, { label: 'Requested by', render: (c) => `${App.esc(c.requested_by_name)} <span class="text-muted small">(${c.requested_by_role})</span>` },
    { label: 'Original', render: (c) => `${App.t5((c.original_clock_in || '').slice(11))} - ${App.t5((c.original_clock_out || '').slice(11))}` },
    { label: 'Proposed', render: (c) => `<strong>${App.t5(c.proposed_clock_in.slice(11))} - ${App.t5(c.proposed_clock_out.slice(11))}</strong>` }, { label: 'Reason', key: 'reason' }];
  box.innerHTML = App.title('Attendance corrections')
    + App.card(`Waiting for a decision (${pend.length})`, App.table([...colsBase, { label: '', render: (c) => `<div class="btn-group btn-group-sm"><button class="btn btn-success" data-act="yes" data-id="${c.id}">Approve</button><button class="btn btn-outline-danger" data-act="no" data-id="${c.id}">Reject</button></div>` }], pend, 'No correction requests waiting.'))
    + App.card('History', App.table([...colsBase, { label: 'Decision', render: (c) => App.badge(c.status) + (c.review_note ? `<div class="small text-muted">${App.esc(c.review_note)}</div>` : '') }], rows.filter((c) => c.status !== 'pending'), 'No decisions yet.'));
  App.on(box, {
    yes: async (d) => { await App.put(`/corrections/${d.id}/decision`, { decision: 'approve' }); App.toast('Correction approved. The record now needs re-approval.'); App.refresh(); },
    no: async (d) => { const n = await App.ask('Reject correction', 'Reason'); if (n) { await App.put(`/corrections/${d.id}/decision`, { decision: 'reject', note: n }); App.toast('Correction rejected.'); App.refresh(); } },
  });
};
App.views['supervisor.corrections'] = correctionsView;
App.views['admin.corrections'] = correctionsView;
App.views['supervisor.reports'] = App.views['common.reports'];

// ---------- QR scan station ----------
App.views['supervisor.scan'] = async (box) => {
  box.innerHTML = App.title('QR scan station') + `<div class="row g-3"><div class="col-lg-6"><div class="card"><div class="card-body text-center">
    <video id="scanVideo" playsinline muted></video><canvas id="scanCanvas" class="d-none"></canvas>
    <div class="small text-muted mt-2" id="camMsg">Starting camera...</div>
    <hr><form id="manual" class="d-flex gap-2"><input class="form-control" name="code" placeholder="Or type the badge code" autocomplete="off"><button class="btn btn-primary" style="background:#1f3a5f;border-color:#1f3a5f">Submit</button></form>
    <div class="form-text text-start">Scan a worker's QR badge to clock them in. Scan again to clock them out.</div></div></div></div>
    <div class="col-lg-6"><div class="card"><div class="card-header">Recent scans</div><div class="card-body p-0" id="scanLog"><div class="text-muted p-3">No scans yet.</div></div></div></div></div>`;
  const log = [];
  let last = '', lastAt = 0, busy = false;
  async function submit(code) {
    if (busy) return; busy = true;
    try {
      const r = await App.post('/attendance/scan', { code });
      log.unshift({ ok: true, text: `${r.worker}: ${r.action === 'clock-in' ? 'clocked in' : 'clocked out'} at ${App.dt(r.action === 'clock-in' ? r.attendance.clock_in : r.attendance.clock_out).slice(11)}${r.attendance.is_late && r.action === 'clock-in' ? ' (late)' : ''}` });
      App.toast(log[0].text);
    } catch (e) { log.unshift({ ok: false, text: e.message }); App.fail(e); }
    finally { busy = false; }
    box.querySelector('#scanLog').innerHTML = log.slice(0, 12).map((l) => `<div class="px-3 py-2 border-bottom ${l.ok ? '' : 'text-danger'}">${l.ok ? 'OK' : 'Error'}: ${App.esc(l.text)}</div>`).join('');
  }
  box.querySelector('#manual').addEventListener('submit', (e) => { e.preventDefault(); const c = e.target.code.value.trim(); if (c) submit(c); e.target.reset(); });
  const video = box.querySelector('#scanVideo'), canvas = box.querySelector('#scanCanvas'), msg = box.querySelector('#camMsg');
  try {
    if (!navigator.mediaDevices?.getUserMedia) throw new Error('Camera is not available in this browser.');
    App._stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
    video.srcObject = App._stream; await video.play(); msg.textContent = 'Point the camera at a worker QR badge.';
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    const loop = () => {
      if (!App._stream) return;
      if (video.readyState === video.HAVE_ENOUGH_DATA) {
        canvas.width = video.videoWidth; canvas.height = video.videoHeight; ctx.drawImage(video, 0, 0);
        const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = window.jsQR && window.jsQR(img.data, img.width, img.height);
        if (code && code.data && (code.data !== last || Date.now() - lastAt > 6000)) { last = code.data; lastAt = Date.now(); submit(code.data); }
      }
      setTimeout(loop, 250);
    };
    loop();
  } catch (e) { msg.textContent = 'Camera not available (' + e.message + '). Use the code box below instead.'; }
};
